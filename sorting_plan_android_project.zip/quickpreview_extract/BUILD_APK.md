# SORTING PLAN - ID Dn INDORE — Android App (APK)

## Option A — Bina Android Studio ke (sabse aasan, GitHub se)
1. github.com par free account banao → **New repository** (Private rakh sakte ho).
2. Is poore folder ki files repository me upload karo (Add file → Upload files).
   `node_modules`, `dist` upload mat karna (ye .gitignore me hain).
3. Repository me **Actions** tab → **Build Android APK** → **Run workflow**.
4. 5–8 minute baad run ke andar **sorting-plan-apk** artifact download karo → andar `app-debug.apk`.
5. APK ko phone me bhejo, install karo (Settings me "Install unknown apps" allow karna padega).

## Option B — Android Studio se
```
npm install
npm run build
npx cap sync android
npx cap open android      # Android Studio khulega → Build ▸ Build APK(s)
```
Ya command line se: `cd android && ./gradlew assembleDebug`
APK yahan milegi: `android/app/build/outputs/apk/debug/app-debug.apk`

## App me kya native hai
- **Mic (voice search):** phone ka apna speech engine (Hindi/English). Pehli baar Microphone permission poochega.
- **Barcode/QR scan (Article Tracking):** Google ML Kit camera scanner.
- Status bar, splash screen, app icon, hardware Back button (pehle popup band hota hai, phir app).
- Poora data app ke andar embedded hai — bina internet ke chalta hai.
  Internet sirf PIN directory lookup aur Speed Post tracking ke liye chahiye.

## Play Store ke liye (baad me)
Debug APK sirf install/test ke liye hai. Play Store ke liye signed **release** build (keystore) chahiye:
`./gradlew bundleRelease` aur apni keystore se sign karo.
