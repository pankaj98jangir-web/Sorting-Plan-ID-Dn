import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  X,
  Search,
  Building2,
  MapPin,
  Copy,
  Check,
  Printer,
  ExternalLink,
  ChevronRight,
  Filter,
  Layers,
  ArrowRight,
  Sparkles
} from 'lucide-react';
import { PostalRecord } from '../data/types';
import { useModalBackButton } from '../hooks/useModalBackButton';
import { useLanguage } from '../i18n/LanguageContext';

interface OfficeDirectoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  allRecords: PostalRecord[];
  initialOfficeName?: string;
  onSelectOfficeInMainSearch?: (officeName: string) => void;
  onOpenAddressFinder?: (query: string) => void;
  onShowToast?: (msg: string) => void;
}

type OfficeTypeFilter = 'all' | 'so' | 'bo' | 'ho';

interface DistinctOffice {
  name: string;
  type: 'BO' | 'SO' | 'HO' | 'OTHER';
  pincode: string;
  parentSo?: string;
  parentHo?: string;
  division?: string;
  villagesCount: number;
}

export const OfficeDirectoryModal: React.FC<OfficeDirectoryModalProps> = ({
  isOpen,
  onClose,
  allRecords,
  initialOfficeName = '',
  onSelectOfficeInMainSearch,
  onOpenAddressFinder,
  onShowToast
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOfficeName, setSelectedOfficeName] = useState<string>('');
  const [selectedOfficeType, setSelectedOfficeType] = useState<'BO' | 'SO' | 'HO' | 'OTHER'>('SO');
  const [typeFilter, setTypeFilter] = useState<OfficeTypeFilter>('all');
  const [villageFilterQuery, setVillageFilterQuery] = useState('');
  const [copiedAll, setCopiedAll] = useState(false);
  const [copiedVillageId, setCopiedVillageId] = useState<string | null>(null);

  const searchInputRef = useRef<HTMLInputElement>(null);

  // Set initial office when opened
  useEffect(() => {
    if (isOpen) {
      if (initialOfficeName) {
        setSearchQuery(initialOfficeName);
        setSelectedOfficeName(initialOfficeName.trim().toUpperCase());
      } else {
        setTimeout(() => searchInputRef.current?.focus(), 150);
      }
    } else {
      setVillageFilterQuery('');
      setCopiedAll(false);
    }
  }, [isOpen, initialOfficeName]);

  // Aggregate all distinct Sub Offices (field2), Branch Offices (field1), and Head Offices (field3)
  const distinctOffices = useMemo(() => {
    const map = new Map<string, DistinctOffice>();
    // Skip the heavy aggregation while the modal is closed (it stays mounted).
    if (!isOpen) return [] as DistinctOffice[];

    allRecords.forEach((r) => {
      // 1. Sub Office (S.O)
      const soRaw = (r.field2 || '').trim();
      if (soRaw && soRaw !== '-' && soRaw.length > 1) {
        const soKey = `SO::${soRaw.toUpperCase()}`;
        const existing = map.get(soKey);
        if (existing) {
          existing.villagesCount++;
        } else {
          map.set(soKey, {
            name: soRaw,
            type: 'SO',
            pincode: r.pincode || '',
            parentHo: r.field3 || '',
            division: r.listName || '',
            villagesCount: 1
          });
        }
      }

      // 2. Branch Office (B.O)
      const boRaw = (r.field1 || '').trim();
      if (boRaw && boRaw !== '-' && boRaw.length > 1) {
        const boKey = `BO::${boRaw.toUpperCase()}`;
        const existing = map.get(boKey);
        if (existing) {
          existing.villagesCount++;
        } else {
          map.set(boKey, {
            name: boRaw,
            type: 'BO',
            pincode: r.pincode || '',
            parentSo: r.field2 || '',
            parentHo: r.field3 || '',
            division: r.listName || '',
            villagesCount: 1
          });
        }
      }
    });

    return Array.from(map.values()).sort((a, b) => b.villagesCount - a.villagesCount);
  }, [allRecords, isOpen]);

  // Filter distinct offices based on search query and type filter
  const filteredOffices = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return distinctOffices.filter((off) => {
      if (typeFilter === 'so' && off.type !== 'SO') return false;
      if (typeFilter === 'bo' && off.type !== 'BO') return false;
      if (!q) return true;
      return (
        off.name.toLowerCase().includes(q) ||
        off.pincode.includes(q) ||
        (off.parentSo && off.parentSo.toLowerCase().includes(q)) ||
        (off.division && off.division.toLowerCase().includes(q))
      );
    });
  }, [distinctOffices, searchQuery, typeFilter]);

  // Set default selected office if none selected yet
  useEffect(() => {
    if (!selectedOfficeName && filteredOffices.length > 0) {
      setSelectedOfficeName(filteredOffices[0].name);
      setSelectedOfficeType(filteredOffices[0].type);
    }
  }, [filteredOffices, selectedOfficeName]);

  // Find records matching the selected office
  const matchingRecords = useMemo(() => {
    if (!selectedOfficeName) return [];
    const targetNorm = selectedOfficeName.trim().toUpperCase();

    const seen = new Set<string>();
    const res: PostalRecord[] = [];

    allRecords.forEach((r) => {
      const matchSo = (r.field2 || '').trim().toUpperCase() === targetNorm;
      const matchBo = (r.field1 || '').trim().toUpperCase() === targetNorm;

      if (matchSo || matchBo) {
        const dedupKey = `${r.village.toLowerCase()}::${(r.field1 || '').toLowerCase()}`;
        if (!seen.has(dedupKey)) {
          seen.add(dedupKey);
          res.push(r);
        }
      }
    });

    return res.sort((a, b) => a.village.localeCompare(b.village));
  }, [allRecords, selectedOfficeName]);

  // Filter matching records by sub-query
  const filteredVillages = useMemo(() => {
    const q = villageFilterQuery.trim().toLowerCase();
    if (!q) return matchingRecords;
    return matchingRecords.filter(
      (r) =>
        r.village.toLowerCase().includes(q) ||
        r.pincode.includes(q) ||
        (r.field1 && r.field1.toLowerCase().includes(q))
    );
  }, [matchingRecords, villageFilterQuery]);

  // Current selected office metadata
  const currentOfficeMeta = useMemo(() => {
    return distinctOffices.find(
      (o) => o.name.toUpperCase() === selectedOfficeName.toUpperCase()
    );
  }, [distinctOffices, selectedOfficeName]);

  // Copy all villages in clean formatted text
  const handleCopyAllVillages = () => {
    if (matchingRecords.length === 0) return;
    const header = `=== INDIA POST VILLAGE BEAT DIRECTORY ===\nOffice: ${selectedOfficeName} (${selectedOfficeType})\nPIN: ${currentOfficeMeta?.pincode || 'N/A'}\nTotal Villages / Areas: ${matchingRecords.length}\n----------------------------------------\n`;
    const list = matchingRecords
      .map((r, i) => `${i + 1}. ${r.village} (BO: ${r.field1 || 'Direct'}, PIN: ${r.pincode})`)
      .join('\n');
    const fullText = header + list;

    navigator.clipboard.writeText(fullText).then(() => {
      setCopiedAll(true);
      setTimeout(() => setCopiedAll(false), 2500);
      onShowToast?.(`Copied all ${matchingRecords.length} villages under ${selectedOfficeName}!`);
    });
  };

  const handleCopySingleVillage = (village: string, id: string) => {
    navigator.clipboard.writeText(village).then(() => {
      setCopiedVillageId(id);
      setTimeout(() => setCopiedVillageId(null), 2000);
    });
  };

  const handlePrintOfficeBeats = () => {
    window.print();
  };

  const { t } = useLanguage();
  useModalBackButton(isOpen, onClose);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs animate-fade-in no-print">
      <div className="bg-white dark:bg-[#1E1714] text-stone-900 dark:text-stone-100 rounded-3xl w-full max-w-4xl shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-stone-100 dark:border-stone-800 bg-gradient-to-r from-[#8E1B25]/10 via-amber-500/5 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#8E1B25] text-white flex items-center justify-center shadow-sm shrink-0">
              <Building2 className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-stone-900 dark:text-stone-100">
                  Sub Office &amp; Branch Office Beat Explorer
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-200 border border-amber-300 dark:border-amber-800">
                  Village Beat Directory
                </span>
              </div>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                Lookup any Sub Office (S.O) or Branch Post Office (B.O) to view all associated villages &amp; delivery areas
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Selection Filter Bar */}
        <div className="p-4 sm:p-5 border-b border-stone-100 dark:border-stone-800 bg-stone-50/60 dark:bg-stone-900/40 space-y-3">
          
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Type Sub Office or Branch Office name (e.g., Manawar, Bagli, Aagrod, Alirajpur)..."
                className="w-full pl-10 pr-9 py-2.5 rounded-xl bg-white dark:bg-[#261C18] border border-stone-300 dark:border-stone-700 text-xs sm:text-sm text-stone-900 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-[#8E1B25] shadow-xs"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Type Filter Tabs */}
            <div className="flex items-center gap-1 p-1 bg-stone-200/80 dark:bg-stone-800 rounded-xl text-xs shrink-0">
              <button
                type="button"
                onClick={() => setTypeFilter('all')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                  typeFilter === 'all'
                    ? 'bg-white dark:bg-[#1E1714] text-[#8E1B25] dark:text-amber-400 shadow-2xs'
                    : 'text-stone-600 dark:text-stone-400'
                }`}
              >
                All ({distinctOffices.length})
              </button>
              <button
                type="button"
                onClick={() => setTypeFilter('so')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                  typeFilter === 'so'
                    ? 'bg-white dark:bg-[#1E1714] text-[#8E1B25] dark:text-amber-400 shadow-2xs'
                    : 'text-stone-600 dark:text-stone-400'
                }`}
              >
                Sub Offices (S.O)
              </button>
              <button
                type="button"
                onClick={() => setTypeFilter('bo')}
                className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                  typeFilter === 'bo'
                    ? 'bg-white dark:bg-[#1E1714] text-[#8E1B25] dark:text-amber-400 shadow-2xs'
                    : 'text-stone-600 dark:text-stone-400'
                }`}
              >
                Branch Offices (B.O)
              </button>
            </div>
          </div>

          {/* Quick Autocomplete Office Chips */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            <span className="text-[11px] font-semibold text-stone-400 shrink-0">Matching Offices:</span>
            {filteredOffices.slice(0, 10).map((off) => (
              <button
                key={`${off.type}-${off.name}`}
                type="button"
                onClick={() => {
                  setSelectedOfficeName(off.name);
                  setSelectedOfficeType(off.type);
                }}
                className={`px-2.5 py-1 rounded-lg font-bold text-xs shrink-0 transition-all flex items-center gap-1.5 cursor-pointer ${
                  selectedOfficeName.toUpperCase() === off.name.toUpperCase()
                    ? 'bg-[#8E1B25] text-white shadow-xs'
                    : 'bg-white dark:bg-stone-800 text-stone-700 dark:text-stone-300 border border-stone-200 dark:border-stone-700 hover:bg-stone-100 dark:hover:bg-stone-700'
                }`}
              >
                <span className={`text-[10px] px-1 rounded ${
                  selectedOfficeName.toUpperCase() === off.name.toUpperCase()
                    ? 'bg-white/20 text-white'
                    : 'bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300'
                }`}>
                  {off.type}
                </span>
                <span>{off.name}</span>
                <span className="opacity-75 font-mono text-[10px]">({off.villagesCount})</span>
              </button>
            ))}
          </div>

        </div>

        {/* Content Body: Split View (Offices Sidebar + Selected Office Villages) */}
        <div className="flex-1 overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-0">
          
          {/* Left Column: Office List (Mobile hidden or scrollable) */}
          <div className="hidden md:flex md:col-span-4 flex-col border-r border-stone-200 dark:border-stone-800 bg-stone-50/40 dark:bg-stone-900/20 overflow-y-auto">
            <div className="p-3 border-b border-stone-100 dark:border-stone-800 text-[11px] font-bold text-stone-500 uppercase tracking-wider flex items-center justify-between">
              <span>Postal Offices</span>
              <span>{filteredOffices.length} found</span>
            </div>

            <div className="divide-y divide-stone-100 dark:divide-stone-800/60 overflow-y-auto">
              {filteredOffices.map((off) => {
                const isSelected = selectedOfficeName.toUpperCase() === off.name.toUpperCase();
                return (
                  <button
                    key={`${off.type}-${off.name}`}
                    type="button"
                    onClick={() => {
                      setSelectedOfficeName(off.name);
                      setSelectedOfficeType(off.type);
                    }}
                    className={`w-full text-left p-3 transition-colors flex items-center justify-between gap-2 cursor-pointer ${
                      isSelected
                        ? 'bg-amber-100/70 dark:bg-amber-950/40 text-stone-900 dark:text-stone-100 border-l-4 border-[#8E1B25]'
                        : 'hover:bg-stone-100/60 dark:hover:bg-stone-800/40 text-stone-700 dark:text-stone-300'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-xs truncate">{off.name}</span>
                        <span className="text-[10px] px-1 py-0.2 rounded font-bold bg-stone-200 dark:bg-stone-700 text-stone-700 dark:text-stone-300">
                          {off.type}
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 truncate mt-0.5">
                        PIN: {off.pincode} {off.division ? `· ${off.division}` : ''}
                      </p>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-mono font-bold bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 text-[#8E1B25] dark:text-amber-400">
                        {off.villagesCount}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Column: Villages / Areas under Selected Office */}
          <div className="col-span-12 md:col-span-8 flex flex-col overflow-hidden bg-white dark:bg-[#1E1714]">
            
            {/* Office Header Card */}
            {selectedOfficeName ? (
              <div className="p-4 sm:p-5 border-b border-stone-200 dark:border-stone-800 bg-gradient-to-r from-amber-50/50 via-stone-50 to-transparent dark:from-amber-950/20 dark:via-stone-900/20 dark:to-transparent space-y-3">
                
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-base sm:text-lg font-black text-stone-900 dark:text-stone-100">
                        {selectedOfficeName}
                      </h3>
                      <span className="px-2 py-0.5 rounded-md font-bold text-xs bg-[#8E1B25] text-white">
                        {selectedOfficeType === 'SO' ? 'Sub Post Office (S.O)' : 'Branch Post Office (B.O)'}
                      </span>
                      {currentOfficeMeta?.pincode && (
                        <span className="font-mono font-bold text-xs bg-amber-200/80 dark:bg-amber-950 px-2 py-0.5 rounded border border-amber-300 dark:border-amber-800 text-stone-900 dark:text-amber-300">
                          PIN {currentOfficeMeta.pincode}
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
                      {currentOfficeMeta?.parentHo ? `Head Office: ${currentOfficeMeta.parentHo}` : ''}
                      {currentOfficeMeta?.division ? ` · Division: ${currentOfficeMeta.division}` : ''}
                    </p>
                  </div>

                  {/* Village Count Badge */}
                  <div className="flex items-center gap-2">
                    <div className="px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 font-bold text-xs flex items-center gap-1.5 shadow-2xs">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{matchingRecords.length} Villages / Delivery Beats</span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons Bar */}
                <div className="flex items-center justify-between gap-2 flex-wrap text-xs pt-1">
                  
                  {/* Sub-search within villages */}
                  <div className="relative flex-1 min-w-[200px]">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-stone-400" />
                    <input
                      type="text"
                      value={villageFilterQuery}
                      onChange={(e) => setVillageFilterQuery(e.target.value)}
                      placeholder={`Filter among ${matchingRecords.length} villages...`}
                      className="w-full pl-8 pr-7 py-1.5 rounded-lg bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 text-xs text-stone-900 dark:text-stone-100 focus:outline-none focus:ring-1 focus:ring-[#8E1B25]"
                    />
                    {villageFilterQuery && (
                      <button
                        onClick={() => setVillageFilterQuery('')}
                        className="absolute right-2 top-1/2 -translate-y-1/2 p-0.5 text-stone-400 hover:text-stone-600"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 flex-wrap">
                    {/* Copy All Button */}
                    <button
                      type="button"
                      onClick={handleCopyAllVillages}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 transition-colors shadow-2xs cursor-pointer"
                      title="Copy complete list of villages for office record or memo"
                    >
                      {copiedAll ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-[#8E1B25]" />}
                      <span>{copiedAll ? 'Copied List!' : 'Copy All Villages'}</span>
                    </button>

                    {/* Filter in Main Search */}
                    {onSelectOfficeInMainSearch && (
                      <button
                        type="button"
                        onClick={() => {
                          onSelectOfficeInMainSearch(selectedOfficeName);
                          onClose();
                        }}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg font-bold text-xs bg-amber-400 hover:bg-amber-300 text-stone-900 transition-colors shadow-2xs cursor-pointer"
                        title="Search this office in main sorting plan"
                      >
                        <span>Filter in Main Plan</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {/* Address Finder link */}
                    <button
                      type="button"
                      onClick={() => onOpenAddressFinder?.(`${selectedOfficeName} Post Office, Indore Region`)}
                      className="p-1.5 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 hover:bg-emerald-200 transition-colors cursor-pointer"
                      title="Look up this office in the Address Finder"
                    >
                      <MapPin className="w-4 h-4" />
                    </button>
                  </div>

                </div>

              </div>
            ) : null}

            {/* Villages List Grid */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-2">
              {filteredVillages.length === 0 ? (
                <div className="text-center py-12 space-y-2 text-stone-400">
                  <Building2 className="w-8 h-8 mx-auto opacity-50" />
                  <p className="font-semibold text-sm">No villages found for this search.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {filteredVillages.map((r, idx) => {
                    const isCopied = copiedVillageId === r.id;
                    return (
                      <div
                        key={r.id || idx}
                        className="p-3 bg-stone-50/80 dark:bg-stone-900/50 hover:bg-amber-50/50 dark:hover:bg-amber-950/20 rounded-xl border border-stone-200 dark:border-stone-800 transition-all flex flex-col justify-between gap-2 shadow-2xs group"
                      >
                        <div>
                          <div className="flex items-start justify-between gap-1.5">
                            <div className="flex items-start gap-2 min-w-0">
                              <span className="font-mono text-[11px] font-bold text-stone-400 mt-0.5">
                                #{idx + 1}
                              </span>
                              <strong className="font-bold text-xs sm:text-sm text-stone-900 dark:text-stone-100 break-words">
                                {r.village}
                              </strong>
                            </div>
                            
                            <span className="font-mono text-xs font-bold text-[#8E1B25] dark:text-amber-400 bg-white dark:bg-stone-800 px-1.5 py-0.5 rounded border border-stone-200 dark:border-stone-700 shrink-0">
                              {r.pincode}
                            </span>
                          </div>

                          <div className="mt-1 space-y-0.5 text-[11px] text-stone-500 dark:text-stone-400 pl-5">
                            {r.field1 && r.field1 !== '-' && (
                              <p className="truncate">
                                <strong>BO:</strong> {r.field1}
                              </p>
                            )}
                            {r.field2 && (
                              <p className="truncate">
                                <strong>SO:</strong> {r.field2}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Village Quick Actions */}
                        <div className="flex items-center justify-between border-t border-stone-200/60 dark:border-stone-800 pt-2 pl-5">
                          <button
                            type="button"
                            onClick={() => handleCopySingleVillage(r.village, r.id)}
                            className="text-[11px] font-semibold text-stone-600 dark:text-stone-400 hover:text-[#8E1B25] dark:hover:text-amber-300 flex items-center gap-1 cursor-pointer"
                          >
                            {isCopied ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                            <span>{isCopied ? 'Copied' : 'Copy Name'}</span>
                          </button>

                          {onOpenAddressFinder && (
                            <button
                              type="button"
                              onClick={() => onOpenAddressFinder(`${r.village}, PIN ${r.pincode}`)}
                              className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
                              title="Look up this village in the Address Finder"
                            >
                              <MapPin className="w-3 h-3" />
                              <span>Map</span>
                            </button>
                          )}
                        </div>

                      </div>
                    );
                  })}
                </div>
              )}
            </div>

          </div>

        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-stone-100 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50 flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="text-stone-400 text-[11px] min-w-0 truncate">
            {t('officeDir.footerNote')}
          </span>

          <button
            type="button"
            onClick={onClose}
            className="shrink-0 px-4 py-2 font-bold text-stone-700 dark:text-stone-300 hover:bg-stone-200/60 dark:hover:bg-stone-800 rounded-lg transition-colors cursor-pointer"
          >
            {t('common.close')}
          </button>
        </div>

      </div>
    </div>
  );
};
