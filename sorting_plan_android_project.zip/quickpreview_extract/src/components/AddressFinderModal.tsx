import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  X,
  MapPin,
  Search,
  Mic,
  MicOff,
  Copy,
  Check,
  RotateCcw,
  WifiOff,
  Building,
  ArrowRight,
} from 'lucide-react';
import { PostalRecord } from '../data/types';
import { useVoiceSearch } from '../hooks/useVoiceSearch';
import { fuzzySearchRecords } from '../utils/postalSearch';
import { useModalBackButton } from '../hooks/useModalBackButton';
import { extractPincode, lookupPincodeFree, FreePincodeResult } from '../utils/freePincodeLookup';
import { useLanguage } from '../i18n/LanguageContext';

interface AddressFinderModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
  contextRecord?: PostalRecord | null;
  records: PostalRecord[];
  onSelectPincode?: (pin: string) => void;
  onShowToast?: (msg: string) => void;
}

export const AddressFinderModal: React.FC<AddressFinderModalProps> = ({
  isOpen,
  onClose,
  initialQuery = '',
  contextRecord = null,
  records: allPostalRecords,
  onSelectPincode,
  onShowToast,
}) => {
  const { t } = useLanguage();
  const [addressInput, setAddressInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [freeResult, setFreeResult] = useState<FreePincodeResult | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [isOnline, setIsOnline] = useState(() => (typeof navigator !== 'undefined' ? navigator.onLine : true));
  const [searchedOnce, setSearchedOnce] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);

  // Offline matching records from the embedded dataset
  const offlineMatches = useMemo(() => {
    const q = addressInput.trim();
    if (!isOpen || !q || q.length < 2) return [];
    return fuzzySearchRecords(allPostalRecords, q).slice(0, 6);
  }, [isOpen, addressInput, allPostalRecords]);

  // Monitor online status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Sync initial query & context record
  useEffect(() => {
    if (isOpen) {
      if (initialQuery) {
        setAddressInput(initialQuery);
        handleSearch(initialQuery);
      } else if (contextRecord) {
        const text = `${contextRecord.village}, ${contextRecord.field2 || ''}, PIN ${contextRecord.pincode}`;
        setAddressInput(text);
        handleSearch(text);
      } else {
        setTimeout(() => inputRef.current?.focus(), 150);
      }
    } else {
      setErrorMessage(null);
      setFreeResult(null);
      setSearchedOnce(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, initialQuery, contextRecord]);

  // Voice Search setup
  const {
    isSupported: isVoiceSupported,
    isListening,
    interimTranscript,
    lang: voiceLang,
    setLang: setVoiceLang,
    startListening,
    stopListening,
  } = useVoiceSearch({
    onTranscript: (spokenText) => {
      setAddressInput((prev) => {
        const next = prev ? `${prev} ${spokenText}` : spokenText;
        setTimeout(() => handleSearch(next), 200);
        return next;
      });
    },
    onError: (err) => {
      onShowToast?.(err);
    },
  });

  const handleSearch = async (queryToSearch?: string) => {
    const q = (queryToSearch !== undefined ? queryToSearch : addressInput).trim();
    if (!q) {
      setErrorMessage(t('addressFinder.enterQuery'));
      return;
    }

    setSearchedOnce(true);
    setErrorMessage(null);
    setFreeResult(null);

    // The free India Post directory only resolves an exact 6-digit PIN —
    // use the one from the context record if we have it, otherwise look
    // for one in the typed query itself.
    const pin = (contextRecord && contextRecord.pincode) || extractPincode(q);
    if (!pin) {
      // No PIN to look up online — the offline matches above are all we can
      // offer for a free-text query.
      return;
    }

    if (!navigator.onLine) {
      return; // offline — offline matches still show; nothing more to do
    }

    setIsLoading(true);
    try {
      const result = await lookupPincodeFree(pin);
      if (result) {
        setFreeResult(result);
      } else {
        setErrorMessage(t('addressFinder.noEntryFound', { pin }));
      }
    } catch {
      setErrorMessage(t('addressFinder.couldNotReach'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!freeResult) return;
    const text = [
      `PIN Code: ${freeResult.pincode}`,
      `District / State: ${freeResult.offices[0]?.district}, ${freeResult.offices[0]?.state}`,
      `Division: ${freeResult.offices[0]?.division} | Region: ${freeResult.offices[0]?.region}`,
      '',
      'Post Offices:',
      ...freeResult.offices.map((o) => `- ${o.name} (${o.branchType})`),
    ].join('\n');
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
      onShowToast?.('Address details copied to clipboard');
    });
  };

  useModalBackButton(isOpen, onClose);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-fade-in no-print">
      <div className="bg-white dark:bg-[#261C18] text-stone-900 dark:text-stone-100 rounded-2xl w-full max-w-2xl shadow-2xl border border-stone-200 dark:border-stone-800 flex flex-col max-h-[92vh] overflow-hidden">

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-stone-100 dark:border-stone-800 bg-gradient-to-r from-stone-50 to-amber-50/40 dark:from-stone-900 dark:to-[#221815]">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-[#8E1B25] text-white shadow-xs">
              <MapPin className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100 leading-snug">
                  {t('addressFinder.title')}
                </h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-100 dark:bg-sky-950/60 text-sky-800 dark:text-sky-300 border border-sky-300 dark:border-sky-800/80">
                  {t('addressFinder.badge')}
                </span>
              </div>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                {t('addressFinder.subtitle')}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="shrink-0 p-1.5 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors cursor-pointer"
            aria-label="Close address finder"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar & Controls */}
        <div className="p-4 sm:p-5 border-b border-stone-100 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/30 space-y-3">

          {!isOnline && (
            <div className="flex items-center gap-2 p-2.5 text-xs bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-200 rounded-xl border border-amber-200 dark:border-amber-900/60">
              <WifiOff className="w-4 h-4 shrink-0 text-amber-600" />
              <span>{t('addressFinder.offlineModeNote')}</span>
            </div>
          )}

          {contextRecord && (
            <div className="flex items-center gap-2 text-xs bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 px-3 py-1.5 rounded-lg border border-amber-200 dark:border-amber-900/50">
              <Building className="w-3.5 h-3.5 text-[#8E1B25] dark:text-amber-400 shrink-0" />
              <span className="truncate">
                {t('addressFinder.postalRecord')} <strong>{contextRecord.village}</strong> (PIN {contextRecord.pincode} · {contextRecord.field2 || contextRecord.field3})
              </span>
            </div>
          )}

          {/* Address Input Box */}
          <div className="relative flex items-center">
            <Search className="absolute left-3.5 w-4 h-4 text-stone-400 pointer-events-none" />
            <input
              ref={inputRef}
              type="text"
              value={addressInput}
              onChange={(e) => setAddressInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleSearch();
                }
              }}
              placeholder={t('addressFinder.placeholder')}
              className={`w-full pl-10 py-2.5 bg-white dark:bg-[#1E1714] border border-stone-300 dark:border-stone-700 rounded-xl text-xs sm:text-sm text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-hidden focus:ring-2 focus:ring-[#8E1B25] dark:focus:ring-amber-400/50 transition-all shadow-2xs ${
                isVoiceSupported ? 'pr-24' : 'pr-10'
              }`}
            />

            <div className="absolute right-2 flex items-center gap-1">
              {addressInput && (
                <button
                  onClick={() => {
                    setAddressInput('');
                    inputRef.current?.focus();
                  }}
                  className="p-1 rounded-md text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 cursor-pointer"
                  title="Clear input"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}

              {isVoiceSupported && (
                <button
                  type="button"
                  onClick={isListening ? stopListening : startListening}
                  className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                    isListening
                      ? 'bg-rose-500 text-white animate-pulse shadow-md ring-2 ring-rose-400'
                      : 'text-stone-500 hover:text-[#8E1B25] dark:text-stone-400 dark:hover:text-amber-400 hover:bg-stone-100 dark:hover:bg-stone-800'
                  }`}
                  title={isListening ? 'Stop mic' : 'Voice Search'}
                >
                  {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                </button>
              )}

              {isVoiceSupported && (
                <button
                  type="button"
                  onClick={() => setVoiceLang(voiceLang === 'hi-IN' ? 'en-IN' : 'hi-IN')}
                  className="px-1.5 py-0.5 text-[10px] font-bold rounded bg-stone-200 dark:bg-stone-700 text-stone-700 dark:text-stone-200 hover:bg-stone-300 dark:hover:bg-stone-600 transition-colors cursor-pointer"
                  title="Switch speech dialect: English / Hindi"
                >
                  {voiceLang === 'hi-IN' ? 'HI' : 'EN'}
                </button>
              )}
            </div>
          </div>

          {isListening && (
            <div className="flex items-center gap-2 px-3 py-1.5 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 text-xs rounded-lg border border-rose-200 dark:border-rose-900/60 animate-pulse">
              <span className="w-2 h-2 rounded-full bg-rose-600 animate-ping" />
              <span>Listening... {voiceLang === 'hi-IN' ? '(Hindi)' : '(English)'}</span>
              {interimTranscript && (
                <span className="font-semibold text-rose-900 dark:text-rose-100 italic truncate">
                  "{interimTranscript}"
                </span>
              )}
            </div>
          )}

          <div className="flex justify-end">
            <button
              onClick={() => handleSearch()}
              disabled={isLoading || !addressInput.trim()}
              className="flex items-center gap-1.5 px-4 py-1.5 font-bold text-xs text-white bg-[#8E1B25] hover:bg-[#6F151C] disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              {isLoading ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>{t('common.searching')}</span>
                </>
              ) : (
                <>
                  <Search className="w-3.5 h-3.5" />
                  <span>{t('common.search')}</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">

          {/* Offline matched postal records */}
          {offlineMatches.length > 0 && (
            <div className="p-3 bg-stone-50 dark:bg-stone-900/60 rounded-xl border border-stone-200 dark:border-stone-800 space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-stone-800 dark:text-stone-200">
                <div className="flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5 text-[#8E1B25] dark:text-amber-400" />
                  <span>{t('addressFinder.matchingOffline')}</span>
                </div>
                <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-semibold bg-emerald-50 dark:bg-emerald-950/50 px-1.5 py-0.5 rounded border border-emerald-200 dark:border-emerald-900">
                  ⚡ {t('addressFinder.offlineAccessible')}
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {offlineMatches.map((rec) => (
                  <div
                    key={rec.id}
                    className="p-2.5 bg-white dark:bg-[#1E1714] rounded-lg border border-stone-200 dark:border-stone-700 text-xs flex flex-col justify-between gap-1 shadow-2xs"
                  >
                    <div>
                      <div className="font-bold text-stone-900 dark:text-stone-100 flex items-center justify-between">
                        <span className="truncate pr-1">{rec.village}</span>
                        <span className="font-mono text-[#8E1B25] dark:text-amber-400 font-bold bg-amber-50 dark:bg-amber-950/60 px-1.5 py-0.5 rounded shrink-0">
                          {rec.pincode}
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 dark:text-stone-400 truncate mt-0.5">
                        {rec.field2 ? `SO: ${rec.field2}` : ''} {rec.field3 ? `· HO: ${rec.field3}` : ''}
                      </p>
                    </div>
                    {onSelectPincode && rec.pincode && (
                      <button
                        onClick={() => {
                          onSelectPincode(rec.pincode);
                          onClose();
                        }}
                        className="mt-1 text-[11px] font-bold text-[#8E1B25] dark:text-amber-400 hover:underline flex items-center gap-1 self-start cursor-pointer"
                      >
                        <span>{t('addressFinder.filterInPlan')}</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {errorMessage && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200 rounded-xl border border-rose-200 dark:border-rose-900/60 text-xs sm:text-sm flex items-start gap-2">
              <RotateCcw className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold">{errorMessage}</p>
                <button
                  onClick={() => handleSearch()}
                  className="mt-1.5 text-xs font-bold underline hover:opacity-80 cursor-pointer"
                >
                  {t('common.retry')}
                </button>
              </div>
            </div>
          )}

          {isLoading && (
            <div className="py-10 text-center space-y-3">
              <div className="relative w-10 h-10 mx-auto">
                <div className="absolute inset-0 rounded-full border-4 border-amber-200 dark:border-amber-950/50" />
                <div className="absolute inset-0 rounded-full border-4 border-[#8E1B25] dark:border-amber-400 border-t-transparent animate-spin" />
              </div>
              <p className="text-xs text-stone-500 dark:text-stone-400">{t('addressFinder.lookingUp')}</p>
            </div>
          )}

          {/* Free API result */}
          {!isLoading && freeResult && (
            <div className="space-y-3 animate-fade-in">
              <div className="flex items-center justify-between gap-2 p-3 bg-sky-50/80 dark:bg-sky-950/30 border border-sky-200 dark:border-sky-900/50 rounded-xl">
                <div className="flex items-center gap-2">
                  <Building className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
                  <span className="text-xs font-semibold text-sky-900 dark:text-sky-200">
                    {t('addressFinder.directoryHeading', { pin: freeResult.pincode })}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  {onSelectPincode && (
                    <button
                      onClick={() => {
                        onSelectPincode(freeResult.pincode);
                        onShowToast?.(`Filtered sorting plan for PIN ${freeResult.pincode}`);
                        onClose();
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-[#8E1B25] dark:text-amber-400 bg-white dark:bg-stone-800 border border-amber-200 dark:border-amber-900/50 rounded-lg hover:bg-amber-50 dark:hover:bg-amber-950/50 transition-colors shadow-2xs cursor-pointer"
                      title="Filter main sorting plan for this PIN"
                    >
                      <span>{t('addressFinder.filterPin')}</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  )}
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1 px-2 py-1 text-xs font-semibold text-stone-700 dark:text-stone-300 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors shadow-2xs cursor-pointer"
                    title="Copy details"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? t('common.copied') : t('common.copy')}</span>
                  </button>
                </div>
              </div>

              <div className="p-4 bg-stone-50/80 dark:bg-stone-900/40 rounded-xl border border-stone-200 dark:border-stone-800 space-y-2 text-xs sm:text-sm">
                <p>
                  <strong>{t('addressFinder.districtState')}</strong> {freeResult.offices[0]?.district}, {freeResult.offices[0]?.state}
                </p>
                <p>
                  <strong>{t('addressFinder.division')}</strong> {freeResult.offices[0]?.division} &nbsp;|&nbsp; <strong>{t('addressFinder.region')}</strong> {freeResult.offices[0]?.region}
                </p>
                <div className="pt-1">
                  <p className="font-bold text-stone-800 dark:text-stone-200 mb-1">
                    {t('addressFinder.postOfficesUnder', { count: freeResult.offices.length })}
                  </p>
                  <ul className="space-y-0.5">
                    {freeResult.offices.map((o, i) => (
                      <li key={i} className="flex items-center gap-1.5">
                        <span className="text-[#8E1B25] dark:text-amber-400">•</span>
                        <span>{o.name} <span className="text-stone-400">({o.branchType})</span></span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* Initial guide / no-result-yet state */}
          {!isLoading && !freeResult && (!searchedOnce || offlineMatches.length === 0) && !errorMessage && (
            <div className="text-center py-8 px-4 space-y-3">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-50 dark:bg-stone-800 text-[#8E1B25] dark:text-amber-400 flex items-center justify-center">
                <MapPin className="w-6 h-6" />
              </div>
              <h4 className="text-sm sm:text-base font-bold text-stone-900 dark:text-stone-100">
                {t('addressFinder.searchPrompt')}
              </h4>
              <p className="text-xs text-stone-500 dark:text-stone-400 max-w-md mx-auto leading-relaxed">
                {t('addressFinder.searchPromptBody')}
              </p>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-stone-100 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50 flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="text-stone-400 text-[11px] min-w-0 truncate">
            {t('addressFinder.footerNote')}
          </span>

          <button
            onClick={onClose}
            className="shrink-0 px-4 py-2 font-bold text-stone-700 dark:text-stone-300 hover:bg-stone-200/60 dark:hover:bg-stone-800 rounded-lg transition-colors cursor-pointer"
          >
            {t('common.close')}
          </button>
        </div>

      </div>
    </div>
  );
};
