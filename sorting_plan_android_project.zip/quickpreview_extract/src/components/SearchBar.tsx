import React, { useRef, useEffect, useState } from 'react';
import { Search, X, Filter, Package, ArrowRight, Mic, Sparkles, Check, MapPin, Lightbulb } from 'lucide-react';
import { RawListMeta, PostalRecord } from '../data/types';
import { useVoiceSearch, VoiceLanguage } from '../hooks/useVoiceSearch';
import { useLanguage } from '../i18n/LanguageContext';

interface SearchBarProps {
  query: string;
  onQueryChange: (q: string) => void;
  suggestions?: PostalRecord[];
  suggestionsAreCorrections?: boolean;
  onSelectSuggestion?: (record: PostalRecord) => void;
  selectedList: string;
  onListChange: (listKey: string) => void;
  selectedField: string;
  onFieldChange: (field: string) => void;
  availableLists: RawListMeta[];
  popularPincodes: string[];
  activePincode: string;
  onSelectPincode: (pin: string) => void;
  totalFilteredCount: number;
  onOpenTrackingWithNumber?: (num: string) => void;
  onOpenAddressFinderWithQuery?: (q: string) => void;
  onShowToast?: (msg: string) => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  query,
  onQueryChange,
  suggestions = [],
  suggestionsAreCorrections = false,
  onSelectSuggestion,
  selectedList,
  onListChange,
  selectedField,
  onFieldChange,
  availableLists,
  popularPincodes,
  activePincode,
  onSelectPincode,
  totalFilteredCount,
  onOpenTrackingWithNumber,
  onOpenAddressFinderWithQuery,
  onShowToast
}) => {
  const { t } = useLanguage();
  const inputRef = useRef<HTMLInputElement>(null);
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [isInputFocused, setIsInputFocused] = useState(false);
  const [suggestionsDismissed, setSuggestionsDismissed] = useState(false);
  const [activeSuggestion, setActiveSuggestion] = useState(-1);
  const suggestionsBoxRef = useRef<HTMLDivElement>(null);

  // Initialize Voice Search Hook
  const {
    isSupported,
    isListening,
    interimTranscript,
    lang,
    setLang,
    startListening,
    stopListening
  } = useVoiceSearch({
    onTranscript: (cleanedText) => {
      onQueryChange(cleanedText);
      if (onShowToast) {
        onShowToast(`🎤 Voice input: "${cleanedText}"`);
      }
      inputRef.current?.focus();
    },
    onError: (errMsg) => {
      if (onShowToast) {
        onShowToast(errMsg);
      }
    }
  });

  // Keyboard shortcut '/' to focus search input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === '/' && document.activeElement !== inputRef.current) {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Close the suggestion dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        suggestionsBoxRef.current &&
        !suggestionsBoxRef.current.contains(e.target as Node) &&
        e.target !== inputRef.current
      ) {
        setIsInputFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Re-arm suggestions once the query changes again after a dismiss
  useEffect(() => {
    setSuggestionsDismissed(false);
    setActiveSuggestion(-1);
  }, [query, suggestions]);

  const hasFilters = query.length > 0 || selectedList !== '__all__' || selectedField !== 'all' || activePincode !== '';

  const handleResetFilters = () => {
    onQueryChange('');
    onListChange('__all__');
    onFieldChange('all');
    onSelectPincode('');
  };

  const handleToggleVoice = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  // Detect if user typed or pasted an India Post consignment number
  const trimmedUpper = query.trim().toUpperCase();
  const isConsignmentLike =
    /^[A-Z]{2}[0-9]{9}[A-Z]{2}$/.test(trimmedUpper) ||
    /^(EM|RN|ED|RT|CD|CP|CE|RL|RM|EU|EW|SP)[0-9]{5,}/.test(trimmedUpper);

  const showSuggestions =
    isInputFocused &&
    !suggestionsDismissed &&
    query.trim().length >= 2 &&
    suggestions.length > 0 &&
    !isConsignmentLike;

  return (
    <div className="bg-gradient-to-b from-[#8E1B25]/15 to-transparent pb-4 pt-3 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-3">
        
        {/* Main Search Input */}
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-5 h-5 text-[#8E1B25] dark:text-amber-400" />
          </div>

          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => onQueryChange(e.target.value)}
            onFocus={() => setIsInputFocused(true)}
            onKeyDown={(e) => {
              if (!showSuggestions) return;
              if (e.key === 'ArrowDown') {
                e.preventDefault();
                setActiveSuggestion((i) => (i + 1) % suggestions.length);
              } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                setActiveSuggestion((i) => (i <= 0 ? suggestions.length - 1 : i - 1));
              } else if (e.key === 'Enter' && activeSuggestion >= 0) {
                e.preventDefault();
                onSelectSuggestion?.(suggestions[activeSuggestion]);
                setSuggestionsDismissed(true);
              } else if (e.key === 'Escape') {
                setSuggestionsDismissed(true);
              }
            }}
            placeholder={t('search.placeholder')}
            className={`w-full pl-11 pr-32 py-3 sm:py-3.5 bg-white dark:bg-[#261C18] text-[#241A17] dark:text-[#F4ECE5] text-base sm:text-lg rounded-xl border shadow-sm focus:outline-none focus:ring-2 placeholder:text-stone-400 transition-all ${
              isListening
                ? 'border-rose-500 ring-2 ring-rose-400/50 dark:border-rose-500'
                : 'border-stone-200 dark:border-stone-800 focus:ring-[#8E1B25] dark:focus:ring-amber-500'
            }`}
            autoComplete="off"
            autoCorrect="off"
            spellCheck="false"
          />

          <div className="absolute inset-y-0 right-0 pr-2 flex items-center gap-1">
            {/* Clear Button */}
            {query && (
              <button
                type="button"
                onClick={() => onQueryChange('')}
                className="p-1.5 rounded-lg text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors cursor-pointer"
                title={t('search.clearInput')}
                aria-label={t('search.clearInput')}
              >
                <X className="w-4 h-4" />
              </button>
            )}

            {/* Voice Search Mic Button — hidden entirely when the platform has no
                Web Speech API (e.g. Android System WebView used by the packaged
                APK build), instead of showing a button that always errors on tap. */}
            {isSupported && (
            <div className="relative flex items-center">
              <button
                type="button"
                onClick={handleToggleVoice}
                className={`relative p-2 rounded-xl transition-all cursor-pointer flex items-center justify-center ${
                  isListening
                    ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30 scale-105'
                    : 'text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 active:scale-95'
                }`}
                title={
                  isListening
                    ? t('search.stopMic')
                    : t('search.voiceSearch')
                }
                aria-label={t('search.voiceSearch')}
              >
                {isListening ? (
                  <>
                    <Mic className="w-5 h-5 text-white animate-pulse" />
                    <span className="absolute -inset-1 rounded-xl bg-rose-500 opacity-40 animate-ping pointer-events-none" />
                  </>
                ) : (
                  <Mic className="w-5 h-5 text-[#8E1B25] dark:text-amber-400 hover:scale-110 transition-transform" />
                )}
              </button>

              {/* Language Selector Dropdown trigger */}
              <button
                type="button"
                onClick={() => setShowLangMenu(!showLangMenu)}
                className="hidden xs:flex items-center text-[10px] font-bold px-1.5 py-0.5 rounded bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-600 dark:text-stone-300 transition-colors ml-0.5 cursor-pointer"
                title="Switch voice recognition dialect: Indian English / Hindi"
              >
                {lang === 'hi-IN' ? 'HI' : 'EN'}
              </button>

              {/* Language Switcher Popup */}
              {showLangMenu && (
                <div className="absolute right-0 top-full mt-2 w-44 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-xl shadow-xl p-1 z-30 animate-fade-in text-xs">
                  <div className="px-2 py-1 text-[10px] font-semibold text-stone-400 uppercase tracking-wider">
                    Voice Recognition
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setLang('en-IN');
                      setShowLangMenu(false);
                      if (onShowToast) onShowToast('Voice language set to Indian English');
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left font-medium transition-colors cursor-pointer ${
                      lang === 'en-IN'
                        ? 'bg-[#8E1B25]/10 text-[#8E1B25] dark:text-amber-300 font-bold'
                        : 'text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'
                    }`}
                  >
                    <span>English (India)</span>
                    {lang === 'en-IN' && <Check className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setLang('hi-IN');
                      setShowLangMenu(false);
                      if (onShowToast) onShowToast('Voice language set to Hindi recognition');
                    }}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg text-left font-medium transition-colors cursor-pointer ${
                      lang === 'hi-IN'
                        ? 'bg-[#8E1B25]/10 text-[#8E1B25] dark:text-amber-300 font-bold'
                        : 'text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800'
                    }`}
                  >
                    <span>Hindi (India)</span>
                    {lang === 'hi-IN' && <Check className="w-3.5 h-3.5" />}
                  </button>
                </div>
              )}
            </div>
            )}

            {/* Keyboard shortcut hint */}
            <kbd className="hidden md:inline-flex items-center gap-0.5 px-2 py-0.5 text-[11px] font-mono text-stone-400 bg-stone-100 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded ml-1">
              /
            </kbd>
          </div>

          {/* Autocomplete / "did you mean" suggestion dropdown — helps the
              user pick the exact spelling as they type, and surfaces a
              typo-corrected match (via the same fuzzy/phonetic search used
              for the main results) instead of them having to guess. */}
          {showSuggestions && (
            <div
              ref={suggestionsBoxRef}
              className="absolute left-0 right-0 top-full mt-1.5 bg-white dark:bg-[#1E1714] border border-stone-200 dark:border-stone-700 rounded-xl shadow-xl z-30 overflow-hidden animate-fade-in"
            >
              <div className="flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-bold text-stone-500 dark:text-stone-400 bg-stone-50 dark:bg-stone-900/60 border-b border-stone-100 dark:border-stone-800">
                <Lightbulb className="w-3 h-3 text-amber-500 shrink-0" />
                <span>{suggestionsAreCorrections ? t('search.didYouMean') : t('search.suggestionsLabel')}</span>
              </div>
              <ul className="max-h-72 overflow-y-auto">
                {suggestions.map((rec, idx) => (
                  <li key={rec.id}>
                    <button
                      type="button"
                      onMouseDown={(e) => {
                        // onMouseDown (not onClick) so this fires before the
                        // input's onBlur closes the dropdown.
                        e.preventDefault();
                        onSelectSuggestion?.(rec);
                        setSuggestionsDismissed(true);
                        setIsInputFocused(false);
                      }}
                      className={`w-full flex items-center justify-between gap-2 px-3 py-2 text-left hover:bg-amber-50 dark:hover:bg-amber-950/30 transition-colors cursor-pointer border-b border-stone-50 dark:border-stone-800/60 last:border-b-0 ${idx === activeSuggestion ? 'bg-amber-50 dark:bg-amber-950/30' : ''}`}
                    >
                      <span className="min-w-0">
                        <span className="block text-sm font-semibold text-stone-900 dark:text-stone-100 truncate">
                          {rec.village}
                        </span>
                        <span className="block text-[11px] text-stone-500 dark:text-stone-400 truncate">
                          {rec.field1}{rec.field2 ? ` · ${rec.field2}` : ''}
                        </span>
                      </span>
                      <span className="shrink-0 font-mono text-xs font-bold text-[#8E1B25] dark:text-amber-400 bg-amber-50 dark:bg-amber-950/50 px-1.5 py-0.5 rounded">
                        {rec.pincode}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Live Listening Floating Banner */}
        {isListening && (
          <div className="flex items-center justify-between gap-3 p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-xl text-rose-900 dark:text-rose-200 shadow-sm animate-fade-in">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-3 h-3 rounded-full bg-rose-600 animate-ping shrink-0" />
              <div className="min-w-0 text-xs sm:text-sm">
                <span className="font-bold">{t('search.listening')}</span>{' '}
                <span className="opacity-80 text-xs">
                  {interimTranscript ? (
                    <strong className="text-rose-700 dark:text-rose-300 font-medium font-mono">
                      "{interimTranscript}"
                    </strong>
                  ) : (
                    `(e.g., 'Sanwer', 'Dewas', 'Depalpur', '453551')`
                  )}
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={stopListening}
              className="px-2.5 py-1 text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-lg shadow-xs shrink-0 cursor-pointer"
            >
              Stop
            </button>
          </div>
        )}

        {/* Fuzzy / Phonetic Search Feature Badge */}
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5 text-stone-500 dark:text-stone-400">
            <Sparkles className="w-3.5 h-3.5 text-[#F2B705] shrink-0" />
            <span className="text-[11px]">
              <strong>Fuzzy &amp; Phonetic Matching:</strong> Typing 'sanwar' automatically matches 'Sanwer' (Voice &amp; multi-dialect enabled).
            </span>
          </div>
        </div>

        {/* Consignment Quick Detection Notification */}
        {isConsignmentLike && onOpenTrackingWithNumber && (
          <div className="flex items-center justify-between gap-2 p-2.5 bg-[#8E1B25]/10 dark:bg-[#8E1B25]/25 border border-[#8E1B25]/30 rounded-xl text-xs text-[#8E1B25] dark:text-amber-300 animate-fade-in">
            <div className="flex items-center gap-2">
              <Package className="w-4 h-4 shrink-0 text-[#8E1B25] dark:text-amber-400" />
              <span>
                Consignment barcode detected: <strong className="font-mono">{trimmedUpper}</strong>
              </span>
            </div>
            <button
              onClick={() => onOpenTrackingWithNumber(trimmedUpper)}
              className="flex items-center gap-1 px-3 py-1 font-bold text-xs bg-[#8E1B25] hover:bg-[#6F151C] text-white rounded-lg shadow-xs transition-colors shrink-0 cursor-pointer"
            >
              <span>{t('search.trackOnIndiaPost')}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Pincode & Address Finder Quick Prompt */}
        {query.trim().length >= 2 && !isConsignmentLike && onOpenAddressFinderWithQuery && (
          <div className="flex items-center justify-between gap-2 p-2 px-3 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/50 rounded-xl text-xs text-emerald-900 dark:text-emerald-200 animate-fade-in">
            <div className="flex items-center gap-2 min-w-0">
              <MapPin className="w-4 h-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
              <span className="truncate">
                {totalFilteredCount === 0
                  ? t('search.noOfflineMatch', { query: query.trim() })
                  : t('search.lookupPinDirectory', { query: query.trim() })}
              </span>
            </div>
            <button
              onClick={() => onOpenAddressFinderWithQuery(query.trim())}
              className="flex items-center gap-1 px-2.5 py-1 font-bold text-xs bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg shadow-2xs transition-colors shrink-0 cursor-pointer"
            >
              <span>{t('search.findAddressBtn')}</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        )}

        {/* Filters and Dropdowns Row */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          {/* Division Selector */}
          <div className="relative flex-1 min-w-[180px]">
            <select
              value={selectedList}
              onChange={(e) => onListChange(e.target.value)}
              className="w-full appearance-none pl-3 pr-8 py-2 bg-white dark:bg-[#261C18] text-xs sm:text-sm font-semibold text-stone-800 dark:text-stone-200 rounded-lg border border-stone-200 dark:border-stone-800 shadow-xs focus:outline-none focus:border-[#8E1B25]"
            >
              <option value="__all__">{t('app.allDivisions')}</option>
              {availableLists.map((l) => (
                <option key={l.key} value={l.key}>
                  {l.name} ({l.count.toLocaleString()})
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2.5 text-stone-500">
              <span className="border-b-2 border-r-2 border-current w-1.5 h-1.5 transform rotate-45 -translate-y-0.5" />
            </div>
          </div>

          {/* Field Scope Selector */}
          <div className="relative w-[150px] sm:w-[170px]">
            <select
              value={selectedField}
              onChange={(e) => onFieldChange(e.target.value)}
              className="w-full appearance-none pl-3 pr-8 py-2 bg-white dark:bg-[#261C18] text-xs sm:text-sm font-medium text-stone-700 dark:text-stone-300 rounded-lg border border-stone-200 dark:border-stone-800 shadow-xs focus:outline-none focus:border-[#8E1B25]"
            >
              <option value="all">{t('search.filterAll')}</option>
              <option value="v">{t('search.filterVillage')}</option>
              <option value="p">{t('search.filterPincode')}</option>
              <option value="f1">{t('search.filterBo')}</option>
              <option value="f2">{t('search.filterSo')}</option>
              <option value="f3">{t('search.filterHo')}</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2.5 text-stone-500">
              <span className="border-b-2 border-r-2 border-current w-1.5 h-1.5 transform rotate-45 -translate-y-0.5" />
            </div>
          </div>

          {/* Reset Filters chip */}
          {hasFilters && (
            <button
              onClick={handleResetFilters}
              className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold text-rose-700 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 rounded-lg transition-colors border border-rose-200 dark:border-rose-900 cursor-pointer"
            >
              <Filter className="w-3 h-3" />
              <span>Reset</span>
            </button>
          )}

          <div className="text-xs text-stone-500 dark:text-stone-400 ml-auto whitespace-nowrap font-mono tabular-nums">
            {totalFilteredCount.toLocaleString()} {totalFilteredCount === 1 ? 'match' : 'matches'}
          </div>
        </div>

        {/* Popular Pincode Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-1 no-scrollbar text-xs">
          <span className="text-stone-500 dark:text-stone-400 font-medium shrink-0 pr-1">
            Quick PIN:
          </span>
          {popularPincodes.map((pin) => {
            const isSelected = activePincode === pin;
            return (
              <button
                key={pin}
                onClick={() => onSelectPincode(isSelected ? '' : pin)}
                className={`px-2.5 py-1 rounded-md font-mono text-xs font-semibold transition-colors shrink-0 cursor-pointer ${
                  isSelected
                    ? 'bg-[#8E1B25] text-white shadow-xs'
                    : 'bg-stone-200/70 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-300 dark:hover:bg-stone-700'
                }`}
              >
                {pin}
              </button>
            );
          })}
        </div>

      </div>
    </div>
  );
};
