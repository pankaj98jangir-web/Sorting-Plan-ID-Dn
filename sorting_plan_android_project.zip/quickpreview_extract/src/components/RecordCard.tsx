import React, { useState } from 'react';
import { Bookmark, Copy, Check, MapPin, Building2, Landmark, Navigation } from 'lucide-react';
import { PostalRecord } from '../data/types';
import { getPhoneticSkeleton, levenshteinDistance, prepareQuery } from '../utils/postalSearch';
import { useLanguage } from '../i18n/LanguageContext';

interface RecordCardProps {
  record: PostalRecord;
  query: string;
  isBookmarked: boolean;
  onToggleBookmark: (id: string) => void;
  onOpenAddressFinder?: (record: PostalRecord) => void;
  onViewOfficeVillages?: (officeName: string) => void;
}

export const RecordCard: React.FC<RecordCardProps> = ({
  record,
  query,
  isBookmarked,
  onToggleBookmark,
  onOpenAddressFinder,
  onViewOfficeVillages
}) => {
  const [copied, setCopied] = useState(false);
  const { t } = useLanguage();

  // Helper to highlight matching text with fuzzy & phonetic support
  const highlightMatch = (text: string, q: string) => {
    const trimmed = q.trim();
    if (!trimmed || !text) return text;

    // 1. Direct exact substring match
    if (text.toLowerCase().includes(trimmed.toLowerCase())) {
      const parts = text.split(new RegExp(`(${trimmed.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi'));
      return parts.map((part, i) =>
        part.toLowerCase() === trimmed.toLowerCase() ? (
          <mark key={i} className="bg-[#F2B705]/45 text-stone-900 dark:text-amber-200 rounded-xs px-0.5 font-bold">
            {part}
          </mark>
        ) : (
          part
        )
      );
    }

    // 2. Token / Fuzzy / Phonetic word-level highlight
    const prep = prepareQuery(trimmed);
    const wordsAndDelims = text.split(/(\s+|[.,/\\_-]+)/);

    return wordsAndDelims.map((item, idx) => {
      const cleanWord = item.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (!cleanWord) return item;

      let isMatch = false;
      const wordSkel = getPhoneticSkeleton(cleanWord);

      for (const tok of prep.tokens) {
        if (!tok.text) continue;
        // Exact
        if (cleanWord === tok.text || cleanWord.startsWith(tok.text)) {
          isMatch = true;
          break;
        }
        // Phonetic Skeleton
        if (tok.skeleton && tok.skeleton.length >= 3 && wordSkel === tok.skeleton) {
          isMatch = true;
          break;
        }
        // Fuzzy Levenshtein
        if (tok.text.length >= 4 && Math.abs(cleanWord.length - tok.text.length) <= 2) {
          if (levenshteinDistance(cleanWord, tok.text) <= 1) {
            isMatch = true;
            break;
          }
        }
      }

      if (isMatch) {
        return (
          <mark
            key={idx}
            className="bg-[#F2B705]/45 text-stone-900 dark:text-amber-200 rounded-xs px-0.5 font-bold"
            title="Matched phonetically / fuzzy"
          >
            {item}
          </mark>
        );
      }
      return item;
    });
  };

  const isTd = record.type === 'td';
  const labels = isTd
    ? {
        v: 'Delivery Area / Locality',
        p: 'Pincode',
        f1: t('card.houseNoLocality'),
        f2: t('card.beatNumber'),
        f3: t('card.deliveryOffice')
      }
    : {
        v: 'Village / Town',
        p: 'Pincode',
        f1: t('card.branchOffice'),
        f2: t('card.subOffice'),
        f3: t('card.headOffice')
      };

  const handleCopy = () => {
    const slipText = isTd
      ? `${record.village}\nPIN: ${record.pincode}\nBeat: ${record.field2}\nOffice: ${record.field3} (${record.listName})`
      : `${record.village}\nPIN: ${record.pincode}\nB.O: ${record.field1}\nS.O: ${record.field2}\nH.O: ${record.field3} (${record.listName})`;

    navigator.clipboard.writeText(slipText).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <article className="group bg-white dark:bg-[#261C18] border border-stone-200 dark:border-stone-800 rounded-xl p-4 shadow-xs hover:shadow-md transition-shadow">
      
      {/* Top Header Row */}
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-0.5 min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            <h3 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100 tracking-tight leading-snug break-words">
              {highlightMatch(record.village, query)}
            </h3>
            {record.pincode && (
              <span className="font-mono text-xs sm:text-sm font-semibold text-[#8E1B25] dark:text-amber-400 bg-amber-50/80 dark:bg-amber-950/30 px-2 py-0.5 rounded-md border border-amber-200 dark:border-amber-900/60 tabular-nums">
                {highlightMatch(record.pincode, query)}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 text-xs text-stone-500 dark:text-stone-400">
            <span>{record.listName}</span>
            <span aria-hidden="true">·</span>
            <span>{isTd ? t('card.cityDeliveryBeat') : t('card.mofussilSorting')}</span>
          </div>
        </div>

        {/* Card Actions: Address Finder, Bookmark & Copy */}
        <div className="flex items-center gap-1 shrink-0">
          {onOpenAddressFinder && (
            <button
              onClick={() => onOpenAddressFinder(record)}
              className="p-1.5 rounded-lg text-emerald-600 dark:text-emerald-400 hover:text-emerald-800 dark:hover:text-emerald-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/50 transition-colors"
              title="Look up this PIN code in the Address Finder"
              aria-label="Open Address Finder"
            >
              <Navigation className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={() => onToggleBookmark(record.id)}
            className={`p-1.5 rounded-lg transition-colors ${
              isBookmarked
                ? 'text-[#8E1B25] dark:text-amber-400 bg-amber-50 dark:bg-amber-950/50'
                : 'text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800'
            }`}
            title={isBookmarked ? "Remove bookmark" : "Pin/Bookmark office"}
            aria-label="Bookmark office"
          >
            <Bookmark className={`w-4 h-4 ${isBookmarked ? 'fill-current' : ''}`} />
          </button>

          <button
            onClick={handleCopy}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
            title="Copy sorting slip text"
            aria-label="Copy sorting details"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Grid of Postal Routing Fields */}
      <div className="mt-3.5 pt-3 border-t border-stone-100 dark:border-stone-800/80 grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3 text-xs">
        
        {/* Field 1: Branch Office / House No */}
        <div className="space-y-0.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-stone-400 dark:text-stone-500 flex items-center gap-1">
              <MapPin className="w-3 h-3 text-stone-400" />
              {labels.f1}
            </span>
            {onViewOfficeVillages && record.field1 && record.field1 !== '-' && (
              <button
                type="button"
                onClick={() => onViewOfficeVillages(record.field1)}
                className="text-[10px] font-semibold text-[#8E1B25] dark:text-amber-400 hover:underline cursor-pointer"
                title={`View all villages under ${record.field1}`}
              >
                Villages &rarr;
              </button>
            )}
          </div>
          <p className="font-medium text-stone-800 dark:text-stone-200 break-words leading-relaxed">
            {record.field1 ? highlightMatch(record.field1, query) : <span className="text-stone-300 dark:text-stone-600">—</span>}
          </p>
        </div>

        {/* Field 2: Sub Office / Beat Number */}
        <div className="space-y-0.5">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-stone-400 dark:text-stone-500 flex items-center gap-1">
              <Building2 className="w-3 h-3 text-stone-400" />
              {labels.f2}
            </span>
            {onViewOfficeVillages && record.field2 && record.field2 !== '-' && (
              <button
                type="button"
                onClick={() => onViewOfficeVillages(record.field2)}
                className="text-[10px] font-semibold text-[#8E1B25] dark:text-amber-400 hover:underline cursor-pointer"
                title={`View all villages under ${record.field2}`}
              >
                Villages &rarr;
              </button>
            )}
          </div>
          <p className="font-medium text-stone-800 dark:text-stone-200 break-words leading-relaxed">
            {record.field2 ? highlightMatch(record.field2, query) : <span className="text-stone-300 dark:text-stone-600">—</span>}
          </p>
        </div>

        {/* Field 3: Head Office / Delivery Office */}
        <div className="space-y-0.5">
          <span className="text-[11px] font-semibold text-stone-400 dark:text-stone-500 flex items-center gap-1">
            <Landmark className="w-3 h-3 text-stone-400" />
            {labels.f3}
          </span>
          <p className="font-medium text-stone-800 dark:text-stone-200 break-words leading-relaxed">
            {record.field3 ? highlightMatch(record.field3, query) : <span className="text-stone-300 dark:text-stone-600">—</span>}
          </p>
        </div>

      </div>

    </article>
  );
};
