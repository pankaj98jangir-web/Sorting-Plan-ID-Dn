import React from 'react';
import { Bookmark, Plus, Settings, Sun, Moon, Printer, Download, Package, MapPin, Building2, Languages } from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { useLanguage } from '../i18n/LanguageContext';
import indiaPostLogo from '../assets/india-post-logo.svg';

interface HeaderProps {
  totalRecordsCount: number;
  activeListsCount: number;
  bookmarkedCount: number;
  showOnlyBookmarks: boolean;
  onToggleBookmarks: () => void;
  onOpenAddList: () => void;
  onOpenManageLists: () => void;
  onOpenTracking: () => void;
  onOpenAddressFinder: () => void;
  onOpenOfficeDirectory?: () => void;
  onOpenWelcome?: () => void;
  onExportCsv: () => void;
  onPrint: () => void;
  isDark: boolean;
  onToggleDark: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  totalRecordsCount,
  activeListsCount,
  bookmarkedCount,
  showOnlyBookmarks,
  onToggleBookmarks,
  onOpenAddList,
  onOpenManageLists,
  onOpenTracking,
  onOpenAddressFinder,
  onOpenOfficeDirectory,
  onOpenWelcome,
  onExportCsv,
  onPrint,
  isDark,
  onToggleDark
}) => {
  const isOnline = useOnlineStatus();
  const { lang, toggleLang, t } = useLanguage();

  return (
    <header className="sticky top-0 z-30 bg-gradient-to-r from-[#8E1B25] to-[#A3222C] text-white shadow-md border-b border-[#6F151C]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5 sm:py-3">
        <div className="flex items-center justify-between gap-2 sm:gap-3">
          
          {/* Brand Zone with Official India Post Logo */}
          <button
            onClick={onOpenWelcome}
            className="flex items-center gap-2.5 sm:gap-3 min-w-0 text-left cursor-pointer group"
            title={t('header.brandTitle')}
          >
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-white p-1 shadow-sm flex items-center justify-center shrink-0 border border-amber-200/50 group-hover:scale-105 transition-transform overflow-hidden">
              <img
                src={indiaPostLogo}
                alt="India Post Logo"
                className="w-full h-full object-contain"
              />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <span className="text-base sm:text-xl font-bold tracking-tight text-white truncate group-hover:text-amber-200 transition-colors">
                  SORTING PLAN - ID Dn INDORE
                </span>
                <span className="text-[10px] sm:text-[11px] font-semibold uppercase tracking-wider bg-white/20 px-1.5 sm:px-2 py-0.5 rounded text-amber-200 shrink-0 border border-white/10">
                  India Post
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-white/80 truncate">
                {t('header.statsLine', { lists: activeListsCount, offices: totalRecordsCount.toLocaleString() })}
              </p>
            </div>
          </button>

          {/* Action Zone — horizontally scrollable (not wrapped) on narrow
              screens so this many buttons never get squeezed or pushed
              outside the viewport; hidden scrollbar keeps it looking like a
              normal toolbar while still being fully reachable via swipe. */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 overflow-x-auto no-scrollbar max-w-full">

            {/* Pincode & Address Finder Button */}
            <button
              onClick={onOpenAddressFinder}
              className="shrink-0 flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-400 text-stone-900 hover:bg-amber-300 shadow-sm transition-transform active:scale-95 cursor-pointer"
              title={t('header.findAddressTitle')}
              aria-label={t('header.findAddress')}
            >
              <MapPin className="w-3.5 h-3.5 text-[#8E1B25]" />
              <span className="hidden sm:inline">{t('header.findAddress')}</span>
              <span className="sm:hidden">{t('header.findAddressShort')}</span>
            </button>

            {/* Office Beat Directory Button */}
            {onOpenOfficeDirectory && (
              <button
                onClick={onOpenOfficeDirectory}
                className="shrink-0 flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-bold bg-white/15 hover:bg-white/25 text-white shadow-sm transition-transform active:scale-95 cursor-pointer"
                title={t('header.officeDirectoryTitle')}
                aria-label={t('header.officeDirectory')}
              >
                <Building2 className="w-3.5 h-3.5 text-amber-300" />
                <span className="hidden md:inline">{t('header.officeDirectory')}</span>
                <span className="md:hidden">{t('header.officeDirectoryShort')}</span>
              </button>
            )}

            {/* Article Tracking Button */}
            <button
              onClick={onOpenTracking}
              className="shrink-0 flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-bold bg-white text-[#8E1B25] hover:bg-stone-100 shadow-sm transition-transform active:scale-95 cursor-pointer"
              title={t('header.trackArticleTitle')}
              aria-label={t('header.trackArticle')}
            >
              <Package className="w-3.5 h-3.5 text-[#8E1B25]" />
              <span className="hidden xs:inline">{t('header.trackArticle')}</span>
              <span className="xs:hidden">{t('header.trackArticleShort')}</span>
              <span
                className={`w-2 h-2 rounded-full shrink-0 ${isOnline ? 'bg-emerald-500' : 'bg-amber-400'}`}
                title={isOnline ? t('header.onlineLiveTracking') : t('header.offlineNeedInternet')}
              />
            </button>

            {/* PWA Install Button */}
            <PWAInstallButton />

            {/* Bookmarks Toggle */}
            <button
              onClick={onToggleBookmarks}
              className={`shrink-0 flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                showOnlyBookmarks
                  ? 'bg-[#F2B705] text-[#241A17] shadow-sm'
                  : 'bg-white/10 hover:bg-white/20 text-white'
              }`}
              title={t('header.pinnedTitle')}
              aria-label={t('header.pinned')}
            >
              <Bookmark className={`w-3.5 h-3.5 ${showOnlyBookmarks ? 'fill-current' : ''}`} />
              <span className="hidden md:inline">{t('header.pinned')}</span>
              {bookmarkedCount > 0 && (
                <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-black/20">
                  {bookmarkedCount}
                </span>
              )}
            </button>

            {/* Export CSV */}
            <button
              onClick={onExportCsv}
              className="shrink-0 hidden lg:flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-white/10 hover:bg-white/20 text-white transition-colors"
              title={t('header.exportTitle')}
              aria-label={t('header.export')}
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t('header.export')}</span>
            </button>

            {/* Print Guide */}
            <button
              onClick={onPrint}
              className="shrink-0 hidden xl:flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium bg-white/10 hover:bg-white/20 text-white transition-colors"
              title={t('header.printTitle')}
              aria-label={t('header.print')}
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{t('header.print')}</span>
            </button>

            {/* Add / Upload List Button */}
            <button
              onClick={onOpenAddList}
              className="shrink-0 flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs font-bold bg-[#F2B705] hover:bg-[#D99E00] text-[#241A17] shadow-sm transition-transform active:scale-95 cursor-pointer"
              title={t('header.addListTitle')}
              aria-label={t('header.addList')}
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span className="hidden xs:inline">{t('header.addList')}</span>
              <span className="xs:hidden">{t('header.addListShort')}</span>
            </button>

            {/* Manage Lists Modal Toggle */}
            <button
              onClick={onOpenManageLists}
              className="shrink-0 p-1.5 rounded-lg text-white/90 hover:text-white bg-white/10 hover:bg-white/20 transition-colors cursor-pointer"
              title={t('header.manageListsTitle')}
              aria-label={t('header.manageListsTitle')}
            >
              <Settings className="w-4 h-4" />
            </button>

            {/* Language Toggle (English / Hindi) — app UI only, never the
                embedded postal data itself */}
            <button
              onClick={toggleLang}
              className="shrink-0 flex items-center gap-1 px-2 py-1.5 rounded-lg text-xs font-bold text-white/90 hover:text-white bg-white/10 hover:bg-white/20 transition-colors cursor-pointer"
              title={t('header.languageTitle')}
              aria-label={t('header.language')}
            >
              <Languages className="w-4 h-4" />
              <span className="hidden sm:inline">{lang === 'en' ? 'EN' : 'हिं'}</span>
            </button>

            {/* Theme Toggle */}
            <button
              onClick={onToggleDark}
              className="shrink-0 p-1.5 rounded-lg text-white/90 hover:text-white bg-white/10 hover:bg-white/20 transition-colors cursor-pointer"
              title={isDark ? t('header.lightMode') : t('header.darkMode')}
              aria-label={isDark ? t('header.lightMode') : t('header.darkMode')}
            >
              {isDark ? <Sun className="w-4 h-4 text-amber-300" /> : <Moon className="w-4 h-4" />}
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
