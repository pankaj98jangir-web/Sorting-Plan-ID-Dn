import React from 'react';
import { X, HelpCircle, Building, MapPin, Truck } from 'lucide-react';
import { useModalBackButton } from '../hooks/useModalBackButton';
import indiaPostLogo from '../assets/india-post-logo.svg';

interface PostalHelperProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PostalHelper: React.FC<PostalHelperProps> = ({ isOpen, onClose }) => {
  useModalBackButton(isOpen, onClose);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
      <div className="bg-white dark:bg-[#261C18] text-stone-900 dark:text-stone-100 rounded-2xl w-full max-w-lg shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-stone-100 dark:border-stone-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-white p-0.5 shadow-2xs border border-stone-200 dark:border-stone-700 flex items-center justify-center overflow-hidden">
              <img src={indiaPostLogo} alt="India Post" className="w-full h-full object-contain" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold">Sorting Plan Guide</h2>
              <p className="text-[11px] text-stone-500 dark:text-stone-400">India Post · Indore Postal Region</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs sm:text-sm leading-relaxed">
          <div className="bg-amber-50 dark:bg-amber-950/30 p-3.5 rounded-xl border border-amber-200 dark:border-amber-900/50">
            <h3 className="font-bold text-amber-900 dark:text-amber-200 mb-1">
              About this Sorting Plan (Indore Postal Region)
            </h3>
            <p className="text-amber-800/90 dark:text-amber-300/90 text-xs">
              This lookup application assists sorting assistants and postal operators in quickly routing letters, parcels, and speed posts to the correct Branch Post Office (B.O), Sub Post Office (S.O), and Head Post Office (H.O), or city delivery beats.
            </p>
          </div>

          <div className="space-y-3">
            <div className="flex items-start gap-2.5">
              <div className="p-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 shrink-0">
                <MapPin className="w-4 h-4 text-[#8E1B25] dark:text-amber-400" />
              </div>
              <div>
                <h4 className="font-bold text-stone-900 dark:text-stone-100 text-xs sm:text-sm">B.O (Branch Office)</h4>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  Operates at the village or rural panchayat level under an account Sub-Office (S.O).
                </p>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <div className="p-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 shrink-0">
                <Building className="w-4 h-4 text-[#8E1B25] dark:text-amber-400" />
              </div>
              <div>
                <h4 className="font-bold text-stone-900 dark:text-stone-100 text-xs sm:text-sm">S.O (Sub Office / Account Office)</h4>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  Major town or tehsil-level office that manages mail dispatch and accounts for its branch offices.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-2.5">
              <div className="p-1.5 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 shrink-0">
                <Truck className="w-4 h-4 text-[#8E1B25] dark:text-amber-400" />
              </div>
              <div>
                <h4 className="font-bold text-stone-900 dark:text-stone-100 text-xs sm:text-sm">H.O (Head Office / GPO)</h4>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  Principal accounts and sorting hub of the postal division (e.g., Indore GPO, Ujjain HO, Mandsaur HO).
                </p>
              </div>
            </div>

            <div className="pt-2 border-t border-stone-100 dark:border-stone-800">
              <h4 className="font-bold text-stone-900 dark:text-stone-100 text-xs sm:text-sm mb-1">
                PIN Code Structure (e.g. 452001)
              </h4>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                <strong>4</strong>: Western Region (MP &amp; Chhattisgarh, Gujarat, Maharashtra) · <strong>45</strong>: Indore &amp; Malwa sub-region · <strong>2</strong>: Sorting district · <strong>001</strong>: Specific delivery post office.
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-stone-100 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-white bg-[#8E1B25] hover:bg-[#6F151C] rounded-lg transition-colors"
          >
            Got it
          </button>
        </div>

      </div>
    </div>
  );
};
