import React, { useEffect } from 'react';
import { X, ScanLine, AlertTriangle } from 'lucide-react';
import { useBarcodeScanner } from '../hooks/useBarcodeScanner';
import { useModalBackButton } from '../hooks/useModalBackButton';

interface BarcodeScannerOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (value: string) => void;
}

export const BarcodeScannerOverlay: React.FC<BarcodeScannerOverlayProps> = ({
  isOpen,
  onClose,
  onScan
}) => {
  const { isSupported, isScanning, error, videoRef, start, stop } = useBarcodeScanner((value) => {
    onScan(value);
    onClose();
  });

  useModalBackButton(isOpen, onClose);

  useEffect(() => {
    if (isOpen) {
      start();
    } else {
      stop();
    }
    return () => stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/90 p-4 animate-fade-in no-print">
      <button
        type="button"
        onClick={onClose}
        className="absolute right-4 p-2 rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors cursor-pointer"
        style={{ top: 'calc(env(safe-area-inset-top, 0px) + 1rem)' }}
        aria-label="Close scanner"
      >
        <X className="w-5 h-5" />
      </button>

      <div className="w-full max-w-sm">
        <div className="relative rounded-2xl overflow-hidden border-2 border-white/30 aspect-square bg-black">
          {/* The video element stays mounted whenever the overlay is open so
              the scanner hook always has a target to attach the camera
              stream to, per its usage contract. */}
          <video ref={videoRef} className="w-full h-full object-cover" muted playsInline />

          {isScanning && (
            <div className="absolute inset-6 border-2 border-amber-400 rounded-xl pointer-events-none">
              <div className="absolute left-0 right-0 top-1/2 h-0.5 bg-amber-400/80 animate-pulse" />
            </div>
          )}
        </div>

        <div className="mt-4 text-center text-white text-xs sm:text-sm min-h-[1.5rem]">
          {error ? (
            <p className="flex items-center justify-center gap-1.5 text-rose-300 font-medium">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              {error}
            </p>
          ) : !isSupported ? (
            <p className="text-rose-300 font-medium">
              Barcode scanning is not supported on this device/browser.
            </p>
          ) : (
            <p className="flex items-center justify-center gap-1.5 opacity-90">
              <ScanLine className="w-4 h-4" />
              Point the camera at the barcode / QR code on the label
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
