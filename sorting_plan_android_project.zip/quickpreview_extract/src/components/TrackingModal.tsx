import React, { useState } from 'react';
import {
  X,
  Search,
  ExternalLink,
  Wifi,
  WifiOff,
  Clock,
  Trash2,
  Package,
  CheckCircle2,
  Copy,
  ScanLine
} from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { useModalBackButton } from '../hooks/useModalBackButton';
import { isBarcodeScanningSupported, scanBarcodeNative } from '../hooks/useBarcodeScanner';
import { isNativeApp } from '../utils/native';
import { BarcodeScannerOverlay } from './BarcodeScannerOverlay';
import indiaPostLogo from '../assets/india-post-logo.svg';
import { useLanguage } from '../i18n/LanguageContext';

const LS_RECENT_TRACKS = 'sp_recent_trackings_v1';

interface TrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShowToast?: (msg: string) => void;
}

interface RecentTrackItem {
  id: string;
  timestamp: number;
}

export const TrackingModal: React.FC<TrackingModalProps> = ({ isOpen, onClose, onShowToast }) => {
  const { t } = useLanguage();
  const isOnline = useOnlineStatus();
  const [consignmentNumber, setConsignmentNumber] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [copied, setCopied] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const scannerSupported = isBarcodeScanningSupported();
  const [recentTracks, setRecentTracks] = useState<RecentTrackItem[]>(() => {
    try {
      const saved = localStorage.getItem(LS_RECENT_TRACKS);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useModalBackButton(isOpen, onClose);

  if (!isOpen) return null;

  const cleanConsignment = consignmentNumber.trim().toUpperCase();

  const validateConsignment = (val: string) => {
    const trimmed = val.trim().toUpperCase();
    // Standard India Post 13 chars: 2 letters, 9 digits, 2 letters (e.g., EM123456789IN)
    // or alphanumeric tracking numbers between 8 and 18 chars
    const regex = /^[A-Z0-9]{8,18}$/;
    return regex.test(trimmed);
  };

  const handleCopyAndSave = (id?: string) => {
    const idToTrack = (id || cleanConsignment);
    if (!idToTrack) {
      setErrorMsg(t('tracking.enterNumber'));
      return false;
    }

    if (!validateConsignment(idToTrack)) {
      setErrorMsg('Invalid article number format. India Post tracking numbers typically contain 13 characters (e.g. EM123456789IN).');
      return false;
    }

    setErrorMsg('');

    // Save to recents
    const filtered = recentTracks.filter((x) => x.id !== idToTrack);
    const updated = [{ id: idToTrack, timestamp: Date.now() }, ...filtered].slice(0, 10);
    setRecentTracks(updated);
    try {
      localStorage.setItem(LS_RECENT_TRACKS, JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }

    // Copy to clipboard
    if (navigator.clipboard) {
      navigator.clipboard.writeText(idToTrack).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 3000);
        if (onShowToast) {
          onShowToast(`Consignment ${idToTrack} copied to clipboard!`);
        }
      });
    }

    return true;
  };

  const handleClearRecents = () => {
    setRecentTracks([]);
    try {
      localStorage.removeItem(LS_RECENT_TRACKS);
    } catch (e) {
      console.error(e);
    }
  };

  const officialTrackingUrl = `https://www.indiapost.gov.in/_layouts/15/dpt.cept.tracking/trackconsignment.aspx`;

  return (
    <>
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-fade-in no-print">
      <div className="bg-white dark:bg-[#261C18] text-stone-900 dark:text-stone-100 rounded-2xl w-full max-w-lg shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-stone-100 dark:border-stone-800 bg-gradient-to-r from-[#8E1B25]/10 via-[#8E1B25]/5 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white p-1 shadow-2xs border border-stone-200 dark:border-stone-700 flex items-center justify-center overflow-hidden shrink-0">
              <img src={indiaPostLogo} alt="India Post" className="w-full h-full object-contain" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100">
                  {t('tracking.title')}
                </h2>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#8E1B25]/15 text-[#8E1B25] dark:text-amber-300">
                  India Post
                </span>
              </div>
              <p className="text-[11px] text-stone-500 dark:text-stone-400">
                Speed Post · Registered Post · Parcels · Letters
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors cursor-pointer"
            aria-label="Close tracking modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs sm:text-sm">
          
          {/* Online vs Offline Status Card */}
          <div
            className={`p-3.5 rounded-xl border flex items-start gap-3 transition-colors ${
              isOnline
                ? 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-900 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/60'
                : 'bg-amber-50 dark:bg-amber-950/30 text-amber-900 dark:text-amber-300 border-amber-200 dark:border-amber-800/60'
            }`}
          >
            {isOnline ? (
              <div className="p-1.5 rounded-lg bg-emerald-600 text-white shrink-0 mt-0.5">
                <Wifi className="w-4 h-4" />
              </div>
            ) : (
              <div className="p-1.5 rounded-lg bg-amber-600 text-white shrink-0 mt-0.5">
                <WifiOff className="w-4 h-4" />
              </div>
            )}
            <div className="text-xs space-y-0.5">
              <p className="font-bold">
                {isOnline ? 'Internet Connected (Live Tracking Ready)' : 'Offline Mode Active'}
              </p>
              <p className="opacity-90 leading-relaxed">
                {isOnline
                  ? 'Sorting Plan works 100% offline. Live status checks connect directly to the official India Post portal.'
                  : 'Your device is offline. The sorting plan and all offices remain accessible offline. Reconnect to internet for live consignment status.'}
              </p>
            </div>
          </div>

          {/* Consignment Number Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="font-bold text-stone-700 dark:text-stone-300">
                Article / Consignment Number <span className="text-rose-500">*</span>
              </label>
              {copied && (
                <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 animate-fade-in">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Copied!
                </span>
              )}
            </div>
            
            <div className="relative">
              <input
                type="text"
                value={consignmentNumber}
                onChange={(e) => {
                  setConsignmentNumber(e.target.value.toUpperCase());
                  setErrorMsg('');
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleCopyAndSave();
                }}
                placeholder={t('tracking.placeholder')}
                className={`w-full pl-3.5 py-2.5 rounded-xl font-mono text-sm bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 focus:outline-none focus:ring-2 focus:ring-[#8E1B25] text-stone-900 dark:text-stone-100 uppercase ${
                  scannerSupported ? 'pr-20' : 'pr-10'
                }`}
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                {scannerSupported && (
                  <button
                    type="button"
                    onClick={async () => {
                      if (!isNativeApp()) {
                        setIsScannerOpen(true);
                        return;
                      }
                      try {
                        const code = await scanBarcodeNative();
                        if (code) {
                          setConsignmentNumber(code.toUpperCase());
                          setErrorMsg('');
                        }
                      } catch (e: any) {
                        setErrorMsg(e?.message || 'Unable to scan.');
                      }
                    }}
                    className="p-1.5 rounded-lg text-[#8E1B25] dark:text-amber-400 hover:bg-stone-100 dark:hover:bg-stone-800 cursor-pointer"
                    title="Scan barcode / QR code on the label"
                    aria-label="Scan consignment barcode"
                  >
                    <ScanLine className="w-4 h-4" />
                  </button>
                )}
                {cleanConsignment && (
                  <button
                    type="button"
                    onClick={() => setConsignmentNumber('')}
                    className="p-1.5 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {errorMsg && (
              <p className="text-xs text-rose-600 dark:text-rose-400 font-medium">
                {errorMsg}
              </p>
            )}
          </div>

          {/* Action Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <button
              type="button"
              onClick={() => handleCopyAndSave()}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-800 dark:text-stone-200 transition-colors cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5 text-[#8E1B25] dark:text-amber-400" />
              <span>Copy Consignment Number</span>
            </button>

            <a
              href={officialTrackingUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => {
                if (cleanConsignment) handleCopyAndSave();
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs bg-[#8E1B25] hover:bg-[#6F151C] text-white transition-colors shadow-xs cursor-pointer text-center"
            >
              <span>{t('tracking.officialSite')}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Recent Tracks List */}
          {recentTracks.length > 0 && (
            <div className="pt-2 border-t border-stone-100 dark:border-stone-800 space-y-2">
              <div className="flex items-center justify-between text-xs text-stone-500">
                <span className="font-semibold flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  {t('tracking.recentTracks')}
                </span>
                <button
                  type="button"
                  onClick={handleClearRecents}
                  className="flex items-center gap-1 text-[11px] text-stone-400 hover:text-rose-500 transition-colors cursor-pointer"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>{t('tracking.clearHistory')}</span>
                </button>
              </div>

              <div className="space-y-1 max-h-36 overflow-y-auto pr-1">
                {recentTracks.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-2 rounded-lg bg-stone-50 dark:bg-stone-900 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors text-xs font-mono"
                  >
                    <button
                      type="button"
                      onClick={() => setConsignmentNumber(item.id)}
                      className="font-bold text-[#8E1B25] dark:text-amber-300 hover:underline cursor-pointer"
                    >
                      {item.id}
                    </button>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleCopyAndSave(item.id)}
                        className="p-1 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 cursor-pointer"
                        title="Copy to clipboard"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-end px-5 py-3.5 border-t border-stone-100 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-stone-600 dark:text-stone-400 hover:bg-stone-200/60 dark:hover:bg-stone-800 rounded-lg transition-colors cursor-pointer"
          >
            {t('common.close')}
          </button>
        </div>

      </div>
    </div>

    <BarcodeScannerOverlay
      isOpen={isScannerOpen}
      onClose={() => setIsScannerOpen(false)}
      onScan={(value) => {
        setConsignmentNumber(value.toUpperCase());
        setErrorMsg('');
      }}
    />
    </>
  );
};
