import React from 'react';
import { X, CheckCircle2, MapPin, Zap, ArrowRight, ShieldCheck } from 'lucide-react';
import { useModalBackButton } from '../hooks/useModalBackButton';
import { useLanguage } from '../i18n/LanguageContext';
import indiaPostLogo from '../assets/india-post-logo.svg';

interface WelcomeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAddressFinder?: () => void;
  totalRecordsCount?: number;
}

export const WelcomeModal: React.FC<WelcomeModalProps> = ({
  isOpen,
  onClose,
  onOpenAddressFinder,
  totalRecordsCount = 19000
}) => {
  useModalBackButton(isOpen, onClose);
  const { t } = useLanguage();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-fade-in no-print">
      <div 
        className="bg-white dark:bg-[#1E1714] text-stone-900 dark:text-stone-100 rounded-3xl w-full max-w-lg shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden flex flex-col max-h-[92vh] animate-scale-up"
        role="dialog"
        aria-modal="true"
      >
        {/* Top Decorative Banner with official India Post branding */}
        <div className="relative bg-gradient-to-r from-[#8E1B25] via-[#A3222C] to-[#8E1B25] p-6 text-white text-center flex flex-col items-center">
          <button
            onClick={onClose}
            className="absolute top-3.5 right-3.5 p-1.5 rounded-full text-white/80 hover:text-white hover:bg-white/20 transition-colors cursor-pointer"
            aria-label={t('welcome.closeAria')}
          >
            <X className="w-5 h-5" />
          </button>

          {/* Official India Post Logo Image */}
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl bg-white p-2 shadow-lg flex items-center justify-center mb-3.5 transform hover:scale-105 transition-transform">
            <img
              src={indiaPostLogo}
              alt="India Post Logo"
              className="w-full h-full object-contain"
            />
          </div>

          <h2 className="text-xl sm:text-2xl font-black tracking-tight flex items-center gap-2">
            <span>SORTING PLAN - ID Dn INDORE</span>
          </h2>
          <p className="text-xs sm:text-sm text-amber-200 font-medium mt-1">
            {t('welcome.subtitle')}
          </p>
        </div>

        {/* Body content */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-4 text-xs sm:text-sm leading-relaxed">
          
          {/* Dual Engine Banner */}
          <div className="p-3.5 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950/40 dark:to-orange-950/40 rounded-2xl border border-amber-200 dark:border-amber-800/60 space-y-1.5">
            <div className="flex items-center gap-2 font-bold text-amber-900 dark:text-amber-200">
              <Zap className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              <span>{t('welcome.smartLocation')}</span>
            </div>
            <p className="text-xs text-amber-900/90 dark:text-amber-300/90 leading-relaxed">
              <strong>{t('welcome.feature1')}</strong> {t('welcome.feature1Body')}<br />
              <strong>{t('welcome.feature2')}</strong> {t('welcome.feature2Body')}
            </p>
          </div>

          {/* Core Features List */}
          <div className="space-y-2.5">
            <h4 className="font-bold text-xs uppercase tracking-wider text-stone-500 dark:text-stone-400">
              {t('welcome.keyHighlights')}
            </h4>

            <div className="flex items-start gap-3 p-2.5 rounded-xl bg-stone-50 dark:bg-stone-900/60 border border-stone-200 dark:border-stone-800">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-stone-900 dark:text-stone-100">{t('welcome.offlineCapability')}</strong>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  {t('welcome.offlineCapabilityBody', { count: totalRecordsCount.toLocaleString() })}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-2.5 rounded-xl bg-stone-50 dark:bg-stone-900/60 border border-stone-200 dark:border-stone-800">
              <MapPin className="w-4 h-4 text-[#8E1B25] dark:text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-stone-900 dark:text-stone-100">{t('welcome.highlight1Title')}</strong>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  {t('welcome.highlight1Body')}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-2.5 rounded-xl bg-stone-50 dark:bg-stone-900/60 border border-stone-200 dark:border-stone-800">
              <ShieldCheck className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-stone-900 dark:text-stone-100">{t('welcome.multiVillage')}</strong>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  {t('welcome.multiVillageBody')}
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="px-5 py-4 border-t border-stone-200 dark:border-stone-800 bg-stone-50/70 dark:bg-stone-900/50 flex flex-col sm:flex-row items-center justify-between gap-3">
          {onOpenAddressFinder && (
            <button
              onClick={() => {
                onClose();
                onOpenAddressFinder();
              }}
              className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-bold text-stone-900 bg-amber-400 hover:bg-amber-300 transition-colors shadow-xs cursor-pointer"
            >
              <MapPin className="w-4 h-4 text-[#8E1B25]" />
              <span>{t('welcome.openAddressFinder')}</span>
            </button>
          )}

          <button
            onClick={onClose}
            className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-[#8E1B25] hover:bg-[#6F151C] transition-colors shadow-xs cursor-pointer"
          >
            <span>{t('welcome.startBtn')}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
