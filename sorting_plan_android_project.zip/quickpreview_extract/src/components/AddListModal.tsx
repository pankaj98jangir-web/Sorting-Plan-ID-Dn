import React, { useState, useRef } from 'react';
import {
  X,
  Upload,
  FileText,
  CheckCircle2,
  AlertCircle,
  Layers,
  ArrowRight,
  Merge,
  Sparkles,
  FileUp,
  Database,
  Check
} from 'lucide-react';
import { CustomList, splitVillageCell } from '../data/store';
import { RawListMeta, RAW_LISTS } from '../data/types';
import { parsePdfOffline } from '../utils/pdfFallbackParser';
import { useModalBackButton } from '../hooks/useModalBackButton';
import indiaPostLogo from '../assets/india-post-logo.svg';

interface AddListModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddList: (list: CustomList) => void;
  onMergeBuiltinList?: (
    listKey: string,
    records: Array<{ v: string; p: string; f1: string; f2: string; f3: string }>
  ) => { addedCount: number; duplicateCount: number; totalInList: number; saved?: boolean };
  availableLists?: RawListMeta[];
}

export const AddListModal: React.FC<AddListModalProps> = ({
  isOpen,
  onClose,
  onAddList,
  onMergeBuiltinList,
  availableLists = RAW_LISTS
}) => {
  const [targetAction, setTargetAction] = useState<'merge' | 'new'>('merge');
  const [targetListKey, setTargetListKey] = useState<string>('ratlam_mandsaur');
  const [listName, setListName] = useState('');
  const [mode, setMode] = useState<'paste' | 'file'>('file');
  const [pastedText, setPastedText] = useState('');
  const [fileText, setFileText] = useState('');
  const [fileName, setFileName] = useState('');
  const [isParsingPdf, setIsParsingPdf] = useState(false);
  const [pdfParsedRecords, setPdfParsedRecords] = useState<
    Array<{ v: string; p: string; f1: string; f2: string; f3: string }>
  >([]);
  const [feedback, setFeedback] = useState<{
    type: 'ok' | 'err';
    message: string;
    details?: string;
  } | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useModalBackButton(isOpen, onClose);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setPdfParsedRecords([]);
    setFileText('');
    setFeedback(null);

    const isPdf = file.name.toLowerCase().endsWith('.pdf') || file.type === 'application/pdf';

    if (isPdf) {
      setIsParsingPdf(true);
      const reader = new FileReader();
      reader.onload = async (event) => {
        const base64 = (event.target?.result as string) || '';
        // Try the AI-powered server parser first (most accurate). If there is
        // no server reachable at all — which is the case once this app runs
        // standalone as an APK with no backend — fall back to a fully
        // offline, in-browser text+regex parser (parsePdfOffline) instead of
        // just failing.
        let serverUnreachable = false;
        try {
          const res = await fetch('/api/parse-pdf', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ pdfBase64: base64, filename: file.name })
          });

          const data = await res.json();
          if (data.records && data.records.length > 0) {
            setPdfParsedRecords(data.records);
            setFeedback({
              type: 'ok',
              message: `Extracted ${data.records.length} records from "${file.name}"!`,
              details: `PDF processed via ${data.extractionMethod}. Click "Merge" or "Save" below to permanently embed these records.`
            });
            setIsParsingPdf(false);
            return;
          }
        } catch (err: any) {
          serverUnreachable = true;
        }

        // Offline fallback path
        try {
          const offlineRecords = await parsePdfOffline(file);
          if (offlineRecords.length > 0) {
            setPdfParsedRecords(offlineRecords);
            setFeedback({
              type: 'ok',
              message: `Extracted ${offlineRecords.length} records from "${file.name}" (offline mode).`,
              details: serverUnreachable
                ? 'No server connection was available, so this was parsed on-device. Accuracy may be lower than AI parsing — please review before saving.'
                : 'Please review the extracted records before saving.'
            });
          } else {
            setFeedback({
              type: 'err',
              message: 'No postal sorting records could be extracted from this PDF.',
              details: 'Please ensure the PDF contains sorting plan tables with Village, PIN Code, B.O, S.O, and H.O., or try pasting the data as text/CSV instead.'
            });
          }
        } catch (offlineErr: any) {
          setFeedback({
            type: 'err',
            message: 'Failed to process this PDF.',
            details: offlineErr?.message || 'Please try pasting the data as text/CSV instead.'
          });
        } finally {
          setIsParsingPdf(false);
        }
      };
      reader.readAsDataURL(file);
    } else {
      // Plain text, CSV, TSV
      const reader = new FileReader();
      reader.onload = (event) => {
        const content = event.target?.result as string;
        setFileText(content || '');
      };
      reader.readAsText(file);
    }
  };

  const detectDelimiter = (line: string): string => {
    const c1 = (line.match(/,/g) || []).length;
    const c2 = (line.match(/\t/g) || []).length;
    const c3 = (line.match(/;/g) || []).length;
    if (c2 >= c1 && c2 >= c3) return '\t';
    if (c3 > c1) return ';';
    return ',';
  };

  const splitLine = (line: string, delim: string): string[] => {
    const out: string[] = [];
    let cur = '';
    let inQuote = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        inQuote = !inQuote;
        continue;
      }
      if (ch === delim && !inQuote) {
        out.push(cur.trim());
        cur = '';
        continue;
      }
      cur += ch;
    }
    out.push(cur.trim());
    return out;
  };

  const parseData = (raw: string, isTdTarget: boolean = false) => {
    const lines = raw.split(/\r?\n/).filter((l) => l.trim().length > 0);
    if (lines.length === 0) {
      return { records: [], totalLines: 0, expandedCount: 0, duplicateCount: 0, error: 'No data lines found.' };
    }

    const delim = detectDelimiter(lines[0]);
    const header = splitLine(lines[0], delim).map((h) => h.toLowerCase());

    const findIndex = (keywords: string[]) => {
      for (let i = 0; i < header.length; i++) {
        for (const kw of keywords) {
          if (header[i].includes(kw)) return i;
        }
      }
      return -1;
    };

    // Header column mapping
    const iV = findIndex(['village', 'area', 'locality', 'name of village', 'name of the village', 'name']);
    const iP = findIndex(['pincode', 'pin code', 'pin']);
    const iF1 = findIndex(['branch post office', 'branch office', 'branch', 'bo', 'house', 'b.o']);
    const iF2 = findIndex(['account office', 'sub office', 'so', 's.o', 'beat']);
    const iF3 = findIndex(['head office', 'ho', 'h.o', 'delivery']);

    // Check if headers exist
    const hasHeader = iV >= 0 || iP >= 0 || iF1 >= 0 || iF2 >= 0 || iF3 >= 0;
    const startRow = hasHeader ? 1 : 0;

    const idxV = iV >= 0 ? iV : 0;
    const idxP = iP >= 0 ? iP : (iF1 === 1 ? 4 : 1);
    const idxF1 = iF1 >= 0 ? iF1 : 2;
    const idxF2 = iF2 >= 0 ? iF2 : 3;
    const idxF3 = iF3 >= 0 ? iF3 : 4;

    const rawRows: Array<{ v: string; p: string; f1: string; f2: string; f3: string }> = [];
    let expandedFromCells = 0;

    for (let r = startRow; r < lines.length; r++) {
      const cols = splitLine(lines[r], delim);
      if (cols.length === 1 && !cols[0]) continue;

      const rawV = idxV < cols.length ? cols[idxV] || '' : '';
      const p = idxP < cols.length ? cols[idxP] || '' : '';
      const f1 = idxF1 < cols.length ? cols[idxF1] || '' : '';
      const f2 = idxF2 < cols.length ? cols[idxF2] || '' : '';
      const f3 = idxF3 < cols.length ? cols[idxF3] || '' : '';

      // Multi-village splitting: if cell has comma/slash/semicolon/newline, split into individual village names
      const individualVillages = splitVillageCell(rawV, isTdTarget);
      if (individualVillages.length > 1) {
        expandedFromCells += individualVillages.length - 1;
      }

      individualVillages.forEach((v) => {
        if (v || p || f1 || f2 || f3) {
          rawRows.push({ v, p, f1, f2, f3 });
        }
      });
    }

    // Deduplication intentionally disabled: every parsed row is kept as-is,
    // even if it looks identical to another one in the same upload.
    return {
      records: rawRows,
      totalLines: lines.length - (hasHeader ? 1 : 0),
      expandedCount: expandedFromCells,
      duplicateCount: 0,
      error: rawRows.length === 0 ? 'Could not extract valid records from data.' : null
    };
  };

  const handleSave = () => {
    setFeedback(null);
    const isTdTarget = targetAction === 'merge' && targetListKey === 'td_list';

    let finalRecords: Array<{ v: string; p: string; f1: string; f2: string; f3: string }> = [];
    let expandedCount = 0;
    let duplicateCount = 0;

    // 1. If we parsed records directly from PDF
    if (pdfParsedRecords.length > 0) {
      // Deduplication intentionally disabled — every parsed record is kept.
      pdfParsedRecords.forEach((item) => {
        const vParts = splitVillageCell(item.v, isTdTarget);
        if (vParts.length > 1) {
          expandedCount += vParts.length - 1;
        }
        vParts.forEach((singleV) => {
          finalRecords.push({
            v: singleV,
            p: item.p,
            f1: item.f1,
            f2: item.f2,
            f3: item.f3
          });
        });
      });
    } else {
      // 2. Otherwise parse from text / CSV / TSV
      const content = mode === 'paste' ? pastedText : fileText;
      if (!content.trim()) {
        setFeedback({
          type: 'err',
          message: mode === 'paste' ? 'Please paste your CSV or TSV data.' : 'Please choose a file to upload.'
        });
        return;
      }

      const parsed = parseData(content, isTdTarget);
      if (parsed.error || parsed.records.length === 0) {
        setFeedback({ type: 'err', message: parsed.error || 'Failed to parse records.' });
        return;
      }
      finalRecords = parsed.records;
      expandedCount = parsed.expandedCount;
      duplicateCount = parsed.duplicateCount;
    }

    if (finalRecords.length === 0) {
      setFeedback({ type: 'err', message: 'No valid records ready to embed.' });
      return;
    }

    if (targetAction === 'merge') {
      const selectedMeta = availableLists.find((l) => l.key === targetListKey) || availableLists[0];
      if (onMergeBuiltinList) {
        const res = onMergeBuiltinList(targetListKey, finalRecords);
        if (res.saved === false) {
          setFeedback({
            type: 'err',
            message: 'Could not save — device storage is full.',
            details: 'The records are visible for now but will be lost when the app closes. Upload a smaller file or free up space, then try again.'
          });
          return;
        }
        setFeedback({
          type: 'ok',
          message: `Permanently embedded into "${selectedMeta.name}"!`,
          details: `Added ${res.addedCount} village records (${expandedCount} expanded from multi-village cells). Saved permanently on this device.`
        });
      }
    } else {
      const cleanName = listName.trim();
      if (!cleanName) {
        setFeedback({ type: 'err', message: 'Please enter a name for the new list.' });
        return;
      }

      const newList: CustomList = {
        key: `custom_${Date.now()}`,
        name: cleanName,
        type: 'village',
        records: finalRecords
      };

      onAddList(newList);
      setFeedback({
        type: 'ok',
        message: `Permanently created new list "${cleanName}"!`,
        details: `Successfully added ${finalRecords.length} records. Saved permanently on this device.`
      });
    }

    setTimeout(() => {
      setListName('');
      setPastedText('');
      setFileText('');
      setFileName('');
      setPdfParsedRecords([]);
      setFeedback(null);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-fade-in no-print">
      <div className="bg-white dark:bg-[#261C18] text-stone-900 dark:text-stone-100 rounded-3xl w-full max-w-xl shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-stone-100 dark:border-stone-800 bg-gradient-to-r from-[#8E1B25]/10 via-transparent to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white p-1 shadow-2xs border border-stone-200 dark:border-stone-700 flex items-center justify-center shrink-0 overflow-hidden">
              <img src={indiaPostLogo} alt="India Post" className="w-full h-full object-contain" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-stone-900 dark:text-stone-100">
                  Upload &amp; Permanently Embed Lists
                </h2>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                  Permanent Storage
                </span>
              </div>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                Supports PDF, CSV, Excel, TXT · Multi-village cell splitting &amp; BO deduplication
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 text-xs sm:text-sm">

          {/* Permanent Embedding Promise Banner */}
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/30 rounded-2xl border border-emerald-200 dark:border-emerald-800/60 flex items-start gap-2.5 text-xs text-emerald-900 dark:text-emerald-200">
            <Database className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
            <div className="space-y-0.5 leading-relaxed">
              <strong>Permanent Server-Side Storage:</strong>
              <p>
                Whatever lists you upload or merge here are saved permanently on this device (and on the server too, when one is connected). No repeated uploads are required.
              </p>
            </div>
          </div>
          
          {/* Target Action Mode: Merge vs Create New */}
          <div className="space-y-1.5">
            <label className="font-bold text-stone-700 dark:text-stone-300 flex items-center gap-1.5">
              <Merge className="w-4 h-4 text-[#8E1B25] dark:text-amber-400" />
              <span>Target List Action</span>
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-stone-100 dark:bg-stone-900 rounded-xl">
              <button
                type="button"
                onClick={() => setTargetAction('merge')}
                className={`py-2 px-3 rounded-lg font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  targetAction === 'merge'
                    ? 'bg-white dark:bg-[#261C18] text-[#8E1B25] dark:text-amber-400 shadow-sm border border-stone-200 dark:border-stone-800'
                    : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-200'
                }`}
              >
                <Merge className="w-3.5 h-3.5" />
                <span>Merge with Built-in List</span>
              </button>
              <button
                type="button"
                onClick={() => setTargetAction('new')}
                className={`py-2 px-3 rounded-lg font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  targetAction === 'new'
                    ? 'bg-white dark:bg-[#261C18] text-[#8E1B25] dark:text-amber-400 shadow-sm border border-stone-200 dark:border-stone-800'
                    : 'text-stone-500 hover:text-stone-900 dark:hover:text-stone-200'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Create New Standalone List</span>
              </button>
            </div>
          </div>

          {/* Merge Target Selector */}
          {targetAction === 'merge' ? (
            <div className="space-y-1.5 bg-amber-50/70 dark:bg-amber-950/30 p-3.5 rounded-2xl border border-amber-200/80 dark:border-amber-900/50">
              <label className="font-bold text-amber-950 dark:text-amber-200 flex items-center gap-1.5 text-xs">
                <span>Select Target Regional List to Merge With:</span>
              </label>
              <select
                value={targetListKey}
                onChange={(e) => setTargetListKey(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-white dark:bg-stone-900 border border-amber-300 dark:border-amber-800 text-stone-900 dark:text-stone-100 font-semibold text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#8E1B25]"
              >
                <option value="ratlam_mandsaur">
                  Ratlam, Mandsaur, Neemuch, Alirajpur, Jhabua (Merges Alirajpur, Jobat &amp; Jhabua line)
                </option>
                <option value="dhar_dewas">
                  Dhar, Dewas (Merges Dewas Sub-Division delivery line)
                </option>
                <option value="indore_mfl">
                  Indore Moufsil (MFL) (Merges Indore MFL delivery line)
                </option>
                <option value="shajapur_ujjain">
                  Ujjain, Shajapur, Agar-Malwa
                </option>
                <option value="khandwa_khargone">
                  Khandwa, Khargone, Barwani, Burhanpur
                </option>
                <option value="td_list">
                  Indore City T.D. List (Delivery Beats)
                </option>
              </select>
              <p className="text-[11px] text-amber-800 dark:text-amber-300/80 mt-1">
                Records will be automatically combined into this list, with comma-separated villages split into individual entries.
              </p>
            </div>
          ) : (
            <div className="space-y-1.5">
              <label className="font-semibold text-stone-700 dark:text-stone-300">
                New List Name <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={listName}
                onChange={(e) => setListName(e.target.value)}
                placeholder="e.g., Alirajpur Sub-Division Sorting Plan"
                className="w-full px-3.5 py-2.5 rounded-xl bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 focus:outline-none focus:ring-2 focus:ring-[#8E1B25] text-stone-900 dark:text-stone-100"
              />
            </div>
          )}

          {/* Data Source Mode Switcher */}
          <div className="space-y-1.5">
            <label className="font-semibold text-stone-700 dark:text-stone-300">Data Source</label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-stone-100 dark:bg-stone-900 rounded-xl">
              <button
                type="button"
                onClick={() => setMode('file')}
                className={`py-1.5 rounded-lg font-semibold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  mode === 'file'
                    ? 'bg-white dark:bg-stone-800 text-[#8E1B25] dark:text-amber-400 shadow-xs'
                    : 'text-stone-500 hover:text-stone-900'
                }`}
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload File (PDF / CSV / TXT)</span>
              </button>
              <button
                type="button"
                onClick={() => setMode('paste')}
                className={`py-1.5 rounded-lg font-semibold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  mode === 'paste'
                    ? 'bg-white dark:bg-stone-800 text-[#8E1B25] dark:text-amber-400 shadow-xs'
                    : 'text-stone-500 hover:text-stone-900'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Paste Text (CSV / Excel / TSV)</span>
              </button>
            </div>
          </div>

          {/* File Upload Section */}
          {mode === 'file' ? (
            <div className="space-y-2">
              <label className="font-semibold text-stone-700 dark:text-stone-300 flex items-center justify-between">
                <span>Select PDF, CSV, or Text Sorting Plan</span>
                <span className="text-[11px] font-bold text-amber-600 dark:text-amber-400">
                  PDF Auto-Extraction Enabled
                </span>
              </label>

              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.csv,.txt,application/pdf,text/csv,text/plain"
                onChange={handleFileChange}
                className="hidden"
              />

              <div
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${
                  isParsingPdf
                    ? 'border-amber-400 bg-amber-50/50 dark:bg-amber-950/20'
                    : 'border-stone-300 dark:border-stone-700 hover:border-[#8E1B25] dark:hover:border-amber-500 bg-stone-50 dark:bg-stone-900/40'
                }`}
              >
                {isParsingPdf ? (
                  <div className="space-y-2 py-2">
                    <div className="w-8 h-8 mx-auto border-3 border-[#8E1B25] border-t-transparent rounded-full animate-spin" />
                    <p className="font-bold text-stone-800 dark:text-stone-200">
                      Reading &amp; Extracting PDF Sorting Plan...
                    </p>
                    <p className="text-xs text-stone-500">
                      Extracting villages, Branch Offices, PIN codes, and Sub Offices.
                    </p>
                  </div>
                ) : fileName ? (
                  <div className="space-y-1">
                    <FileUp className="w-8 h-8 mx-auto text-emerald-600 dark:text-emerald-400" />
                    <p className="font-bold text-stone-900 dark:text-stone-100">{fileName}</p>
                    {pdfParsedRecords.length > 0 && (
                      <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                        ✓ {pdfParsedRecords.length} records ready to embed
                      </p>
                    )}
                    <p className="text-[11px] text-stone-400">Click to change file</p>
                  </div>
                ) : (
                  <>
                    <Upload className="w-8 h-8 mx-auto text-stone-400 mb-2" />
                    <p className="font-bold text-stone-700 dark:text-stone-300">Click to choose PDF or CSV file</p>
                    <p className="text-xs text-stone-400 mt-1">
                      Accepts Official Sorting Plan PDFs, CSVs, or plain text export
                    </p>
                  </>
                )}
              </div>

              {/* PDF Preview Snippet */}
              {pdfParsedRecords.length > 0 && (
                <div className="p-3 bg-stone-50 dark:bg-stone-900/60 rounded-xl border border-stone-200 dark:border-stone-800 space-y-1.5 text-xs">
                  <div className="font-bold text-stone-700 dark:text-stone-300 flex items-center justify-between">
                    <span>Sample Extracted Records (First {Math.min(3, pdfParsedRecords.length)}):</span>
                    <span className="font-mono text-emerald-600 font-bold">{pdfParsedRecords.length} total</span>
                  </div>
                  <div className="space-y-1">
                    {pdfParsedRecords.slice(0, 3).map((r, i) => (
                      <div key={i} className="p-1.5 bg-white dark:bg-[#1E1714] rounded border border-stone-200 dark:border-stone-700 font-mono text-[11px] truncate">
                        <strong>{r.v}</strong> | PIN: {r.p} | BO: {r.f1} | SO: {r.f2}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* Paste Section */
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="font-semibold text-stone-700 dark:text-stone-300">
                  CSV, Excel or Tab-Separated Records
                </label>
                <span className="text-[11px] text-stone-400">
                  Supports cells with multiple villages separated by commas
                </span>
              </div>
              <textarea
                value={pastedText}
                onChange={(e) => setPastedText(e.target.value)}
                placeholder={`NAME OF VILLAGE/AREA,BRANCH POST OFFICE NAME,SUB OFFICE,NAME OF HO,PINCODE\n"ILASKHEDI, MOCHIKHEDI, LAXMIPURA, RALAMANDAL",AAGROD,DEWAS HO,DEWAS HO,455116\nAali,Ajanda B.O,Alirajpur,Alirajpur,457887`}
                rows={7}
                className="w-full px-3 py-2.5 rounded-xl font-mono text-xs bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-800 focus:outline-none focus:ring-2 focus:ring-[#8E1B25] text-stone-900 dark:text-stone-100"
              />
            </div>
          )}

          {/* Intelligence Features Notice */}
          <div className="p-3 bg-stone-50 dark:bg-stone-900/60 rounded-xl border border-stone-200 dark:border-stone-800 flex items-start gap-2.5 text-xs text-stone-600 dark:text-stone-400">
            <Sparkles className="w-4 h-4 text-[#F2B705] shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <strong className="text-stone-800 dark:text-stone-200">Automatic Processing:</strong>
              <p>
                1. <strong>PDF &amp; Multi-Village Splitting:</strong> Cells containing multiple villages separated by commas, semicolons, or slashes are split into separate entries.<br />
                2. <strong>Branch Office Deduplication:</strong> Duplicate entries for the same village under a Branch Post Office are shown only once in results.
              </p>
            </div>
          </div>

          {/* Feedback Alert */}
          {feedback && (
            <div
              className={`p-3.5 rounded-xl flex items-start gap-2.5 text-xs ${
                feedback.type === 'ok'
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-900 dark:text-emerald-200 border border-emerald-200 dark:border-emerald-800'
                  : 'bg-rose-50 dark:bg-rose-950/40 text-rose-900 dark:text-rose-200 border border-rose-200 dark:border-rose-800'
              }`}
            >
              {feedback.type === 'ok' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 dark:text-emerald-400 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 dark:text-rose-400 mt-0.5" />
              )}
              <div className="space-y-0.5">
                <p className="font-bold">{feedback.message}</p>
                {feedback.details && <p className="opacity-90">{feedback.details}</p>}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-2 px-5 py-3.5 border-t border-stone-100 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50">
          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-2 text-xs font-semibold text-stone-600 dark:text-stone-400 hover:bg-stone-200/60 dark:hover:bg-stone-800 rounded-lg transition-colors cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={isParsingPdf}
            className="w-full sm:w-auto px-5 py-2 text-xs font-bold text-[#241A17] bg-[#F2B705] hover:bg-[#D99E00] disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-sm transition-transform active:scale-95 cursor-pointer flex items-center justify-center gap-1.5"
          >
            <span>{targetAction === 'merge' ? 'Merge & Save Permanently' : 'Save Permanently as New List'}</span>
            <ArrowRight className="w-3.5 h-3.5 shrink-0" />
          </button>
        </div>

      </div>
    </div>
  );
};
