import React from 'react';
import { X, Trash2, RotateCcw } from 'lucide-react';
import { RawListMeta } from '../data/types';
import { useModalBackButton } from '../hooks/useModalBackButton';
import { useLanguage } from '../i18n/LanguageContext';

interface ManageListsModalProps {
  isOpen: boolean;
  onClose: () => void;
  allLists: RawListMeta[];
  hiddenKeys: string[];
  onToggleList: (key: string) => void;
  onDeleteCustomList: (key: string) => void;
  onResetDefaults: () => void;
}

export const ManageListsModal: React.FC<ManageListsModalProps> = ({
  isOpen,
  onClose,
  allLists,
  hiddenKeys,
  onToggleList,
  onDeleteCustomList,
  onResetDefaults
}) => {
  const { t } = useLanguage();
  useModalBackButton(isOpen, onClose);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
      <div className="bg-white dark:bg-[#261C18] text-stone-900 dark:text-stone-100 rounded-2xl w-full max-w-lg shadow-2xl border border-stone-200 dark:border-stone-800 overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-stone-100 dark:border-stone-800">
          <div>
            <h2 className="text-lg font-bold">{t('manageLists.title')}</h2>
            <p className="text-xs text-stone-500 dark:text-stone-400">Toggle visibility or remove custom imported lists</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto divide-y divide-stone-100 dark:divide-stone-800/80">
          {allLists.map((l) => {
            const isHidden = hiddenKeys.includes(l.key);
            const isCustom = l.key.startsWith('custom_');

            return (
              <div key={l.key} className="py-3.5 first:pt-0 last:pb-0 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm text-stone-900 dark:text-stone-100 truncate">
                      {l.name}
                    </span>
                    {isCustom && (
                      <span className="text-[10px] uppercase font-bold text-amber-700 dark:text-amber-300 bg-amber-100/70 dark:bg-amber-950/60 px-1.5 py-0.2 rounded">
                        custom
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-stone-400 mt-0.5">
                    {l.count.toLocaleString()} entries · {l.type === 'td' ? 'City Delivery Beats' : 'District Sorting Plan'}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {/* Toggle Switch */}
                  <button
                    onClick={() => onToggleList(l.key)}
                    className={`relative w-11 h-6 rounded-full transition-colors ${
                      !isHidden ? 'bg-[#8E1B25] dark:bg-amber-600' : 'bg-stone-200 dark:bg-stone-700'
                    }`}
                    title={!isHidden ? 'Hide list from search' : 'Show list in search'}
                  >
                    <span
                      className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform shadow-xs ${
                        !isHidden ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>

                  {/* Delete Button for Custom Lists */}
                  {isCustom && (
                    <button
                      onClick={() => {
                        if (confirm(`Remove custom list "${l.name}" permanently?`)) {
                          onDeleteCustomList(l.key);
                        }
                      }}
                      className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                      title="Delete this custom list"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between gap-2 px-5 py-3.5 border-t border-stone-100 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/50">
          <button
            onClick={onResetDefaults}
            className="flex items-center gap-1.5 text-xs font-semibold text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t('manageLists.resetHidden')}</span>
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-white bg-stone-900 dark:bg-stone-700 hover:bg-black rounded-lg transition-colors"
          >
            {t('common.done')}
          </button>
        </div>

      </div>
    </div>
  );
};
