import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { useLanguage } from '../i18n/LanguageContext';

export const OfflineBanner: React.FC = () => {
  const isOnline = useOnlineStatus();
  const { t } = useLanguage();

  if (isOnline) return null;

  return (
    <div className="bg-amber-600 text-white text-xs px-4 py-1.5 flex items-center justify-center gap-2 shadow-xs transition-all animate-fade-in no-print">
      <WifiOff className="w-3.5 h-3.5 shrink-0" />
      <span>
        <strong>{t('offline.active')}</strong> {t('offline.body')}
      </span>
      <span className="hidden md:inline opacity-90 border-l border-white/30 pl-2 ml-1 text-[11px]">
        {t('offline.note')}
      </span>
    </div>
  );
};
