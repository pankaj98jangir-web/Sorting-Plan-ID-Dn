import { isNativeApp } from './utils/native';

/** One-time setup for the packaged Android app: brand-coloured status bar,
 * splash screen hand-off and hardware back-button behaviour. A no-op in a
 * normal browser. */
export async function initNativeApp(): Promise<void> {
  if (!isNativeApp()) return;

  try {
    const { StatusBar, Style } = await import('@capacitor/status-bar');
    await StatusBar.setStyle({ style: Style.Dark });
    await StatusBar.setBackgroundColor({ color: '#8E1B25' });
  } catch {
    // Status bar styling is cosmetic only.
  }

  try {
    const { App } = await import('@capacitor/app');
    // Modals push a history entry (see useModalBackButton) so Back closes
    // them first; only exit the app when there is nothing left to go back to.
    App.addListener('backButton', ({ canGoBack }) => {
      if (canGoBack) {
        window.history.back();
      } else {
        App.exitApp();
      }
    });
  } catch {
    // ignore
  }

  try {
    const { SplashScreen } = await import('@capacitor/splash-screen');
    await SplashScreen.hide();
  } catch {
    // ignore
  }
}
