import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import { LanguageProvider } from './i18n/LanguageContext';
import { initNativeApp } from './nativeInit';
import { isNativeApp } from './utils/native';
import './index.css';

// Service worker registration is loaded dynamically and guarded with
// @vite-ignore, because the standalone single-file build
// (vite.standalone.config.ts, for direct file:// use) has no PWA plugin and
// therefore no 'virtual:pwa-register' module at all — service workers
// require a secure context (https/localhost) and never register over
// file:// anyway, so it's simply skipped there instead of failing the build.
// The packaged app already ships every file inside the APK, so a service
// worker cache would only risk serving stale files after an app update.
if ('serviceWorker' in navigator && !isNativeApp()) {
  import(/* @vite-ignore */ 'virtual:pwa-register')
    .then(({ registerSW }) => {
      registerSW({
        immediate: true,
        onOfflineReady() {
          console.log('Postal Sorting Plan is ready for full offline operation.');
        },
      });
    })
    .catch(() => {
      // No service worker available in this build — safe to ignore.
    });
}

initNativeApp();

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <LanguageProvider>
      <App />
    </LanguageProvider>
  </StrictMode>,
);

