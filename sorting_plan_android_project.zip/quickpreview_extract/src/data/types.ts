export interface RawListMeta {
  key: string;
  name: string;
  type: 'village' | 'td';
  count: number;
}

export type RawRecordTuple = [number, number, string, string, string, string, string];

export interface PostalRecord {
  id: string;
  listKey: string;
  listName: string;
  type: 'village' | 'td';
  village: string;
  pincode: string;
  field1: string; // Branch Post Office OR House No / Locality
  field2: string; // Sub Office / Account Office OR Beat No.
  field3: string; // Head Office (HO) OR Delivery Office
  searchStr: string;
}

export const RAW_LISTS: RawListMeta[] = [
  { key: "indore_mfl", name: "Indore Moufsil (MFL)", type: "village", count: 2305 },
  { key: "shajapur_ujjain", name: "Ujjain, Shajapur, Agar-Malwa", type: "village", count: 1986 },
  { key: "ratlam_mandsaur", name: "Ratlam, Mandsaur, Neemuch, Alirajpur, Jhabua", type: "village", count: 6863 },
  { key: "dhar_dewas", name: "Dhar, Dewas (Sub-Division Delivery)", type: "village", count: 3092 },
  { key: "khandwa_khargone", name: "Khandwa, Khargone, Barwani, Burhanpur", type: "village", count: 3218 },
  { key: "td_list", name: "Indore City T.D. List (Delivery Beats)", type: "td", count: 6102 }
];
