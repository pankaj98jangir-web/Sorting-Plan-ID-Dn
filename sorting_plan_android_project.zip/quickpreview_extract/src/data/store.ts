import { RAW_LISTS, PostalRecord, RawListMeta } from './types';
import { RECORDS_MFL } from './records_mfl';
import { RECORDS_UJJAIN } from './records_ujjain';
import { RECORDS_RATLAM } from './records_ratlam';
import { RECORDS_DHAR } from './records_dhar';
import { RECORDS_KHANDWA } from './records_khandwa';
import { RECORDS_TD } from './records_td';
import permanentStorageFallback from './permanent_storage.json';

const LS_HIDDEN = 'sp_hidden_builtin_v1';
const LS_CUSTOM = 'sp_custom_lists_v1';
const LS_BOOKMARKS = 'sp_bookmarks_v1';
const LS_MERGED_BUILTIN = 'sp_merged_builtin_records_v2';

export interface CustomList {
  key: string;
  name: string;
  type: 'village' | 'td';
  records: Array<{
    v: string;
    p: string;
    f1: string;
    f2: string;
    f3: string;
  }>;
}

export type MergedBuiltinStore = Record<
  string,
  Array<{
    v: string;
    p: string;
    f1: string;
    f2: string;
    f3: string;
  }>
>;

/**
 * Splits a village/area cell that may contain multiple comma-, slash-, semicolon-, or newline-separated names.
 * Example: "ILASKHEDI, MOCHIKHEDI, LAXMIPURA, RALAMANDAL, "
 * Returns: ["ILASKHEDI", "MOCHIKHEDI", "LAXMIPURA", "RALAMANDAL"]
 */
const hasContent = (s: string) => /[A-Za-z0-9\u0900-\u097F]/.test(s);

export function splitVillageCell(rawVillage: string, isTdList: boolean = false): string[] {
  if (!rawVillage) return [];
  const trimmed = rawVillage.trim();
  // Cells holding only punctuation (e.g. a stray ".") carry no information.
  if (!trimmed || !hasContent(trimmed)) return [];

  // For City Delivery (TD list), preserve plot numbers like "16/2 ka Patta" or "8/3 Manoramaganj"
  if (isTdList) {
    if (trimmed.includes(',')) {
      const parts = trimmed
        .split(/[,;\n\r]+/)
        .map((s) => s.trim())
        .filter((s) => s.length > 0 && s !== '-' && s !== '.');
      return parts.length > 0 ? parts : [trimmed];
    }
    return [trimmed];
  }

  // For Village / Town sorting plans:
  // 1. Split on commas, semicolons, and newlines
  const primaryParts = trimmed
    .split(/[,;\n\r]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0 && s !== '-' && s !== '.' && s !== 'null' && s !== 'undefined');

  const finalParts: string[] = [];
  for (const part of primaryParts) {
    // If the part contains " / " with whitespace separating alternative village names
    if (part.includes(' / ')) {
      const subParts = part
        .split(/\s+\/\s+/)
        .map((s) => s.trim())
        .filter((s) => s.length > 0);
      finalParts.push(...subParts);
    } else {
      finalParts.push(part);
    }
  }

  return finalParts.length > 0 ? finalParts : [trimmed];
}

export function getStoredHidden(): string[] {
  try {
    const val = localStorage.getItem(LS_HIDDEN);
    return val ? JSON.parse(val) : [];
  } catch {
    return [];
  }
}

export function setStoredHidden(keys: string[]) {
  try {
    localStorage.setItem(LS_HIDDEN, JSON.stringify(keys));
  } catch (e) {
    console.error(e);
  }
}

export function getStoredCustomLists(): CustomList[] {
  try {
    const val = localStorage.getItem(LS_CUSTOM);
    if (val) return JSON.parse(val);
  } catch {
    // ignore
  }
  return (permanentStorageFallback as any)?.customLists || [];
}

export function setStoredCustomLists(lists: CustomList[]) {
  try {
    localStorage.setItem(LS_CUSTOM, JSON.stringify(lists));
  } catch (e) {
    console.error(e);
  }
  persistRecordsToServer(undefined, lists);
}

export function getStoredBookmarks(): string[] {
  try {
    const val = localStorage.getItem(LS_BOOKMARKS);
    return val ? JSON.parse(val) : [];
  } catch {
    return [];
  }
}

export function setStoredBookmarks(ids: string[]) {
  try {
    localStorage.setItem(LS_BOOKMARKS, JSON.stringify(ids));
  } catch (e) {
    console.error(e);
  }
}

export function getStoredMergedBuiltinRecords(): MergedBuiltinStore {
  try {
    const val = localStorage.getItem(LS_MERGED_BUILTIN);
    if (val) return JSON.parse(val);
  } catch {
    // ignore
  }
  return (permanentStorageFallback as any)?.mergedBuiltin || {};
}

export function setStoredMergedBuiltinRecords(store: MergedBuiltinStore): boolean {
  try {
    localStorage.setItem(LS_MERGED_BUILTIN, JSON.stringify(store));
    return true;
  } catch (e) {
    console.error(e);
    return false;
  }
}

export async function persistRecordsToServer(
  mergedBuiltin?: MergedBuiltinStore,
  customLists?: CustomList[]
) {
  try {
    const payload: any = {};
    if (mergedBuiltin) payload.mergedBuiltin = mergedBuiltin;
    if (customLists) payload.customLists = customLists;

    await fetch('/api/save-permanent-records', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
  } catch (e) {
    console.warn('[Storage] Server persistence notice (running in offline mode):', e);
  }
}

export async function syncWithServerPermanentStorage(): Promise<boolean> {
  try {
    const res = await fetch('/api/permanent-records');
    if (!res.ok) return false;
    const data = await res.json();
    let updated = false;

    if (data.mergedBuiltin && Object.keys(data.mergedBuiltin).length > 0) {
      const current = getStoredMergedBuiltinRecords();
      const combined = { ...current, ...data.mergedBuiltin };
      localStorage.setItem(LS_MERGED_BUILTIN, JSON.stringify(combined));
      updated = true;
    }

    if (Array.isArray(data.customLists) && data.customLists.length > 0) {
      localStorage.setItem(LS_CUSTOM, JSON.stringify(data.customLists));
      updated = true;
    }

    return updated;
  } catch (e) {
    console.warn('[Storage] Permanent storage sync notice:', e);
    return false;
  }
}

export function addMergedBuiltinRecords(
  listKey: string,
  newRecords: Array<{ v: string; p: string; f1: string; f2: string; f3: string }>
): { addedCount: number; duplicateCount: number; totalInList: number; saved: boolean } {
  const currentStore = getStoredMergedBuiltinRecords();
  const existing = currentStore[listKey] || [];

  // Deduplication intentionally disabled: every uploaded/merged record is
  // kept as-is, even if it looks identical to an existing one. Village and
  // branch-office names can legitimately repeat (different lists, revised
  // sorting plans, etc.), so nothing is ever silently dropped here.
  const validNew: Array<{ v: string; p: string; f1: string; f2: string; f3: string }> = [];

  newRecords.forEach((r) => {
    const villageNames = splitVillageCell(r.v);
    villageNames.forEach((singleVillage) => {
      validNew.push({
        v: singleVillage,
        p: r.p,
        f1: r.f1,
        f2: r.f2,
        f3: r.f3
      });
    });
  });

  const merged = [...existing, ...validNew];
  currentStore[listKey] = merged;
  const saved = setStoredMergedBuiltinRecords(currentStore);

  // Permanently save to server disk so it embeds across all sessions & devices
  persistRecordsToServer(currentStore);

  return {
    addedCount: validNew.length,
    duplicateCount: 0,
    totalInList: merged.length,
    saved
  };
}

export function clearMergedBuiltinRecords(listKey?: string) {
  try {
    if (listKey) {
      const current = getStoredMergedBuiltinRecords();
      delete current[listKey];
      setStoredMergedBuiltinRecords(current);
      persistRecordsToServer(current);
    } else {
      localStorage.removeItem(LS_MERGED_BUILTIN);
      fetch('/api/reset-permanent-records', { method: 'POST' }).catch(() => {});
    }
  } catch (e) {
    console.error(e);
  }
}

export function compileInitialRecords(): { records: PostalRecord[]; lists: RawListMeta[] } {
  const allTuples = [
    ...RECORDS_MFL,
    ...RECORDS_UJJAIN,
    ...RECORDS_RATLAM,
    ...RECORDS_DHAR,
    ...RECORDS_KHANDWA,
    ...RECORDS_TD
  ];

  const lists: RawListMeta[] = RAW_LISTS.map((l) => ({ ...l }));
  const records: PostalRecord[] = [];

  // Deduplication intentionally disabled across this whole compile step: a
  // village/BO pairing that appears more than once (within built-in data,
  // across merged lists, or in a custom upload) is kept every time rather
  // than silently dropped.

  // 1. Process Built-in Tuples with multi-village cell splitting
  allTuples.forEach((t, tupleIdx) => {
    const listIndex = t[0];
    const isTd = t[1] === 1;
    const meta = RAW_LISTS[listIndex] || RAW_LISTS[0];
    const rawVillage = t[2] || '';
    const pincode = t[3] || '';
    const field1 = t[4] || '';
    const field2 = t[5] || '';
    const field3 = t[6] || '';

    // Split cell into individual village names if multiple are present
    const villageNames = splitVillageCell(rawVillage, isTd);

    villageNames.forEach((singleVillage, subIdx) => {
      const searchStr = `${singleVillage} ${pincode} ${field1} ${field2} ${field3} ${meta.name}`.toLowerCase();
      records.push({
        id: `builtin_${listIndex}_${tupleIdx}_${subIdx}`,
        listKey: meta.key,
        listName: meta.name,
        type: isTd ? 'td' : 'village',
        village: singleVillage,
        pincode,
        field1,
        field2,
        field3,
        searchStr
      });
    });
  });

  // 2. Append merged built-in records (e.g. Alirajpur/Jobat into Ratlam, Dewas Sub Dn into Dhar-Dewas, Indore MFL DN into Indore MFL)
  const mergedBuiltin = getStoredMergedBuiltinRecords();
  Object.entries(mergedBuiltin).forEach(([targetKey, recs]) => {
    const meta = lists.find((l) => l.key === targetKey) || {
      key: targetKey,
      name: targetKey,
      type: 'village' as const,
      count: 0
    };

    recs.forEach((r, idx) => {
      const villageNames = splitVillageCell(r.v, meta.type === 'td');
      villageNames.forEach((singleVillage, subIdx) => {
        const searchStr = `${singleVillage} ${r.p} ${r.f1} ${r.f2} ${r.f3} ${meta.name}`.toLowerCase();
        records.push({
          id: `merged_${targetKey}_${idx}_${subIdx}`,
          listKey: targetKey,
          listName: meta.name,
          type: meta.type,
          village: singleVillage,
          pincode: r.p,
          field1: r.f1,
          field2: r.f2,
          field3: r.f3,
          searchStr
        });
      });
    });
  });

  // 3. Append custom lists from storage
  const custom = getStoredCustomLists();
  custom.forEach((cl) => {
    lists.push({
      key: cl.key,
      name: cl.name,
      type: cl.type || 'village',
      count: 0
    });

    cl.records.forEach((r, rIdx) => {
      const villageNames = splitVillageCell(r.v, cl.type === 'td');
      villageNames.forEach((singleVillage, subIdx) => {
        const searchStr = `${singleVillage} ${r.p} ${r.f1} ${r.f2} ${r.f3} ${cl.name}`.toLowerCase();
        records.push({
          id: `custom_${cl.key}_${rIdx}_${subIdx}`,
          listKey: cl.key,
          listName: cl.name,
          type: cl.type || 'village',
          village: singleVillage,
          pincode: r.p,
          field1: r.f1,
          field2: r.f2,
          field3: r.f3,
          searchStr
        });
      });
    });
  });

  // 4. Dynamically compute the exact active record counts for each list
  lists.forEach((l) => {
    l.count = records.filter((r) => r.listKey === l.key).length;
  });

  return { records, lists };
}
