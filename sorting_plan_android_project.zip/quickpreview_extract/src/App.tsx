import { useState, useMemo, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { SearchBar } from './components/SearchBar';
import { RecordCard } from './components/RecordCard';
import { AddListModal } from './components/AddListModal';
import { ManageListsModal } from './components/ManageListsModal';
import { PostalHelper } from './components/PostalHelper';
import { TrackingModal } from './components/TrackingModal';
import { AddressFinderModal } from './components/AddressFinderModal';
import { WelcomeModal } from './components/WelcomeModal';
import { OfflineBanner } from './components/OfflineBanner';
import { OfficeDirectoryModal } from './components/OfficeDirectoryModal';
import {
  compileInitialRecords,
  getStoredHidden,
  setStoredHidden,
  getStoredBookmarks,
  setStoredBookmarks,
  setStoredCustomLists,
  getStoredCustomLists,
  addMergedBuiltinRecords,
  syncWithServerPermanentStorage,
  CustomList
} from './data/store';
import { PostalRecord, RawListMeta } from './data/types';
import { Mail, Bookmark, Sparkles, ChevronDown, Check, Package, MapPin } from 'lucide-react';
import { fuzzySearchRecords } from './utils/postalSearch';
import { safeStorage } from './utils/safeStorage';
import { useLanguage } from './i18n/LanguageContext';

export default function App() {
  const { t } = useLanguage();

  // --- Persistent Storage State ---
  const [dataState, setDataState] = useState(() => compileInitialRecords());
  const [hiddenKeys, setHiddenKeys] = useState<string[]>(() => getStoredHidden());
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => getStoredBookmarks());
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const prefersDark = typeof window.matchMedia === 'function' && window.matchMedia('(prefers-color-scheme: dark)').matches;
      return safeStorage.getItem('sp_theme') === 'dark' || (!safeStorage.has('sp_theme') && prefersDark);
    }
    return false;
  });

  // --- Filtering & Search State ---
  const [query, setQuery] = useState('');
  // The input box always shows `query` immediately for instant typing
  // feedback. The actual (expensive, 20k+ record) search only re-runs
  // ~180ms after the user stops typing, using `debouncedQuery` — this
  // keeps typing smooth on lower-end phones with the full embedded dataset.
  const [debouncedQuery, setDebouncedQuery] = useState('');
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedQuery(query), 180);
    return () => clearTimeout(timer);
  }, [query]);
  const [selectedList, setSelectedList] = useState('__all__');
  const [selectedField, setSelectedField] = useState('all');
  const [activePincode, setActivePincode] = useState('');
  const [showOnlyBookmarks, setShowOnlyBookmarks] = useState(false);
  const [pageLimit, setPageLimit] = useState(60);

  // --- Modal Visibility State ---
  const [isAddListOpen, setIsAddListOpen] = useState(false);
  const [isManageOpen, setIsManageOpen] = useState(false);
  const [isHelperOpen, setIsHelperOpen] = useState(false);
  const [isTrackingOpen, setIsTrackingOpen] = useState(false);
  const [isAddressFinderOpen, setIsAddressFinderOpen] = useState(false);
  const [isOfficeDirectoryOpen, setIsOfficeDirectoryOpen] = useState(false);
  const [directoryInitialOffice, setDirectoryInitialOffice] = useState('');
  const [isWelcomeOpen, setIsWelcomeOpen] = useState(() => {
    if (typeof window !== 'undefined') {
      return !safeStorage.getItem('sp_welcome_seen');
    }
    return false;
  });
  const [addressFinderInitialQuery, setAddressFinderInitialQuery] = useState('');
  const [addressFinderContextRecord, setAddressFinderContextRecord] = useState<PostalRecord | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const handleCloseWelcome = useCallback(() => {
    setIsWelcomeOpen(false);
    if (typeof window !== 'undefined') {
      safeStorage.setItem('sp_welcome_seen', 'true');
    }
  }, []);

  const handleOpenAddressFinder = useCallback((options?: { query?: string; record?: PostalRecord }) => {
    setAddressFinderInitialQuery(options?.query || '');
    setAddressFinderContextRecord(options?.record || null);
    setIsAddressFinderOpen(true);
  }, []);

  const handleOpenOfficeDirectory = useCallback((officeName?: string) => {
    setDirectoryInitialOffice(officeName || '');
    setIsOfficeDirectoryOpen(true);
  }, []);

  // Sync Dark Mode class to <html>
  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      safeStorage.setItem('sp_theme', 'dark');
    } else {
      root.classList.remove('dark');
      safeStorage.setItem('sp_theme', 'light');
    }
  }, [isDark]);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2800);
  }, []);

  // Reload data when custom lists or built-in changes occur
  const reloadData = useCallback(() => {
    setDataState(compileInitialRecords());
  }, []);

  // Sync permanent storage from server on startup (cross-device & persistent)
  useEffect(() => {
    syncWithServerPermanentStorage().then((hasUpdates) => {
      if (hasUpdates) {
        reloadData();
      }
    });
  }, [reloadData]);

  // Filter available lists based on hidden keys
  const visibleLists = useMemo(() => {
    return dataState.lists.filter((l) => !hiddenKeys.includes(l.key));
  }, [dataState.lists, hiddenKeys]);

  // Derive top 8 popular pincodes for quick filter buttons
  const popularPincodes = useMemo(() => {
    const countMap: Record<string, number> = {};
    for (const r of dataState.records) {
      if (r.pincode && r.pincode.length === 6) {
        countMap[r.pincode] = (countMap[r.pincode] || 0) + 1;
      }
    }
    return Object.entries(countMap)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(([pin]) => pin);
  }, [dataState.records]);

  // Main search and filter algorithm with fuzzy and phonetic matching
  const filteredRecords = useMemo(() => {
    const q = debouncedQuery.trim();
    const pinFilter = activePincode.trim();

    // 1. Fast scope filtering (hidden lists, division selection, bookmarks, quick pin)
    const baseCandidates = dataState.records.filter((r) => {
      if (hiddenKeys.includes(r.listKey)) return false;
      if (selectedList !== '__all__' && r.listKey !== selectedList) return false;
      if (showOnlyBookmarks && !bookmarkedIds.includes(r.id)) return false;
      if (pinFilter && r.pincode !== pinFilter) return false;
      return true;
    });

    if (!q) return baseCandidates;

    // 2. Field-specific extractor
    let extractor: ((record: PostalRecord) => string) | undefined;
    switch (selectedField) {
      case 'v':
        extractor = (r) => r.village;
        break;
      case 'p':
        extractor = (r) => r.pincode;
        break;
      case 'f1':
        extractor = (r) => r.field1;
        break;
      case 'f2':
        extractor = (r) => r.field2;
        break;
      case 'f3':
        extractor = (r) => r.field3;
        break;
      case 'all':
      default:
        extractor = undefined;
        break;
    }

    // 3. Fuzzy & Phonetic search (e.g. 'sanwar' -> 'Sanwer', Devanagari 'सांवेर' -> 'Sanwer')
    return fuzzySearchRecords(baseCandidates, q, extractor);
  }, [
    dataState.records,
    hiddenKeys,
    selectedList,
    showOnlyBookmarks,
    bookmarkedIds,
    activePincode,
    debouncedQuery,
    selectedField
  ]);

  // Lightweight "while you type" suggestion list — a small, fast top-N
  // fuzzy/phonetic match (reuses the same typo-tolerant search as the main
  // list, see src/utils/postalSearch.ts) so the user can see and pick the
  // exact spelling they want, or get a typo correction, before committing
  // to a full search. Debounced the same way as the main list.
  const suggestions = useMemo(() => {
    const q = debouncedQuery.trim();
    if (q.length < 2) return [];
    const scope = hiddenKeys.length
      ? dataState.records.filter((r) => !hiddenKeys.includes(r.listKey))
      : dataState.records;
    // Typed digits -> suggest matching PIN codes; otherwise suggest by
    // village/locality name only (so the dropdown lists the names a user
    // can actually pick, not every village served by a matching office).
    const byPin = /^\d+$/.test(q);
    const pool = fuzzySearchRecords(scope, q, byPin ? (r) => r.pincode : (r) => r.village);
    return pool.slice(0, 7);
  }, [dataState.records, hiddenKeys, debouncedQuery]);

  // True when none of the suggestions contain the typed text as an exact
  // whole word — i.e. every suggestion shown is a typo-correction, not a
  // literal match, so the UI can label them "Did you mean" instead of
  // "Suggestions".
  const suggestionsAreCorrections = useMemo(() => {
    const q = debouncedQuery.trim().toLowerCase();
    if (!q || suggestions.length === 0) return false;
    return !suggestions.some((r) => r.village.toLowerCase().split(/\s+/).includes(q));
  }, [suggestions, debouncedQuery]);

  // Reset pagination when search parameters change
  useEffect(() => {
    setPageLimit(60);
  }, [debouncedQuery, selectedList, selectedField, activePincode, showOnlyBookmarks]);

  // Toggle Bookmark
  const handleToggleBookmark = useCallback(
    (id: string) => {
      setBookmarkedIds((prev) => {
        const next = prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id];
        setStoredBookmarks(next);
        return next;
      });
    },
    []
  );

  // Toggle List Visibility in Manage Modal
  const handleToggleList = useCallback((key: string) => {
    setHiddenKeys((prev) => {
      const next = prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key];
      setStoredHidden(next);
      return next;
    });
  }, []);

  // Add Custom List
  const handleAddList = useCallback(
    (newList: CustomList) => {
      const current = getStoredCustomLists();
      const updated = [...current, newList];
      setStoredCustomLists(updated);
      reloadData();
      showToast(`Added list "${newList.name}" with ${newList.records.length} records`);
    },
    [reloadData, showToast]
  );

  // Merge into Built-in Regional List
  const handleMergeBuiltinList = useCallback(
    (
      targetKey: string,
      records: Array<{ v: string; p: string; f1: string; f2: string; f3: string }>
    ) => {
      const res = addMergedBuiltinRecords(targetKey, records);
      reloadData();
      showToast(`Merged ${res.addedCount} new records into postal sorting plan!`);
      return res;
    },
    [reloadData, showToast]
  );

  // Delete Custom List
  const handleDeleteCustomList = useCallback(
    (key: string) => {
      const current = getStoredCustomLists();
      const updated = current.filter((l) => l.key !== key);
      setStoredCustomLists(updated);
      reloadData();
      showToast('Custom list removed');
    },
    [reloadData, showToast]
  );

  // Reset Hidden Lists
  const handleResetDefaults = useCallback(() => {
    setHiddenKeys([]);
    setStoredHidden([]);
    showToast('All default lists are now visible');
  }, [showToast]);

  // Export current filtered results to CSV
  const handleExportCsv = useCallback(() => {
    if (filteredRecords.length === 0) {
      showToast('No records to export');
      return;
    }

    const headers = ['Division/List', 'Area/Village', 'Pincode', 'Field1 (BO/House)', 'Field2 (SO/Beat)', 'Field3 (HO/Delivery Office)'];
    const rows = filteredRecords.map((r) => [
      `"${r.listName.replace(/"/g, '""')}"`,
      `"${r.village.replace(/"/g, '""')}"`,
      `"${r.pincode}"`,
      `"${r.field1.replace(/"/g, '""')}"`,
      `"${r.field2.replace(/"/g, '""')}"`,
      `"${r.field3.replace(/"/g, '""')}"`
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((row) => row.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Sorting_Plan_Export_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast(`Exported ${filteredRecords.length} records to CSV`);
  }, [filteredRecords, showToast]);

  // Trigger Print View
  const handlePrint = useCallback(() => {
    window.print();
  }, []);

  const renderedRecords = filteredRecords.slice(0, pageLimit);
  const hasMore = pageLimit < filteredRecords.length;

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF7F2] dark:bg-[#1C1512] text-[#241A17] dark:text-[#F4ECE5] transition-colors app-safe-top app-safe-bottom">
      
      {/* Offline Status Alert Banner */}
      <OfflineBanner />

      {/* App Header */}
      <Header
        totalRecordsCount={dataState.records.length}
        activeListsCount={visibleLists.length}
        bookmarkedCount={bookmarkedIds.length}
        showOnlyBookmarks={showOnlyBookmarks}
        onToggleBookmarks={() => setShowOnlyBookmarks(!showOnlyBookmarks)}
        onOpenAddList={() => setIsAddListOpen(true)}
        onOpenManageLists={() => setIsManageOpen(true)}
        onOpenTracking={() => setIsTrackingOpen(true)}
        onOpenAddressFinder={() => handleOpenAddressFinder()}
        onOpenOfficeDirectory={() => handleOpenOfficeDirectory()}
        onOpenWelcome={() => setIsWelcomeOpen(true)}
        onExportCsv={handleExportCsv}
        onPrint={handlePrint}
        isDark={isDark}
        onToggleDark={() => setIsDark(!isDark)}
      />

      {/* Search & Scope Filters */}
      <SearchBar
        query={query}
        onQueryChange={setQuery}
        suggestions={suggestions}
        suggestionsAreCorrections={suggestionsAreCorrections}
        onSelectSuggestion={(record) => {
          setQuery(record.village);
          setDebouncedQuery(record.village);
        }}
        selectedList={selectedList}
        onListChange={setSelectedList}
        selectedField={selectedField}
        onFieldChange={setSelectedField}
        availableLists={visibleLists}
        popularPincodes={popularPincodes}
        activePincode={activePincode}
        onSelectPincode={setActivePincode}
        totalFilteredCount={filteredRecords.length}
        onOpenTrackingWithNumber={(num) => {
          setIsTrackingOpen(true);
        }}
        onOpenAddressFinderWithQuery={(q) => handleOpenAddressFinder({ query: q })}
        onShowToast={showToast}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-3 pb-24">
        
        {/* Bookmarks banner when active */}
        {showOnlyBookmarks && (
          <div className="mb-4 p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-900/60 flex items-center justify-between text-xs sm:text-sm text-amber-900 dark:text-amber-200">
            <div className="flex items-center gap-2">
              <Bookmark className="w-4 h-4 text-amber-600 fill-current" />
              <span>
                {t('app.pinnedBanner', { count: filteredRecords.length })}
              </span>
            </div>
            <button
              onClick={() => setShowOnlyBookmarks(false)}
              className="text-xs font-bold underline hover:opacity-80"
            >
              {t('app.showAllRecords')}
            </button>
          </div>
        )}

        {/* Empty State */}
        {filteredRecords.length === 0 ? (
          <div className="text-center py-16 px-4">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-amber-100 dark:bg-stone-800 text-[#8E1B25] dark:text-amber-400 flex items-center justify-center">
              <Mail className="w-8 h-8 opacity-75" />
            </div>
            <h3 className="text-lg font-bold text-stone-900 dark:text-stone-100">
              {t('app.noMatchingOffices')}
            </h3>
            <p className="mt-1 text-xs sm:text-sm text-stone-500 dark:text-stone-400 max-w-md mx-auto">
              {t('app.couldntFind')}
            </p>
            <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
              {query.trim() && (
                <button
                  onClick={() => handleOpenAddressFinder({ query })}
                  className="px-4 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <MapPin className="w-3.5 h-3.5" />
                  <span>{t('app.tryAddressFinder', { query: query.trim() })}</span>
                </button>
              )}
              <button
                onClick={() => {
                  setQuery('');
                  setSelectedList('__all__');
                  setSelectedField('all');
                  setActivePincode('');
                  setShowOnlyBookmarks(false);
                }}
                className="px-4 py-2 text-xs font-bold text-white bg-[#8E1B25] hover:bg-[#6F151C] rounded-lg shadow-xs transition-colors"
              >
                {t('app.clearAllFilters')}
              </button>
              <button
                onClick={() => setIsAddListOpen(true)}
                className="px-4 py-2 text-xs font-semibold text-stone-700 dark:text-stone-300 bg-stone-200/80 dark:bg-stone-800 hover:bg-stone-300 rounded-lg transition-colors"
              >
                {t('app.uploadMissingList')}
              </button>
            </div>
          </div>
        ) : (
          /* Cards Grid */
          <div className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {renderedRecords.map((record) => (
                <RecordCard
                  key={record.id}
                  record={record}
                  query={query}
                  isBookmarked={bookmarkedIds.includes(record.id)}
                  onToggleBookmark={handleToggleBookmark}
                  onOpenAddressFinder={(rec) =>
                    handleOpenAddressFinder({
                      query: `${rec.village}, ${rec.field2 || ''}, PIN ${rec.pincode}`,
                      record: rec,
                    })
                  }
                  onViewOfficeVillages={(officeName) => handleOpenOfficeDirectory(officeName)}
                />
              ))}
            </div>

            {/* Load More Pagination Button */}
            {hasMore && (
              <div className="pt-4 text-center">
                <button
                  onClick={() => setPageLimit((prev) => prev + 60)}
                  className="inline-flex items-center gap-1.5 px-6 py-2.5 text-xs sm:text-sm font-bold text-[#8E1B25] dark:text-amber-400 bg-white dark:bg-[#261C18] border border-stone-300 dark:border-stone-700 hover:bg-stone-50 dark:hover:bg-stone-800 rounded-xl shadow-xs transition-all active:scale-95"
                >
                  <span>{t('app.loadMore', { count: filteredRecords.length - pageLimit })}</span>
                  <ChevronDown className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

      </main>

      {/* Floating Helper & Tracking Pills at Bottom-Left */}
      <aside aria-label="Quick Actions" className="fixed bottom-4 left-4 z-20 flex items-center gap-2 flex-wrap">
        <button
          onClick={() => handleOpenAddressFinder()}
          className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold bg-amber-400 text-stone-900 border border-amber-500 rounded-xl shadow-md hover:bg-amber-300 transition-transform active:scale-95 cursor-pointer"
          title="Pincode & Address Finder"
        >
          <MapPin className="w-3.5 h-3.5 text-[#8E1B25]" />
          <span>Find Address</span>
        </button>

        <button
          onClick={() => setIsTrackingOpen(true)}
          className="flex items-center gap-1.5 px-3 py-2 text-xs font-bold bg-[#8E1B25] text-white border border-[#6F151C] rounded-xl shadow-md hover:bg-[#6F151C] transition-transform active:scale-95 cursor-pointer"
          title="Track India Post Article"
        >
          <Package className="w-3.5 h-3.5" />
          <span>Track Article</span>
        </button>

        <button
          onClick={() => setIsHelperOpen(true)}
          className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold bg-white dark:bg-[#261C18] text-stone-700 dark:text-stone-300 border border-stone-200 dark:border-stone-800 rounded-xl shadow-md hover:bg-stone-50 dark:hover:bg-stone-800 transition-transform active:scale-95 cursor-pointer"
          title="Postal sorting guide & terminology"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#F2B705]" />
          <span>Postal Guide</span>
        </button>
      </aside>

      {/* Toast Notification */}
      {toastMessage && (
        <aside aria-label="Notification" className="fixed bottom-4 right-4 z-50 flex items-center gap-2 px-4 py-2.5 bg-stone-900 text-white text-xs sm:text-sm font-medium rounded-xl shadow-xl animate-fade-in border border-stone-800">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </aside>
      )}

      {/* Modals */}
      <AddListModal
        isOpen={isAddListOpen}
        onClose={() => setIsAddListOpen(false)}
        onAddList={handleAddList}
        onMergeBuiltinList={handleMergeBuiltinList}
        availableLists={visibleLists}
      />

      <ManageListsModal
        isOpen={isManageOpen}
        onClose={() => setIsManageOpen(false)}
        allLists={dataState.lists}
        hiddenKeys={hiddenKeys}
        onToggleList={handleToggleList}
        onDeleteCustomList={handleDeleteCustomList}
        onResetDefaults={handleResetDefaults}
      />

      <PostalHelper
        isOpen={isHelperOpen}
        onClose={() => setIsHelperOpen(false)}
      />

      <TrackingModal
        isOpen={isTrackingOpen}
        onClose={() => setIsTrackingOpen(false)}
        onShowToast={showToast}
      />

      <AddressFinderModal
        isOpen={isAddressFinderOpen}
        onClose={() => setIsAddressFinderOpen(false)}
        initialQuery={addressFinderInitialQuery}
        contextRecord={addressFinderContextRecord}
        records={dataState.records}
        onSelectPincode={(pin) => {
          setActivePincode(pin);
          setSelectedList('__all__');
          setQuery('');
        }}
        onShowToast={showToast}
      />

      <OfficeDirectoryModal
        isOpen={isOfficeDirectoryOpen}
        onClose={() => setIsOfficeDirectoryOpen(false)}
        allRecords={dataState.records}
        initialOfficeName={directoryInitialOffice}
        onSelectOfficeInMainSearch={(office) => {
          setSelectedList('__all__');
          setSelectedField('all');
          setQuery(office);
          showToast(`Filtered sorting plan for "${office}"`);
        }}
        onOpenAddressFinder={(q) => handleOpenAddressFinder({ query: q })}
        onShowToast={showToast}
      />

      <WelcomeModal
        isOpen={isWelcomeOpen}
        onClose={handleCloseWelcome}
        onOpenAddressFinder={() => handleOpenAddressFinder()}
        totalRecordsCount={dataState.records.length}
      />

    </div>
  );
}
