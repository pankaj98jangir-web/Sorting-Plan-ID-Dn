import { useState, useRef, useEffect, useCallback } from 'react';
import { normalizeSpokenVoice } from '../utils/postalSearch';
import { isFileProtocol, isSecureContextForMedia } from '../utils/runtimeEnv';
import { isNativeApp } from '../utils/native';
import { SpeechRecognition as NativeSpeech } from '@capacitor-community/speech-recognition';

// Global declaration for Web Speech API
declare global {
  interface Window {
    SpeechRecognition?: any;
    webkitSpeechRecognition?: any;
  }
}

export type VoiceLanguage = 'hi-IN' | 'en-IN';

interface UseVoiceSearchProps {
  onTranscript: (cleanedText: string) => void;
  onError?: (errorMessage: string) => void;
}

export function useVoiceSearch({ onTranscript, onError }: UseVoiceSearchProps) {
  const [isListening, setIsListening] = useState(false);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [lang, setLang] = useState<VoiceLanguage>(() => {
    try {
      const saved = localStorage.getItem('sp_voice_lang');
      return (saved === 'en-IN' ? 'en-IN' : 'hi-IN') as VoiceLanguage;
    } catch {
      return 'hi-IN';
    }
  });

  const recognitionRef = useRef<any>(null);
  // file:// pages auto-deny microphone access with no permission prompt in
  // most browsers (see isFileProtocol doc) — treat voice search as
  // unsupported there so the mic button is hidden instead of offering a
  // feature that will always fail with a confusing error.
  const native = isNativeApp();
  const isSupported =
    native ||
    (typeof window !== 'undefined' && !isFileProtocol() && Boolean(
      window.SpeechRecognition || window.webkitSpeechRecognition
    ));

  const saveLang = (newLang: VoiceLanguage) => {
    setLang(newLang);
    try {
      localStorage.setItem('sp_voice_lang', newLang);
    } catch (e) {
      console.error(e);
    }
  };

  const stopListening = useCallback(() => {
    if (native) {
      NativeSpeech.stop().catch(() => {});
      return;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch (e) {
        console.error(e);
      }
    }
    setIsListening(false);
    setInterimTranscript('');
  }, []);

  const startListening = useCallback(async () => {
    if (!isSupported) {
      onError?.('Voice search is not supported in this browser. Please use Google Chrome or Microsoft Edge.');
      return;
    }

    // ---- Packaged Android/iOS app: use the device's own speech engine ----
    if (native) {
      try {
        const { available } = await NativeSpeech.available();
        if (!available) {
          onError?.('Speech recognition is not available on this phone. Install/enable the Google app (Google Speech Services) and try again.');
          return;
        }

        let perm = await NativeSpeech.checkPermissions();
        if (perm.speechRecognition !== 'granted') {
          perm = await NativeSpeech.requestPermissions();
        }
        if (perm.speechRecognition !== 'granted') {
          onError?.('Microphone permission is off. Open Settings → Apps → this app → Permissions → Microphone → Allow.');
          return;
        }

        await NativeSpeech.removeAllListeners();
        let lastHeard = '';

        await NativeSpeech.addListener('partialResults', (data) => {
          lastHeard = data.matches?.[0] || '';
          setInterimTranscript(lastHeard);
        });

        await NativeSpeech.addListener('listeningState', (data) => {
          if (data.status === 'started') {
            setIsListening(true);
            setInterimTranscript('');
          } else {
            setIsListening(false);
            setInterimTranscript('');
            const cleaned = normalizeSpokenVoice(lastHeard);
            lastHeard = '';
            NativeSpeech.removeAllListeners().catch(() => {});
            if (cleaned) {
              onTranscript(cleaned);
            } else {
              onError?.('No voice speech was detected. Please tap the mic and speak again.');
            }
          }
        });

        await NativeSpeech.start({
          language: lang,
          maxResults: 1,
          partialResults: true,
          popup: false,
        });
      } catch (err: any) {
        setIsListening(false);
        setInterimTranscript('');
        onError?.(`Voice search failed: ${err?.message || 'unknown error'}`);
      }
      return;
    }

    if (!isSecureContextForMedia()) {
      // Chrome silently blocks mic access outside a secure context (https,
      // localhost, or file:) — most commonly when the app is opened over
      // plain http:// at a LAN IP (e.g. http://192.168.x.x:5173 on a
      // phone). A permission prompt can still appear in some Chrome
      // versions even here, but the mic never actually works — so this is
      // called out explicitly instead of a generic "denied" message.
      onError?.('Mic needs a secure connection (https:// or localhost). It will not work over a plain http:// address — even if Chrome shows a permission prompt.');
      return;
    }

    // Stop any existing instance
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch {
        // Ignore
      }
    }

    // Explicitly request mic access via getUserMedia first, and close that
    // stream immediately. This "warms up" the permission in Chrome before
    // handing off to SpeechRecognition — Chrome's own speech-recognition
    // permission handling is known to be flaky/inconsistent on its own
    // (it can fire 'not-allowed' even when the page's general microphone
    // permission is already set to Allow in site settings), and this
    // explicit request surfaces a real, fresh browser permission prompt and
    // a clear, specific error if the user has actually blocked the mic.
    if (navigator.mediaDevices?.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((t) => t.stop());
      } catch (mediaErr: any) {
        if (mediaErr?.name === 'NotAllowedError' || mediaErr?.name === 'PermissionDeniedError') {
          onError?.('Microphone access is blocked for this site. Tap the lock/info icon next to the address bar → Permissions → Microphone → Allow, then try again.');
        } else if (mediaErr?.name === 'NotFoundError') {
          onError?.('No microphone was found on this device.');
        } else {
          onError?.('Unable to access the microphone. Please check your device/browser settings.');
        }
        return;
      }
    }

    const SpeechRecClass = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecClass();
    recognitionRef.current = recognition;

    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = lang;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
      setIsListening(true);
      setInterimTranscript('');
    };

    recognition.onresult = (event: any) => {
      let currentInterim = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript;
        } else {
          currentInterim += transcript;
        }
      }

      if (currentInterim) {
        setInterimTranscript(currentInterim);
      }

      if (finalTranscript) {
        const cleaned = normalizeSpokenVoice(finalTranscript);
        if (cleaned) {
          onTranscript(cleaned);
        }
      }
    };

    recognition.onerror = (event: any) => {
      console.warn('Speech recognition error:', event.error);
      setIsListening(false);
      setInterimTranscript('');

      if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
        onError?.('Microphone access was denied. Tap the lock/info icon next to the address bar → Permissions → Microphone → Allow, then try again.');
      } else if (event.error === 'no-speech') {
        onError?.('No voice speech was detected. Please click the mic and speak again.');
      } else if (event.error === 'network') {
        onError?.('Voice search requires an active internet connection.');
      } else {
        onError?.(`Voice search error: ${event.error || 'unknown'}`);
      }
    };

    recognition.onend = () => {
      setIsListening(false);
      setInterimTranscript('');
    };

    try {
      recognition.start();
    } catch (err: any) {
      console.error('Failed to start speech recognition:', err);
      setIsListening(false);
      onError?.('Unable to start microphone. Please try again.');
    }
  }, [isSupported, native, lang, onError, onTranscript]);

  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // Cleanup
        }
      }
    };
  }, []);

  return {
    isSupported,
    isListening,
    interimTranscript,
    lang,
    setLang: saveLang,
    startListening,
    stopListening
  };
}
