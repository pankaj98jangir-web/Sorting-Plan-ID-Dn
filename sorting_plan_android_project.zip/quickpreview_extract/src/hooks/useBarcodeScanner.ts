import { useCallback, useRef, useState } from 'react';
import { isFileProtocol, isSecureContextForMedia } from '../utils/runtimeEnv';
import { isNativeApp } from '../utils/native';
import { BarcodeScanner } from '@capacitor-mlkit/barcode-scanning';

// BarcodeDetector isn't in TypeScript's default DOM lib yet — declare the
// minimal shape we use.
interface DetectedBarcode {
  rawValue: string;
}
interface BarcodeDetectorLike {
  detect(source: CanvasImageSource): Promise<DetectedBarcode[]>;
}
declare global {
  interface Window {
    BarcodeDetector?: new (options?: { formats?: string[] }) => BarcodeDetectorLike;
  }
}

/**
 * Packaged app only: opens the phone's native ML Kit scanner (full-screen,
 * autofocus, torch support) and resolves with the first barcode's text, or
 * null if the user cancelled. Throws an Error with a user-readable message.
 */
export async function scanBarcodeNative(): Promise<string | null> {
  const { supported } = await BarcodeScanner.isSupported();
  if (!supported) {
    throw new Error('Barcode scanning is not supported on this phone.');
  }

  const perm = await BarcodeScanner.requestPermissions();
  if (perm.camera !== 'granted' && perm.camera !== 'limited') {
    throw new Error('Camera permission is off. Open Settings → Apps → this app → Permissions → Camera → Allow.');
  }

  const { available } = await BarcodeScanner.isGoogleBarcodeScannerModuleAvailable();
  if (!available) {
    // One-time download of Google's scanner module (needs internet).
    await BarcodeScanner.installGoogleBarcodeScannerModule();
    throw new Error('Scanner component is being installed by Google Play services. Please wait a minute and tap scan again.');
  }

  const { barcodes } = await BarcodeScanner.scan();
  const first = barcodes?.[0];
  return first ? (first.rawValue || first.displayValue || null) : null;
}

export function isBarcodeScanningSupported(): boolean {
  if (isNativeApp()) return true;
  return (
    typeof window !== 'undefined' &&
    !isFileProtocol() &&
    Boolean(window.BarcodeDetector) &&
    Boolean(navigator.mediaDevices?.getUserMedia)
  );
}

/**
 * Scans barcodes/QR codes using the device camera, entirely on-device via the
 * native BarcodeDetector API — no network call and no extra library needed.
 * Useful for reading India Post consignment/article number labels directly
 * instead of typing them in.
 *
 * Support: modern Chromium-based browsers and the Android System WebView
 * used by Capacitor/TWA-packaged apps (roughly Chrome/WebView 83+). Not
 * supported in Firefox or Safari — `isSupported` reflects that so callers
 * can hide the scan button instead of showing one that always fails.
 *
 * Usage contract: render the `<video ref={videoRef} />` element
 * unconditionally for as long as the scanner UI is mounted (it can be
 * visually hidden, but must exist in the DOM) before calling `start()`,
 * since the camera stream is attached to it directly.
 */
export function useBarcodeScanner(onDetect: (value: string) => void) {
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const detectorRef = useRef<BarcodeDetectorLike | null>(null);

  const isSupported = isBarcodeScanningSupported();

  const stop = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = null;
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsScanning(false);
  }, []);

  const start = useCallback(async () => {
    if (!isSupported) {
      setError('Barcode scanning is not supported on this device/browser.');
      return;
    }

    if (!isSecureContextForMedia()) {
      setError('Camera needs a secure connection (https:// or localhost). It will not work over a plain http:// address.');
      return;
    }

    setError(null);

    try {
      detectorRef.current = new window.BarcodeDetector!({
        formats: ['code_128', 'code_39', 'ean_13', 'ean_8', 'qr_code', 'itf', 'codabar']
      });

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      });
      streamRef.current = stream;

      if (!videoRef.current) {
        throw new Error('Camera preview element is not ready.');
      }
      videoRef.current.srcObject = stream;
      await videoRef.current.play();
      setIsScanning(true);

      const tick = async () => {
        if (!videoRef.current || !detectorRef.current) return;
        try {
          if (videoRef.current.readyState >= 2) {
            const codes = await detectorRef.current.detect(videoRef.current);
            if (codes.length > 0 && codes[0].rawValue) {
              onDetect(codes[0].rawValue);
              stop();
              return;
            }
          }
        } catch {
          // Transient per-frame detection errors are expected; keep scanning.
        }
        rafRef.current = requestAnimationFrame(tick);
      };

      rafRef.current = requestAnimationFrame(tick);
    } catch (err: any) {
      if (err?.name === 'NotAllowedError') {
        setError('Camera access is blocked for this site. Tap the lock/info icon next to the address bar → Permissions → Camera → Allow, then try again.');
      } else if (err?.name === 'NotFoundError') {
        setError('No camera was found on this device.');
      } else if (err?.name === 'NotReadableError') {
        setError('The camera is already in use by another app. Close it and try again.');
      } else {
        setError(err?.message || 'Unable to start the camera.');
      }
      setIsScanning(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isSupported, onDetect, stop]);

  return { isSupported, isScanning, error, videoRef, start, stop };
}
