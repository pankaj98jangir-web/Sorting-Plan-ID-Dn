import { useEffect, useRef } from 'react';

/**
 * Makes a modal close on the Android hardware/gesture back button instead of
 * exiting the whole app (the default behavior in a WebView-based APK when a
 * modal is just an absolutely-positioned <div> with no history entry of its
 * own) or navigating the underlying page away in a browser/PWA tab.
 *
 * How it works: when the modal opens we push one history entry. A back press
 * fires `popstate`, which we treat as "close this modal". We also listen for
 * the Cordova/Capacitor `backbutton` event as a fallback for shells that
 * don't route the hardware key through `popstate` automatically. If the
 * modal instead closes because the user tapped "X" / Save / the backdrop, we
 * pop the extra history entry ourselves in cleanup so back-stacks don't grow.
 */
export function useModalBackButton(isOpen: boolean, onClose: () => void): void {
  const closedByBackRef = useRef(false);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    if (!isOpen) return;

    closedByBackRef.current = false;
    window.history.pushState({ modal: true }, '');

    const handlePopState = () => {
      closedByBackRef.current = true;
      onCloseRef.current();
    };

    const handleHardwareBack = (e: Event) => {
      e.preventDefault?.();
      closedByBackRef.current = true;
      onCloseRef.current();
    };

    window.addEventListener('popstate', handlePopState);
    document.addEventListener('backbutton', handleHardwareBack as EventListener);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      document.removeEventListener('backbutton', handleHardwareBack as EventListener);
      if (!closedByBackRef.current) {
        window.history.back();
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen]);
}
