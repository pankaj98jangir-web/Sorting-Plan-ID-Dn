// api.postalpincode.in is a free, public, no-authentication India Post
// pincode directory (CORS-open, so it can be called directly from the
// browser — no backend proxy needed). It only resolves an exact 6-digit
// PIN code to its post offices/district/state; it has no fuzzy address
// matching or AI reasoning. This is the only online address/pincode lookup
// in the app — Google Maps and Gemini AI grounding were removed.

export interface FreePincodeOffice {
  name: string;
  branchType: string;
  district: string;
  state: string;
  division: string;
  region: string;
}

export interface FreePincodeResult {
  pincode: string;
  offices: FreePincodeOffice[];
}

/** Pulls the first plausible 6-digit Indian PIN code out of free-form text. */
export function extractPincode(text: string): string | null {
  const match = text.match(/\b([1-9][0-9]{5})\b/);
  return match ? match[1] : null;
}

export async function lookupPincodeFree(pincode: string): Promise<FreePincodeResult | null> {
  const res = await fetch(`https://api.postalpincode.in/pincode/${encodeURIComponent(pincode)}`);
  if (!res.ok) return null;

  const data = await res.json();
  const entry = Array.isArray(data) ? data[0] : null;
  if (!entry || entry.Status !== 'Success' || !Array.isArray(entry.PostOffice) || entry.PostOffice.length === 0) {
    return null;
  }

  return {
    pincode,
    offices: entry.PostOffice.map((po: any) => ({
      name: po.Name || 'N/A',
      branchType: po.BranchType || 'N/A',
      district: po.District || 'N/A',
      state: po.State || 'N/A',
      division: po.Division || 'N/A',
      region: po.Region || 'N/A'
    }))
  };
}

