/**
 * Postal Search Engine with Fuzzy, Phonetic, Hinglish, and Hindi Devanagari matching.
 * Specifically tuned for India Post Indore Region (Malwa / Nimar place names).
 */

// Devanagari to Latin Transliteration Table
const DEVANAGARI_CHARS: Record<string, string> = {
  'अ': 'a', 'आ': 'aa', 'इ': 'i', 'ई': 'ee', 'उ': 'u', 'ऊ': 'oo', 'ऋ': 'ri',
  'ए': 'e', 'ऐ': 'ai', 'ओ': 'o', 'औ': 'au', 'अं': 'an', 'अः': 'ah',
  'क': 'k', 'ख': 'kh', 'ग': 'g', 'घ': 'gh', 'ङ': 'ng',
  'च': 'ch', 'छ': 'chh', 'ज': 'j', 'झ': 'jh', 'ञ': 'ny',
  'ट': 't', 'ठ': 'th', 'ड': 'd', 'ढ': 'dh', 'ण': 'n',
  'त': 't', 'थ': 'th', 'द': 'd', 'ध': 'dh', 'न': 'n',
  'प': 'p', 'फ': 'ph', 'ब': 'b', 'भ': 'bh', 'म': 'm',
  'य': 'y', 'र': 'r', 'ल': 'l', 'व': 'v', 'श': 'sh', 'ष': 'sh', 'स': 's', 'ह': 'h',
  'क़': 'q', 'ख़': 'kh', 'ग़': 'gh', 'ज़': 'z', 'ड़': 'd', 'ढ़': 'dh', 'फ़': 'f',
  '०': '0', '१': '1', '२': '2', '३': '3', '४': '4', '५': '5', '६': '6', '७': '7', '८': '8', '९': '9',
};

const DEVANAGARI_MATRAS: Record<string, string> = {
  'ा': 'a', 'ि': 'i', 'ी': 'ee', 'ु': 'u', 'ू': 'oo', 'ृ': 'ri',
  'े': 'e', 'ै': 'ai', 'ो': 'o', 'ौ': 'au', 'ं': 'n', 'ँ': 'n', 'ः': 'h',
  '्': '' // Halant / Virama suppresses vowel
};

// Spoken Hindi numbers to digits (for voice input recognition)
const HINDI_NUMBER_WORDS: Record<string, string> = {
  'शून्य': '0', 'एक': '1', 'दो': '2', 'तीन': '3', 'चार': '4',
  'पांच': '5', 'पाँच': '5', 'छह': '6', 'छः': '6', 'सात': '7', 'आठ': '8', 'नौ': '9',
  'दस': '10', 'zero': '0', 'one': '1', 'two': '2', 'three': '3', 'four': '4',
  'five': '5', 'six': '6', 'seven': '7', 'eight': '8', 'nine': '9'
};

/**
 * Checks if a string contains Devanagari script characters
 */
export function hasDevanagari(text: string): boolean {
  return /[\u0900-\u097F]/.test(text);
}

/**
 * Transliterates Hindi Devanagari text into Latin / English characters.
 * Example: 'सांवेर' -> 'sanver'
 * Example: 'इंदौर' -> 'indor'
 */
export function transliterateDevanagari(text: string): string {
  let result = '';
  const len = text.length;
  
  for (let i = 0; i < len; i++) {
    const char = text[i];
    const nextChar = i + 1 < len ? text[i + 1] : '';

    if (DEVANAGARI_CHARS[char]) {
      result += DEVANAGARI_CHARS[char];
      // If the character is a consonant and next character is not a matra or halant,
      // it historically has an inherent 'a' in Sanskrit, but in Hindi placenames
      // end-of-word or certain joints don't need it.
      // We keep it clean without trailing spurious 'a's.
    } else if (DEVANAGARI_MATRAS[char] !== undefined) {
      result += DEVANAGARI_MATRAS[char];
    } else {
      result += char;
    }
  }

  return result.toLowerCase();
}

/**
 * Normalizes spoken voice query (e.g., replaces spoken digit words with digits)
 */
export function normalizeSpokenVoice(transcript: string): string {
  let cleaned = transcript.trim();

  // Replace spoken digit words in Hindi or English
  for (const [word, digit] of Object.entries(HINDI_NUMBER_WORDS)) {
    const regex = new RegExp(`\\b${word}\\b`, 'gi');
    cleaned = cleaned.replace(regex, digit);
  }

  // Remove common speech filler phrases like "पिन कोड", "पिनकोड", "pincode", "search for"
  cleaned = cleaned.replace(/\b(पिन\s*कोड|पिनकोड|pincode|pin\s*code|search\s*for|खोजो)\b/gi, ' ');

  // Collapse whitespace
  return cleaned.replace(/\s+/g, ' ').trim();
}

/**
 * Computes phonetic skeleton of an Indian English word.
 * - Maps 'w' and 'v' to 'v' (Sanwer <-> Sanwar <-> Sanver)
 * - Normalizes vowels to '*' so 'sanwar' and 'sanwer' produce identical 's*nv*r'
 * - Collapses duplicate letters ('ujjain' -> 'ujain')
 * - Maps 'ph' -> 'f', 'sh' -> 's', 'z' -> 'j'
 */
// Skeletons are pure functions of the word and the same ~40k distinct words
// are re-checked on every search, so cache them (big speed-up on phones).
const skeletonCache = new Map<string, string>();

export function getPhoneticSkeleton(rawWord: string): string {
  const cached = skeletonCache.get(rawWord);
  if (cached !== undefined) return cached;
  const result = computePhoneticSkeleton(rawWord);
  if (skeletonCache.size < 200000) skeletonCache.set(rawWord, result);
  return result;
}

function computePhoneticSkeleton(rawWord: string): string {
  let word = rawWord.toLowerCase().replace(/[^a-z0-9]/g, '');
  if (!word) return '';

  // 1. Common Indian consonant normalizations
  word = word.replace(/ph/g, 'f');
  word = word.replace(/sh/g, 's');
  word = word.replace(/w/g, 'v');
  word = word.replace(/z/g, 'j');
  word = word.replace(/kh/g, 'k');
  word = word.replace(/gh/g, 'g');
  word = word.replace(/bh/g, 'b');
  word = word.replace(/dh/g, 'd');
  word = word.replace(/th/g, 't');
  word = word.replace(/chh/g, 'ch');
  word = word.replace(/q/g, 'k');

  // 2. Collapse double consonants: e.g. jj -> j, tt -> t
  let collapsed = '';
  for (let i = 0; i < word.length; i++) {
    if (i === 0 || word[i] !== word[i - 1]) {
      collapsed += word[i];
    }
  }

  // 3. Map all vowels to '*'
  // E.g. 'sanwar' -> 's-a-n-v-a-r' -> 's*nv*r'
  // E.g. 'sanwer' -> 's-a-n-v-e-r' -> 's*nv*r'
  const skeleton = collapsed.replace(/[aeiou]/g, '*');

  return skeleton;
}

/**
 * Fast Levenshtein distance between two strings with early exit
 */
export function levenshteinDistance(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  
  const m = a.length;
  const n = b.length;
  if (Math.abs(m - n) > 2) return 99; // Fast exit if length difference too large

  const prevRow = new Int32Array(n + 1);
  const currRow = new Int32Array(n + 1);

  for (let j = 0; j <= n; j++) prevRow[j] = j;

  for (let i = 1; i <= m; i++) {
    currRow[0] = i;
    const aChar = a.charCodeAt(i - 1);
    for (let j = 1; j <= n; j++) {
      const cost = aChar === b.charCodeAt(j - 1) ? 0 : 1;
      currRow[j] = Math.min(
        currRow[j - 1] + 1,       // insertion
        prevRow[j] + 1,           // deletion
        prevRow[j - 1] + cost     // substitution
      );
    }
    for (let j = 0; j <= n; j++) {
      prevRow[j] = currRow[j];
    }
  }

  return prevRow[n];
}

export interface PreparedQuery {
  raw: string;
  normalized: string;
  tokens: Array<{
    text: string;
    skeleton: string;
    isPincode: boolean;
  }>;
  devanagariTransliteration?: string;
}

/**
 * Prepares and tokenizes a query for high-performance searching
 */
export function prepareQuery(rawQuery: string): PreparedQuery {
  let cleaned = rawQuery.trim().toLowerCase();
  
  // If query is in Devanagari, generate Latin transliteration
  let devTransliteration: string | undefined;
  if (hasDevanagari(cleaned)) {
    devTransliteration = transliterateDevanagari(cleaned);
  }

  const queryToTokenize = devTransliteration ? `${cleaned} ${devTransliteration}` : cleaned;
  const rawTokens = queryToTokenize
    .split(/[\s,./\\_-]+/)
    .map((t) => t.trim())
    .filter((t) => t.length > 0);

  // Deduplicate tokens
  const uniqueTokenTexts = Array.from(new Set(rawTokens));

  const tokens = uniqueTokenTexts.map((text) => ({
    text,
    skeleton: getPhoneticSkeleton(text),
    isPincode: /^\d{3,6}$/.test(text)
  }));

  return {
    raw: rawQuery,
    normalized: cleaned,
    tokens,
    devanagariTransliteration: devTransliteration
  };
}

/**
 * Evaluates whether a search string / target words matches a single query token.
 * Returns match score (0 = no match, higher = stronger match).
 */
export function matchTokenAgainstWords(
  targetWords: string[],
  targetSearchStr: string,
  tokenText: string,
  tokenSkeleton: string,
  isPincode: boolean
): number {
  // Pincode matching: strict prefix / substring check
  if (isPincode) {
    if (targetSearchStr.includes(tokenText)) {
      return 500;
    }
    return 0;
  }

  // NOTE: deliberately no raw substring/prefix shortcut here. Matching
  // anywhere inside the concatenated record text, or matching any word that
  // merely *starts with* the query, caused unrelated words that happen to
  // contain the query as a fragment (e.g. query "patadi" matching
  // "patadixyz" or "xyzpatadi") to show up as results. Only an exact word
  // match, or a genuine typo-tolerant fuzzy/phonetic match against a whole
  // word, counts now — so "patadi" still matches a word that is exactly
  // "patadi" (and separately-written suffix words like "bo"/"so"/"ho" are
  // unaffected, since each word is compared on its own), but not a longer
  // word that merely contains it.

  const tokenLen = tokenText.length;
  // If token is very short (1 char), only allow exact match
  if (tokenLen < 2) {
    return 0;
  }

  let bestWordScore = 0;

  for (let i = 0; i < targetWords.length; i++) {
    const word = targetWords[i];
    if (!word) continue;

    // A. Exact word match
    if (word === tokenText) {
      return 400;
    }

    // B. Phonetic skeleton matching — for genuine typo/spelling variants
    // only (e.g. 'sanwar' skeleton 's*nv*r' === 'sanwer' skeleton 's*nv*r').
    // Skeleton equality requires the whole word to reduce to the same
    // consonant skeleton, so it can't match a word with extra text tacked
    // on the front or back.
    if (tokenSkeleton && tokenSkeleton.length >= 3) {
      const wordSkeleton = getPhoneticSkeleton(word);
      if (wordSkeleton === tokenSkeleton) {
        bestWordScore = Math.max(bestWordScore, 200);
        continue;
      }
    }

    // C. Fuzzy Levenshtein match for typos (e.g. sanwar vs sanwer, indur vs indore)
    // Only check if length difference is <= 2 and word length is >= 4
    const wordLen = word.length;
    if (tokenLen >= 4 && Math.abs(wordLen - tokenLen) <= 2) {
      // First character check: allow if first char matches or common phonetic swap (v/w, s/sh)
      const firstA = tokenText[0];
      const firstB = word[0];
      const firstMatch =
        firstA === firstB ||
        ((firstA === 'v' || firstA === 'w') && (firstB === 'v' || firstB === 'w')) ||
        (firstA === 's' && firstB === 's');

      if (firstMatch) {
        const dist = levenshteinDistance(tokenText, word);
        if (dist === 1) {
          // 1 char edit distance: Very high confidence fuzzy match!
          bestWordScore = Math.max(bestWordScore, 180);
          continue;
        } else if (dist === 2 && tokenLen >= 6 && wordLen >= 6) {
          // 2 char edit distance allowed only for longer words
          bestWordScore = Math.max(bestWordScore, 90);
          continue;
        }
      }
    }
  }

  return bestWordScore;
}

export interface ScoredRecord<T> {
  record: T;
  score: number;
}

/**
 * Searches a list of records with fuzzy and phonetic ranking.
 * Guarantees that typing 'sanwar' will find 'Sanwer' with high confidence.
 */
export function fuzzySearchRecords<T extends { searchStr: string }>(
  records: T[],
  query: string,
  targetFieldExtractor?: (record: T) => string
): T[] {
  const trimmed = query.trim();
  if (!trimmed) return records;

  const prep = prepareQuery(trimmed);
  if (prep.tokens.length === 0) return records;

  const scoredResults: ScoredRecord<T>[] = [];

  for (let i = 0; i < records.length; i++) {
    const r = records[i];
    const targetStr = targetFieldExtractor ? targetFieldExtractor(r).toLowerCase() : r.searchStr;

    // Quick whole-phrase match bonus
    let recordScore = 0;
    if (targetStr.includes(prep.normalized)) {
      recordScore += 500;
    }

    // Split target into individual cleaned words
    const targetWords = targetStr.split(/[\s,./\\_-]+/).filter((w) => w.length > 0);

    let allTokensMatched = true;

    // If query was in Devanagari and transliterated, we match either the original or transliterated tokens
    const primaryTokens = prep.devanagariTransliteration
      ? prep.tokens.filter((t) => !hasDevanagari(t.text))
      : prep.tokens;

    for (let j = 0; j < primaryTokens.length; j++) {
      const tok = primaryTokens[j];
      const tokScore = matchTokenAgainstWords(
        targetWords,
        targetStr,
        tok.text,
        tok.skeleton,
        tok.isPincode
      );

      if (tokScore === 0) {
        allTokensMatched = false;
        break;
      }
      recordScore += tokScore;
    }

    if (allTokensMatched) {
      scoredResults.push({
        record: r,
        score: recordScore
      });
    }
  }

  // Sort by score descending (most relevant first). Deduplication is
  // intentionally not applied here — every matching record is returned,
  // even if another result looks identical to it.
  scoredResults.sort((a, b) => b.score - a.score);

  return scoredResults.map((s) => s.record);
}
