import { Capacitor } from '@capacitor/core';

/** True when running inside the packaged Android/iOS app (Capacitor), as
 * opposed to a normal browser tab. Native builds use real device plugins
 * (speech recognition, ML Kit barcode scanner) because the Android WebView
 * does not implement the browser's Web Speech / BarcodeDetector APIs. */
export function isNativeApp(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}
