/**
 * True when the app is running from a file:// URL (opened directly from
 * disk) rather than served over http/https.
 *
 * This matters specifically for microphone/camera access: several browsers
 * (Chrome included) treat file:// as unable to persist a per-site
 * permission decision, so getUserMedia()-based features (voice search,
 * barcode/QR camera scanning) are auto-denied immediately — no permission
 * prompt ever appears, which otherwise just looks like a broken "permission
 * denied" error with no way to grant it. Features gated on this should be
 * hidden here instead of offered and failing.
 */
export function isFileProtocol(): boolean {
  return typeof window !== 'undefined' && window.location.protocol === 'file:';
}

/**
 * True only for https:, localhost/127.0.0.1 over http, and file: — the set
 * the browser spec calls a "secure context". Camera and microphone access
 * (getUserMedia) are blocked by the browser on every other origin — most
 * commonly plain http:// on a LAN IP (e.g. opening the dev server from a
 * phone as http://192.168.x.x:5173 instead of https). This blocking can
 * happen even after the user appears to grant a permission prompt, which is
 * why mic/camera features should check this explicitly and explain why,
 * rather than surface a generic "permission denied".
 */
export function isSecureContextForMedia(): boolean {
  return typeof window !== 'undefined' && window.isSecureContext === true;
}
