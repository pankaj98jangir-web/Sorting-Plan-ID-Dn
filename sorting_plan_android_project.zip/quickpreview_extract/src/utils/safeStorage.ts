/**
 * Thin wrapper around localStorage that never throws.
 *
 * `localStorage` access can throw a SecurityError in several real
 * environments — not just file:// pages (an "opaque origin", which is
 * exactly what happens when this app is opened directly from disk instead
 * of served over http/https), but also private-browsing modes in some
 * browsers, storage-quota-exceeded situations, and corporate/enterprise
 * policies that disable Web Storage outright.
 *
 * An uncaught exception here during React's initial render (e.g. inside a
 * useState lazy initializer) crashes the entire render tree and leaves a
 * blank page — so every localStorage call in this app should go through
 * this wrapper instead of calling `window.localStorage` directly.
 */
export const safeStorage = {
  getItem(key: string): string | null {
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  },

  setItem(key: string, value: string): void {
    try {
      localStorage.setItem(key, value);
    } catch {
      // Ignore — e.g. opaque origin (file://), private browsing, quota exceeded.
    }
  },

  removeItem(key: string): void {
    try {
      localStorage.removeItem(key);
    } catch {
      // ignore
    }
  },

  has(key: string): boolean {
    try {
      return key in localStorage;
    } catch {
      return false;
    }
  }
};
