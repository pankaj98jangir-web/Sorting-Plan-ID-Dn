// Runs entirely in the browser/WebView using pdf.js — no network or backend
// required. Mirrors the server's "local-pdf-regex" strategy in server.ts, so
// sorting-plan PDFs can still be imported when there is no reachable backend
// (for example, once this app is packaged as a standalone Android APK).
//
// This is intentionally a plain-regex parser (no AI), so accuracy is lower
// than the server's Gemini-powered extraction — it is a fallback, not a
// replacement.

export interface OfflineParsedPdfRecord {
  v: string;
  p: string;
  f1: string;
  f2: string;
  f3: string;
}

export async function parsePdfOffline(file: File): Promise<OfflineParsedPdfRecord[]> {
  // Imported dynamically so pdf.js (and its worker) are only pulled into the
  // bundle/parsed when a PDF is actually opened, not on every app load.
  const pdfjsLib = await import('pdfjs-dist');
  // In the normal (module) build this URL resolves to a real hashed asset
  // file. In the single-file standalone build there is no separate worker
  // file to point to — if that import fails, we simply don't set
  // workerSrc, and pdf.js automatically falls back to running its "fake
  // worker" on the main thread instead (slower, but still works, no crash).
  try {
    const pdfjsWorkerUrl = (await import('pdfjs-dist/build/pdf.worker.min.mjs?url')).default;
    pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorkerUrl;
  } catch {
    // no-op — fake-worker fallback kicks in automatically
  }

  const buffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: buffer }).promise;

  let rawText = '';
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const content = await page.getTextContent();
    const lineText = content.items.map((item: any) => ('str' in item ? item.str : '')).join(' ');
    rawText += lineText + '\n';
  }

  const records: OfflineParsedPdfRecord[] = [];
  const lines = rawText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  for (const line of lines) {
    const pinMatch = line.match(/\b([1-9][0-9]{5})\b/);
    if (!pinMatch) continue;

    const pincode = pinMatch[1];
    const parts = line
      .split(/\t+|\s{2,}|\|/)
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    if (parts.length >= 2) {
      const v = parts[0] !== pincode ? parts[0] : parts[1] || '';
      const f1 = parts.length > 2 && parts[1] !== pincode ? parts[1] : parts[2] || '';
      const f2 = parts.length > 3 ? parts[parts.length - 2] : f1;
      const f3 = parts.length > 4 ? parts[parts.length - 1] : f2;

      const stripPin = (s: string) => s.replace(new RegExp(`\\b${pincode}\\b`, 'g'), '').trim();

      records.push({
        v: stripPin(v),
        p: pincode,
        f1: stripPin(f1),
        f2: stripPin(f2),
        f3: stripPin(f3)
      });
    }
  }

  return records;
}
