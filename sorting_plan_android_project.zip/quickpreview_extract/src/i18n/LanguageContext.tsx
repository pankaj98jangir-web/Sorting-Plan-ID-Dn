import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { safeStorage } from '../utils/safeStorage';
import { translations, Lang, TranslationKey } from './translations';

const LANG_STORAGE_KEY = 'sp_app_lang';

interface LanguageContextValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  toggleLang: () => void;
  /** Translate a UI string key, with optional {{var}} substitutions. This
   * is ONLY for the app's own interface text — never for postal data
   * (village/office names), which must always display exactly as entered. */
  t: (key: TranslationKey, vars?: Record<string, string | number>) => string;
}

const LanguageContext = createContext<LanguageContextValue | null>(null);

function getInitialLang(): Lang {
  const saved = safeStorage.getItem(LANG_STORAGE_KEY);
  return saved === 'hi' ? 'hi' : 'en';
}

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [lang, setLangState] = useState<Lang>(getInitialLang);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    safeStorage.setItem(LANG_STORAGE_KEY, l);
  }, []);

  const toggleLang = useCallback(() => {
    setLangState((prev) => {
      const next: Lang = prev === 'en' ? 'hi' : 'en';
      safeStorage.setItem(LANG_STORAGE_KEY, next);
      return next;
    });
  }, []);

  const t = useCallback(
    (key: TranslationKey, vars?: Record<string, string | number>) => {
      const dict = translations[lang] as Record<string, string>;
      let str = dict[key] ?? translations.en[key] ?? key;
      if (vars) {
        Object.entries(vars).forEach(([k, v]) => {
          str = str.split(`{{${k}}}`).join(String(v));
        });
      }
      return str;
    },
    [lang]
  );

  return (
    <LanguageContext.Provider value={{ lang, setLang, toggleLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export function useLanguage(): LanguageContextValue {
  const ctx = useContext(LanguageContext);
  if (!ctx) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return ctx;
}
