// Produces dist-standalone/index.html: a single HTML file with all JS and
// CSS inlined and compiled to a classic (non-module) script, so it can be
// opened directly via file:// in a browser — double-click and it runs, no
// server needed. This is different from the normal `npm run build`, whose
// output uses <script type="module"> and separate /assets/*.js files; those
// are blocked by browsers' CORS policy for the file:// origin.
//
// The PWA plugin (service worker, install prompt, manifest) is intentionally
// left out of this build: service workers require a secure context (https
// or localhost) and never register over file://, so including them here
// would just add dead weight.

import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';
import { viteSingleFile } from 'vite-plugin-singlefile';

export default defineConfig({
  base: './',
  plugins: [react(), tailwindcss(), viteSingleFile()],
  resolve: {
    alias: {
      '@': path.resolve(import.meta.dirname, '.'),
    },
  },
  build: {
    outDir: 'dist-standalone',
    target: 'es2018',
    cssCodeSplit: false,
    assetsInlineLimit: 100 * 1024 * 1024, // inline everything (fonts, images, worker files)
    rollupOptions: {
      output: {
        format: 'iife',
        inlineDynamicImports: true,
      },
    },
  },
});
