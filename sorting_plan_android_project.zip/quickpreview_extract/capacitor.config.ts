import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.indiapost.sortingplan',
  appName: 'SORTING PLAN - ID Dn INDORE',
  webDir: 'dist',
  android: {
    // Never allow mixed http/https content inside the app.
    allowMixedContent: false,
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1500,
      launchAutoHide: true,
      backgroundColor: '#8E1B25',
      androidScaleType: 'CENTER_INSIDE',
      showSpinner: false,
    },
    StatusBar: {
      style: 'DARK',
      backgroundColor: '#8E1B25',
      overlaysWebView: false,
    },
    Keyboard: {
      resize: 'body',
    },
  },
};

export default config;
