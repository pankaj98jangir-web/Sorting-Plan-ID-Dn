import fs from 'fs';

const filePath = 'dist-standalone/index.html';
let html = fs.readFileSync(filePath, 'utf-8');

const before = html;

// Two problems with the plain type="module" -> classic-script swap:
//   1. `defer` has no effect on inline (src-less) scripts per the HTML spec —
//      it only works on external <script src="...">. So it can't be used to
//      delay this inline bundle.
//   2. This script sits in <head>, before <div id="root"> exists in <body>.
//      A classic inline script runs immediately as the parser reaches it —
//      unlike a module script, which is implicitly deferred until the DOM is
//      ready. Running immediately means document.getElementById('root') is
//      still null, so React's createRoot() throws ("Target container is not
//      a DOM node") and the whole app fails to render.
//
// Fix: keep it a classic script (for file:// compatibility), but wrap its
// body in a DOMContentLoaded listener so it still only runs once the DOM —
// including #root — actually exists, regardless of where the tag sits.
html = html.replace(
  /<script type="module"(?:\s+crossorigin)?>([\s\S]*?)<\/script>/,
  (_match, code) =>
    `<script>document.addEventListener('DOMContentLoaded',function(){${code}});</script>`
);

if (html === before) {
  console.warn('[fix-standalone-html] No type="module" script tag found — nothing changed. Verify the build output manually.');
} else {
  fs.writeFileSync(filePath, html, 'utf-8');
  console.log('[fix-standalone-html] Converted inlined script to a classic (non-module) script for file:// compatibility.');
}
