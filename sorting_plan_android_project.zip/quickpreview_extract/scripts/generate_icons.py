import zlib
import struct
import os

def create_png(width, height, filepath, bg_color=(142, 27, 37), is_maskable=False):
    # RGBA image buffer
    # bg_color: #8E1B25 -> (142, 27, 37, 255)
    # gold_color: #F2B705 -> (242, 183, 5, 255)
    # white: (255, 255, 255, 255)
    r_bg, g_bg, b_bg = bg_color
    a_bg = 255
    r_gold, g_gold, b_gold = 242, 183, 5
    r_w, g_w, b_w = 255, 255, 255

    rows = []
    # If maskable, safe zone is inner 80% (10% padding on each side)
    scale = 0.7 if is_maskable else 0.85
    cx, cy = width / 2.0, height / 2.0

    for y in range(height):
        row = bytearray([0]) # filter type 0 (None)
        ny = (y - cy) / (height / 2.0)
        for x in range(width):
            nx = (x - cx) / (width / 2.0)
            
            # Simple mail horn / envelope icon math
            # Base background
            r, g, b, a = r_bg, g_bg, b_bg, a_bg

            # Post wing / triangle emblem
            # A triangle pointing up in upper middle
            if abs(nx) < 0.6 * scale and -0.6 * scale <= ny <= 0.5 * scale:
                # Triangle shape: top point at (0, -0.6*scale), bottom base at ny = 0.5*scale
                t_width = (ny + 0.6 * scale) / (1.1 * scale) * 0.6 * scale
                if abs(nx) <= t_width:
                    # Gold wing
                    r, g, b = r_gold, g_gold, b_gold

                # Inner circle cut
                dist_circle = ((nx)**2 + (ny - 0.05 * scale)**2)**0.5
                if dist_circle < 0.22 * scale:
                    r, g, b = r_bg, g_bg, b_bg

                # Inner white mail arrow
                if ny >= 0.05 * scale and abs(nx) <= (0.5 * scale - ny) * 0.7:
                    r, g, b = r_w, g_w, b_w

            row.extend([r, g, b, a])
        rows.append(bytes(row))

    raw_data = b"".join(rows)
    compressed = zlib.compress(raw_data)

    def chunk(chunk_type, data):
        c = chunk_type + data
        crc = struct.pack(">I", zlib.crc32(c) & 0xffffffff)
        return struct.pack(">I", len(data)) + c + crc

    png_header = b"\x89PNG\r\n\x1a\n"
    ihdr_data = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    ihdr = chunk(b"IHDR", ihdr_data)
    idat = chunk(b"IDAT", compressed)
    iend = chunk(b"IEND", b"")

    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, "wb") as f:
        f.write(png_header + ihdr + idat + iend)
    print(f"Generated {filepath} ({width}x{height})")

if __name__ == "__main__":
    base = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "public"))
    create_png(180, 180, os.path.join(base, "apple-touch-icon.png"))
    create_png(192, 192, os.path.join(base, "pwa-192x192.png"))
    create_png(512, 512, os.path.join(base, "pwa-512x512.png"))
    create_png(512, 512, os.path.join(base, "pwa-maskable-512x512.png"), is_maskable=True)
    print("All PWA icons generated successfully!")
