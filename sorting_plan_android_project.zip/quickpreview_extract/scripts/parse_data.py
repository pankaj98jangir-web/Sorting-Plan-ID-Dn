# Parse lists
print('Writing parse_data.py')
