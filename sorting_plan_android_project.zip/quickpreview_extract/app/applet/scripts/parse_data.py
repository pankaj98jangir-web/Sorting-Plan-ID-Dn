import csv
import json
import re

# File paths
MFL_PATH = 'src/data/records_mfl.ts'
DHAR_PATH = 'src/data/records_dhar.ts'
RATLAM_PATH = 'src/data/records_ratlam.ts'

# Helper to read existing records
def read_existing_tuples(file_path):
    tuples = []
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    # Match tuple patterns: [idx, is_td, village, pincode, f1, f2, f3]
    pattern = re.compile(r'\[\s*(\d+)\s*,\s*(\d+)\s*,\s*(".*?")\s*,\s*(".*?")\s*,\s*(".*?")\s*,\s*(".*?")\s*,\s*(".*?")\s*\]')
    for m in pattern.finditer(content):
        list_idx = int(m.group(1))
        is_td = int(m.group(2))
        v = json.loads(m.group(3))
        p = json.loads(m.group(4))
        f1 = json.loads(m.group(5))
        f2 = json.loads(m.group(6))
        f3 = json.loads(m.group(7))
        tuples.append([list_idx, is_td, v, p, f1, f2, f3])
    return tuples

print("Base helper defined.")
