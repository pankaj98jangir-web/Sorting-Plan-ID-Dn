package com.indiapost.sortingplan;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
