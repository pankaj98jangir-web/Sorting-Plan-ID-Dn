import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { PDFParse } from 'pdf-parse';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const isProd = process.env.NODE_ENV === 'production';
const PORT = parseInt(process.env.PORT || '3000', 10);
const PERMANENT_STORAGE_FILE = path.resolve(__dirname, 'src/data/permanent_storage.json');

// Ensure permanent storage file exists
function getPermanentData(): { mergedBuiltin: Record<string, any[]>; customLists: any[] } {
  try {
    if (fs.existsSync(PERMANENT_STORAGE_FILE)) {
      const content = fs.readFileSync(PERMANENT_STORAGE_FILE, 'utf-8');
      return JSON.parse(content);
    }
  } catch (err) {
    console.error('Error reading permanent storage file:', err);
  }
  return { mergedBuiltin: {}, customLists: [] };
}

function savePermanentData(data: { mergedBuiltin: Record<string, any[]>; customLists: any[] }): boolean {
  try {
    fs.writeFileSync(PERMANENT_STORAGE_FILE, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error saving permanent storage file:', err);
    return false;
  }
}

async function startServer() {
  const app = express();

  // Support large base64 uploads for PDFs and full CSV sorting lists
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // 1. Permanent Records APIs (Cross-device, cross-session permanent storage)
  app.get('/api/permanent-records', (_req: Request, res: Response) => {
    const data = getPermanentData();
    res.json({
      success: true,
      mergedBuiltin: data.mergedBuiltin || {},
      customLists: data.customLists || []
    });
  });

  app.post('/api/save-permanent-records', (req: Request, res: Response) => {
    try {
      const { mergedBuiltin, customLists } = req.body;
      const current = getPermanentData();

      if (mergedBuiltin && typeof mergedBuiltin === 'object') {
        current.mergedBuiltin = {
          ...current.mergedBuiltin,
          ...mergedBuiltin
        };
      }

      if (Array.isArray(customLists)) {
        current.customLists = customLists;
      }

      const ok = savePermanentData(current);
      if (!ok) {
        return res.status(500).json({ error: 'Failed to write permanent records to server disk.' });
      }

      console.log(`[Permanent Storage] Successfully updated permanent records on disk.`);
      return res.json({
        success: true,
        message: 'Records permanently embedded into server storage!',
        mergedBuiltin: current.mergedBuiltin,
        customLists: current.customLists
      });
    } catch (err: any) {
      console.error('Error in /api/save-permanent-records:', err);
      return res.status(500).json({ error: err?.message || 'Server error' });
    }
  });

  app.post('/api/reset-permanent-records', (req: Request, res: Response) => {
    try {
      const { listKey } = req.body;
      const current = getPermanentData();

      if (listKey) {
        delete current.mergedBuiltin[listKey];
        current.customLists = current.customLists.filter((cl: any) => cl.key !== listKey);
      } else {
        current.mergedBuiltin = {};
        current.customLists = [];
      }

      savePermanentData(current);
      return res.json({ success: true, message: 'Permanent records cleared on server.' });
    } catch (err: any) {
      return res.status(500).json({ error: err?.message || 'Server error' });
    }
  });

  // 2. Intelligent PDF Sorting Plan Parser API
  app.post('/api/parse-pdf', async (req: Request, res: Response) => {
    try {
      const { pdfBase64, filename } = req.body;
      if (!pdfBase64 || typeof pdfBase64 !== 'string') {
        return res.status(400).json({ error: 'pdfBase64 string is required.' });
      }

      const cleanBase64 = pdfBase64.replace(/^data:application\/pdf;base64,/, '');
      const pdfBuffer = Buffer.from(cleanBase64, 'base64');

      let records: Array<{ v: string; p: string; f1: string; f2: string; f3: string }> = [];
      let extractionMethod = 'local-pdf-parse';

      const apiKey = process.env.GEMINI_API_KEY;

      // Strategy A: If Gemini API key is available, use Gemini 2.5 Flash for high-accuracy tabular PDF extraction
      if (apiKey) {
        try {
          const ai = new GoogleGenAI({ apiKey });
          const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: [
              {
                role: 'user',
                parts: [
                  {
                    inlineData: {
                      mimeType: 'application/pdf',
                      data: cleanBase64
                    }
                  },
                  {
                    text: `You are an expert postal sorting plan document parser for India Post.
Extract all postal records from this document.
For each row/village/office, extract:
- "v": Village name or Area name (keep comma-separated village names intact if together in one cell, e.g. "ILASKHEDI, MOCHIKHEDI, LAXMIPURA")
- "p": 6-digit PIN code (e.g. "455116")
- "f1": Branch Post Office (B.O) name
- "f2": Sub Office (S.O) name
- "f3": Head Office (H.O) name

Return ONLY a valid JSON array of objects with keys: "v", "p", "f1", "f2", "f3".
Example:
[
  { "v": "ILASKHEDI, MOCHIKHEDI, LAXMIPURA, RALAMANDAL", "p": "455116", "f1": "AAGROD", "f2": "DEWAS HO", "f3": "DEWAS HO" }
]
Do NOT write markdown, code blocks, or explanations. Only raw JSON array.`
                  }
                ]
              }
            ]
          });

          const rawText = (response.text || '').trim();
          const cleanJson = rawText.replace(/```json/gi, '').replace(/```/g, '').trim();
          const parsed = JSON.parse(cleanJson);
          if (Array.isArray(parsed) && parsed.length > 0) {
            records = parsed.map((item: any) => ({
              v: String(item.v || item.village || '').trim(),
              p: String(item.p || item.pincode || '').trim(),
              f1: String(item.f1 || item.bo || item.branch || '').trim(),
              f2: String(item.f2 || item.so || item.subOffice || '').trim(),
              f3: String(item.f3 || item.ho || item.headOffice || '').trim()
            }));
            extractionMethod = 'gemini-ai-multimodal';
          }
        } catch (aiErr: any) {
          console.warn('[PDF Parser] Gemini extraction fallback to local parser:', aiErr?.message || aiErr);
        }
      }

      // Strategy B: Local PDF text parser using pdf-parse if Gemini not used or returned empty
      if (records.length === 0) {
        try {
          const parser = new PDFParse({ data: pdfBuffer });
          const textResult = await parser.getText();
          const rawText = textResult?.text || '';

          // Parse lines from rawText
          const lines = rawText.split(/\r?\n/).map((l) => l.trim()).filter((l) => l.length > 0);

          for (const line of lines) {
            // Find 6-digit pincode
            const pinMatch = line.match(/\b([1-9][0-9]{5})\b/);
            if (!pinMatch) continue;

            const pincode = pinMatch[1];
            // Split line by tab or multiple spaces
            const parts = line.split(/\t+|\s{2,}|\|/).map((s) => s.trim()).filter((s) => s.length > 0);

            if (parts.length >= 2) {
              const v = parts[0] !== pincode ? parts[0] : (parts[1] || '');
              const f1 = parts.length > 2 && parts[1] !== pincode ? parts[1] : (parts[2] || '');
              const f2 = parts.length > 3 ? parts[parts.length - 2] : f1;
              const f3 = parts.length > 4 ? parts[parts.length - 1] : f2;

              records.push({
                v: v.replace(new RegExp(`\\b${pincode}\\b`, 'g'), '').trim(),
                p: pincode,
                f1: f1.replace(new RegExp(`\\b${pincode}\\b`, 'g'), '').trim(),
                f2: f2.replace(new RegExp(`\\b${pincode}\\b`, 'g'), '').trim(),
                f3: f3.replace(new RegExp(`\\b${pincode}\\b`, 'g'), '').trim()
              });
            }
          }
          extractionMethod = 'local-pdf-regex';
        } catch (pdfErr: any) {
          console.error('[PDF Parser] Local PDF parsing error:', pdfErr);
        }
      }

      return res.json({
        success: true,
        filename: filename || 'sorting_plan.pdf',
        extractionMethod,
        count: records.length,
        records
      });
    } catch (err: any) {
      console.error('[PDF Parser] Server error:', err);
      return res.status(500).json({ error: err?.message || 'Failed to parse PDF.' });
    }
  });

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer();
